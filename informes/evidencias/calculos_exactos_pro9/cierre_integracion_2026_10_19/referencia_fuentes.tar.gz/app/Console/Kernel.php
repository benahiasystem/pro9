<?php

// ######## INICIO CONTRATO GEOPOLITICO VENEZUELA

namespace App\Console;

use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use Illuminate\Console\Scheduling\Schedule;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule) {
        $schedule->command('tenancy:run islr-retentions:recover')->everyMinute()->withoutOverlapping();
        $schedule->command('tenancy:run iva-retentions:recover')->everyMinute()->withoutOverlapping();
        $schedule->command('tenant:run')
            ->everyMinute();
        // Se ejecutara por hora guardando estado de cpu y memoria (windows/linux)
        //$schedule->command('status:server')->everyMinute();
        // $schedule->command('order:payments')->everyMinute()->appendOutputTo(storage_path('logs/order_create.log'));
        $schedule->command('order:payments')->everyMinute()->sendOutputTo(storage_path('logs/order_create.log'));
        $schedule->command('tenancy:run suscription:create-orders')->dailyAt('08:00')->timezone('America/Caracas')->appendOutputTo(storage_path('logs/suscription_orders.log'));
        $schedule->command('tenancy:run suscription:check-expired')->dailyAt('08:30')->timezone('America/Caracas')->appendOutputTo(storage_path('logs/suscription_expired.log'));
        // $schedule->command('tenancy:run suscription:send-reminders')->everyMinute()->appendOutputTo(storage_path('logs/suscription_reminders.log'));
        $schedule->command('tenancy:run suscription:send-reminders') ->everyMinute() ->sendOutputTo(storage_path('logs/suscription_reminders.log'));
        $schedule->command('tenancy:run ecommerce:expire-discount-campaigns')
            ->everyMinute()
            ->withoutOverlapping()
            ->sendOutputTo(storage_path('logs/discount_campaigns_expired.log'));
        // Limpieza de órdenes de impresión ya impresas (status=2) — pdf_b64 es pesado
        $schedule->command('tenancy:run print-orders:prune')->dailyAt('04:00')->timezone('America/Caracas')->appendOutputTo(storage_path('logs/print_orders_prune.log'));
        // Marketplace: minimización de retención (Ley 29733) — purga contactos e IPs viejas
        $schedule->command('marketplace:purge')->dailyAt('03:30')->timezone('America/Caracas')->appendOutputTo(storage_path('logs/marketplace_purge.log'));
        $schedule->command('marketplace:purge')->dailyAt('03:30')->timezone('America/Caracas')->appendOutputTo(storage_path('logs/marketplace_purge.log'));
        // Limpieza de archivos por empresa segun lo programado en storage_cleanup_configurations.
        // Corre cada 30 min porque la hora la define cada configuracion, no el schedule
        $schedule->command('storage:clean')->everyMinute()->timezone('America/Caracas')->appendOutputTo(storage_path('logs/storage_clean.log'));
        $schedule->command('mozo:sync')->everyThirtyMinutes()->sendOutputTo(storage_path('logs/mozo_sync.log'));
        $schedule->command('vendeya:sync')->everyThirtyMinutes()->sendOutputTo(storage_path('logs/vendeya_sync.log'));
        // Llena las tablas para libro mayor - Se desactiva CMAR - buscar opcion de url
        // $schedule->command('account_ledger:fill')->hourly();

        //restaurar base de datos demo para restaurant
        // $schedule->command('database:restoredemo')->dailyAt('23:50');
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands() {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
// ######## FIN CONTRATO GEOPOLITICO VENEZUELA
