<?php
// ######## INICIO TASAS OCHO DECIMALES: CONVERSIONES EXACTAS ########
// ######## FIN TASAS OCHO DECIMALES: CONVERSIONES EXACTAS ########
// ######## INICIO MIGRACIÓN MONEDA VENEZUELA ########

namespace App\Http\Controllers\Tenant;

use App\CoreFacturalo\Facturalo;
use App\CoreFacturalo\Helpers\Template\ReportHelper;
use App\Exports\PaymentExport;
use App\Helpers\CacheHelper;
use App\Http\Controllers\Controller;
use App\Http\Controllers\SearchItemController;
use App\Http\Requests\Tenant\DocumentEmailRequest;
use App\Http\Requests\Tenant\DocumentRequest;
use App\Http\Requests\Tenant\DocumentUpdateRequest;
use App\Http\Resources\Tenant\DocumentCollection;
use App\Http\Resources\Tenant\DocumentResource;
use App\Imports\DocumentImportExcelFormat;
use App\Imports\DocumentsImport;
use App\Imports\DocumentsImportTwoFormat;
use App\Mail\Tenant\DocumentEmail;
use App\Models\Tenant\Catalogs\AffectationIgvType;
use App\Models\Tenant\Catalogs\AttributeType;
use App\Models\Tenant\Catalogs\CatColorsItem;
use App\Models\Tenant\Catalogs\CatItemMoldCavity;
use App\Models\Tenant\Catalogs\CatItemMoldProperty;
use App\Models\Tenant\Catalogs\CatItemPackageMeasurement;
use App\Models\Tenant\Catalogs\CatItemProductFamily;
use App\Models\Tenant\Catalogs\CatItemStatus;
use App\Models\Tenant\Catalogs\CatItemUnitBusiness;
use App\Models\Tenant\Catalogs\CatItemUnitsPerPackage;
use App\Models\Tenant\Catalogs\ChargeDiscountType;
use App\Models\Tenant\Catalogs\CurrencyType;
use App\Models\Tenant\Catalogs\DocumentType;
use App\Models\Tenant\Catalogs\NoteCreditType;
use App\Models\Tenant\Catalogs\NoteDebitType;
use App\Models\Tenant\Catalogs\OperationType;
use App\Models\Tenant\Catalogs\PriceType;
use App\Models\Tenant\CatItemSize;
use App\Models\Tenant\Company;
use App\Models\Tenant\Configuration;
use App\Models\Tenant\Dispatch;
use App\Models\Tenant\Document;
use App\Models\Tenant\Establishment;
use App\Models\Tenant\Item;
use App\Models\Tenant\PaymentCondition;
use App\Models\Tenant\PaymentMethodType;
use App\Models\Tenant\Person;
use App\Models\Tenant\SaleNote;
use App\Models\Tenant\Series;
use App\Services\SeriesResolver;
use App\Support\Venezuela\Localization;
use App\Models\Tenant\StateType;
use App\Models\Tenant\User;
use App\Traits\OfflineTrait;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Excel;
use Modules\BusinessTurn\Models\BusinessTurn;
use Modules\Finance\Helpers\UploadFileHelper;
use Modules\Finance\Traits\FinanceTrait;
use Modules\Inventory\Models\Warehouse as ModuleWarehouse;
use Modules\Item\Http\Requests\BrandRequest;
use Modules\Item\Http\Requests\CategoryRequest;
use Modules\Item\Models\Brand;
use Modules\Item\Models\Category;
use Modules\Document\Helpers\DocumentHelper;
use Modules\Inventory\Models\{
    InventoryConfiguration
};
use App\Models\Tenant\Cash;
use Modules\LevelAccess\Traits\SystemActivityTrait;

class DocumentController extends Controller
{
    use FinanceTrait;
    use OfflineTrait;
    use SystemActivityTrait;

    private $route_path;

    private $max_count_payment = 0;

    public function __construct()
    {
        $this->middleware('input.request:document,web', ['only' => ['store','preview']]);
        $this->middleware('input.request:documentUpdate,web', ['only' => ['update']]);
    }

    public function index()
    {
        $is_client = $this->getIsClient();
        $import_documents = config('tenant.import_documents');
        $import_documents_second = config('tenant.import_documents_second_format');
        $document_import_excel = config('tenant.document_import_excel');
        $configuration = Configuration::getPublicConfig();

        return view('tenant.documents.index',
            compact('is_client', 'import_documents',
                'import_documents_second',
                'document_import_excel',
                'configuration'));
    }

    public function columns()
    {
        return [
            'number' => 'Número',
            'date_of_issue' => 'Fecha de emisión'
        ];
    }

    // TODO: refactorizar para usar el mismo método en el controller de sale notes
    public function records(Request $request)
    {
        $auth_id = auth()->user()->id;
        $cacheParams = [
            'category_id' => $request->category_id,
            'page' => $request->page,
            'customer_id' => $request->customer_id,
            'd_end' => $request->d_end,
            'd_start' => $request->d_start,
            'date_of_issue' => $request->date_of_issue,
            'document_type_id' => $request->document_type_id,
            'item_id' => $request->item_id,
            'number' => $request->number,
            'control_number' => $request->control_number,
            'observations' => $request->observations,
            'pending_payment' => $request->pending_payment,
            'series' => $request->series,
            'state_type_id' => $request->state_type_id,
            'purchase_order' => $request->purchase_order,
            'guides' => $request->guides,
            'plate_numbers' => $request->plate_numbers,
        ];
        $cacheKey = \App\Services\Fiscal\DocumentEmissionView::cacheNamespace() . ':document_list_' . "user-$auth_id" . "_" . md5(json_encode($cacheParams));
        if ($this->pingCache()) {
            return $this->cacheWithTagKey(
                $cacheKey,
                ['document_list'], // Etiqueta para el detalle del item
                300, // 1 hora (el detalle cambia menos frecuentemente que las listas)
                fn () => new DocumentCollection($this->getRecords($request)->paginate(config('tenant.items_per_page'))),
                [ 'section' => 'Document List', 'filters' => $cacheParams ] // Contexto adicional para logging
            );
        } else {
            return new DocumentCollection($this->getRecords($request)->paginate(config('tenant.items_per_page')));
        }
        // $records = $this->getRecords($request);


        // return new DocumentCollection($records->paginate(config('tenant.items_per_page')));
    }

    /**
     * Devuelve los totales de la busqueda,
     *
     * Implementado en resources/js/views/tenant/documents/index.vue
     * @param Request $request
     *
     * @return array[]
     */
    public function recordsTotal(Request $request)
    {

        $FT_t = DocumentType::find('01');
        $BV_t = DocumentType::find('03');
        $NC_t = DocumentType::find('07');
        $ND_t = DocumentType::find('08');
        $currencyTypeId = Localization::nationalCurrencyId();
        $currencySymbol = Localization::currencySymbol($currencyTypeId);

        $BV = $this->getRecords($request)->where('document_type_id', $BV_t->id)->where('currency_type_id', $currencyTypeId)->sum('total');
        $FT = $this->getRecords($request)->where('document_type_id', $FT_t->id)->where('currency_type_id', $currencyTypeId)->sum('total');
        $NC = $this->getRecords($request)->where('document_type_id', $NC_t->id)->where('currency_type_id', $currencyTypeId)->sum('total');
        $ND = $this->getRecords($request)->where('document_type_id', $ND_t->id)->where('currency_type_id', $currencyTypeId)->sum('total');
        return [
            [
                'name' => $FT_t->description,
                'total' => "{$currencySymbol} " . ReportHelper::setNumber($FT),
            ],
            [
                'name' => $BV_t->description,
                'total' => "{$currencySymbol} " . ReportHelper::setNumber($BV),

            ],
            [
                'name' => $NC_t->description,
                'total' => "{$currencySymbol} " . ReportHelper::setNumber($NC),
            ],
            [
                'name' => $ND_t->description,
                'total' => "{$currencySymbol} " . ReportHelper::setNumber($ND),
            ],
        ];
    }

    /**
     * KPIs del listado de comprobantes (solo documentos: facturas y boletas).
     *
     * Devuelve:
     *  - Ventas del mes (facturas + boletas), desglose y variacion vs mes anterior.
     *  - Cuentas por cobrar (saldo pendiente), separado en por cobrar y vencidas.
     *
     * Implementado en resources/js/views/tenant/documents/index.vue
     *
     * @param Request $request
     * @return array
     */
    public function kpis(Request $request)
    {
        $valid_states = ['01', '03', '05', '07', '13'];

        $start_current = Carbon::now()->startOfMonth()->toDateString();
        $end_current   = Carbon::now()->endOfMonth()->toDateString();
        $start_prev    = Carbon::now()->subMonthNoOverflow()->startOfMonth()->toDateString();
        $end_prev      = Carbon::now()->subMonthNoOverflow()->endOfMonth()->toDateString();

        $sumPen = function ($document_type_id, $start, $end) use ($valid_states) {
            return (float) Document::query()
                ->where(fn ($q) => $q->whereTypeUser())
                ->whereIn('state_type_id', $valid_states)
                ->where('document_type_id', $document_type_id)
                ->whereBetween('date_of_issue', [$start, $end])
                ->selectRaw("COALESCE(SUM(CASE WHEN currency_type_id = 'VES' THEN total ELSE total * exchange_rate_sale END), 0) as s")
                ->value('s');
        };

        $facturas_now = $sumPen('01', $start_current, $end_current);
        $sales_now    = $facturas_now;

        $sales_prev = $sumPen('01', $start_prev, $end_prev);

        if ($sales_prev > 0) {
            $variation = (($sales_now - $sales_prev) / $sales_prev) * 100;
        } else {
            $variation = $sales_now > 0 ? 100 : 0;
        }

        // Cuentas por cobrar: saldo pendiente de facturas/boletas no canceladas.
        $receivable_total = 0;
        $por_cobrar_30    = 0;
        $vencidas         = 0;
        $today = Carbon::now()->startOfDay();
        $due_limit_30 = $today->copy()->addDays(30)->endOfDay();

        Document::query()
            ->where(fn ($q) => $q->whereTypeUser())
            ->whereIn('state_type_id', $valid_states)
            ->whereIn('document_type_id', ['01'])
            ->where('total_canceled', false)
            ->with(['invoice:id,document_id,date_of_due'])
            ->withSum('payments as payments_sum', 'payment')
            ->get(['id', 'document_type_id', 'currency_type_id', 'exchange_rate_sale', 'total'])
            ->each(function ($row) use (&$receivable_total, &$por_cobrar_30, &$vencidas, $today, $due_limit_30) {
                $retention = $row->retention_amount + $row->guarantee_amount;
                $balance = $row->total - $retention - ($row->payments_sum ?? 0);

                if ($balance <= 0) {
                    return;
                }

                $balance_pen = ($row->currency_type_id === 'VES')
                    ? $balance
                    : (float) \App\Services\ExchangeRates\ExchangeRateMath::finalAmount(\App\Services\ExchangeRates\ExchangeRateMath::rational($balance)->multipliedBy(\App\Services\ExchangeRates\ExchangeRateMath::rational($row->exchange_rate_sale)), 2);

                $receivable_total += $balance_pen;

                $date_of_due = optional($row->invoice)->date_of_due;
                if ($date_of_due && Carbon::parse($date_of_due)->lt($today)) {
                    $vencidas += $balance_pen;
                } elseif ($date_of_due && Carbon::parse($date_of_due)->lte($due_limit_30)) {
                    $por_cobrar_30 += $balance_pen;
                }
            });

        return [
            'sales' => [
                'total'        => 'Bs. ' . number_format($sales_now, 2, '.', ','),
                'facturas'     => 'Bs. ' . number_format($facturas_now, 2, '.', ','),
                'variation'    => ($variation >= 0 ? '+' : '') . number_format($variation, 1, '.', ',') . '% vs mes anterior',
                'variation_up' => $variation >= 0,
            ],
            'receivable' => [
                'total'   => 'Bs. ' . number_format($receivable_total, 2, '.', ','),
                'current' => 'Bs. ' . number_format($por_cobrar_30, 2, '.', ','),
                'overdue' => 'Bs. ' . number_format($vencidas, 2, '.', ','),
            ],
        ];
    }

    public function searchCustomers(Request $request)
    {

        //tru de boletas en env esta en true filtra a los con dni   , false a todos
        $identity_document_type_id = $this->getIdentityDocumentTypeId($request->document_type_id, $request->operation_type_id);
//        $operation_type_id_id = $this->getIdentityDocumentTypeId($request->operation_type_id);

        $customers = Person::where(function ($query) use ($request) {
            $query->where('number', 'like', "%{$request->input}%")
                ->orWhere('name', 'like', "%{$request->input}%");
        })
            ->whereType('customers')
            ->whereSalesIdentityActive(\App\Services\ExportInvoicePolicy::isExport($request->operation_type_id))
            ->orderBy('name')
            ->whereIn('identity_document_type_id', $identity_document_type_id)
            ->whereIsEnabled()
            ->whereFilterCustomerBySeller('customers')
            ->get()->transform(function ($row) {
                /** @var  Person $row */
                return $row->getCollectionData(true);
                /* Movido al modelo */
                return [
                    'id' => $row->id,
                    'description' => $row->number . ' - ' . $row->name,
                    'name' => $row->name,
                    'number' => $row->number,
                    'identity_document_type_id' => $row->identity_document_type_id,
                    'identity_document_type_code' => $row->identity_document_type->code,
                    'addresses' => $row->addresses,
                    'address' => $row->address
                ];
            });
        // dd($customers);

        return compact('customers');
    }


    public function create()
    {
        return $this->renderDocumentCreateForm();
    }

    public function createFromTable($table, $table_id)
    {
        return $this->renderDocumentCreateForm($table, $table_id);
    }

    private function renderDocumentCreateForm($table = null, $table_id = null)
    {
        if (auth()->user()->type == 'integrator')
            return redirect('/documents');

        $cash = Cash::where([['user_id', auth()->user()->id], ['state', true]])->first();

        if (!$cash) {
            if (!$this->userCanAccessCash()) {
                return redirect('/documents')->with('toast_warning', 'No tienes permisos para abrir caja. Contacta al administrador para acceder a la configuración de Finanzas.');
            }
            return redirect()->route('tenant.cash.index', ['redirect_reason' => 'no_cash_document']);
        }

        $configuration = Configuration::first();
        $is_contingency = 0;

        return view('tenant.documents.form', compact('is_contingency', 'configuration', 'table', 'table_id'));
    }

    public function create_tensu()
    {
        if (auth()->user()->type == 'integrator')
            return redirect('/documents');

        $cash = Cash::where([['user_id', auth()->user()->id], ['state', true]])->first();

        if (!$cash) {
            if (!$this->userCanAccessCash()) {
                return redirect('/documents')->with('toast_warning', 'No tienes permisos para abrir caja. Contacta al administrador para acceder a la configuración de Finanzas.');
            }
            return redirect()->route('tenant.cash.index', ['redirect_reason' => 'no_cash_document']);
        }

        $is_contingency = 0;
        return view('tenant.documents.form_tensu', compact('is_contingency'));
    }

    private function userCanAccessCash(): bool
    {
        // Simula una petición GET a /cash con el usuario actual
        $cashRequest = \Illuminate\Http\Request::create('cash', 'GET');
        $cashRequest->setUserResolver(fn () => auth()->user());

        $passed = false;
        $middleware = new \App\Http\Middleware\RedirectModuleLevel();
        $middleware->handle($cashRequest, function () use (&$passed) {
            $passed = true;            // si llega aquí, el middleware dejó pasar => sí puede entrar a /cash
            return response('ok');
        });

        return $passed;                // false => el middleware redirigiría => sin acceso a caja
    }


    public function tables()
    {
        $customers = $this->table('customers');
        $user = new User();
        if (\Auth::user()) {
            $user = \Auth::user();
        }
        $document_id = $user->document_id;
        $series_id = $user->series_id;
        $establishment_id = $user->establishment_id;
        $can_create_payment=$user->type === 'admin' || (bool)$user->create_payment;
        $userId = $user->id;
        $userType = $user->type;
        $series = $user->getSeries();
        // $prepayment_documents = $this->table('prepayment_documents');
        $establishments = Establishment::where('id', $establishment_id)->get();// Establishment::all();
        // ########## INICIO CAMBIO SOLO FACTURAS Y NOTAS DE VENTA
        $document_types_invoice = DocumentType::whereIn('id', ['01'])->get();
        // ######### FIN CAMBIO SOLO FACTURAS Y NOTAS DE VENTA
        $document_types_note = DocumentType::whereIn('id', ['07', '08'])->get();
        $note_credit_types = NoteCreditType::whereActive()->orderByDescription()->get();
        $note_debit_types = NoteDebitType::whereActive()->orderByDescription()->get();
        $currency_types = CurrencyType::whereActive()->get();
        $special_tax_regimes = \App\Services\ExportInvoicePolicy::available(Company::firstOrFail()) ? \App\Services\SpecialTaxRegimePolicy::options() : [];
        $operation_types = OperationType::whereActive(\App\Services\ExportInvoicePolicy::available(Company::firstOrFail()))->get();
        $discount_types = ChargeDiscountType::whereType('discount')->whereLevel('item')->get();
        $charge_types = ChargeDiscountType::whereType('charge')->whereLevel('item')->get();
        $company = Company::active();
        $document_type_03_filter = config('tenant.document_type_03_filter');
        // $sellers = User::where('establishment_id',$establishment_id)->whereIn('type', ['seller', 'admin'])->orWhere('id', $userId)->get();
        $sellers = User::getSellersToNvCpe($establishment_id, $userId)
            ->transform(function (User $row) {
                return $row->getCollectionData();
            });
        $payment_method_types = $this->table('payment_method_types');
        $business_turns = BusinessTurn::where('active', true)->get();
        $enabled_discount_global = Configuration::isGlobalDiscountEnabled();
        $is_client = $this->getIsClient();
        // ########## INICIO CAMBIO SOLO FACTURAS Y NOTAS DE VENTA
        $select_first_document_type_03 = false;
        // ######### FIN CAMBIO SOLO FACTURAS Y NOTAS DE VENTA
        $payment_conditions = PaymentCondition::all();
        $restaurant_tip_factor = optional(Configuration::first())->restaurant_tip_factor;
        $is_restaurant_active = DB::connection('tenant')->table('business_turns')
        ->where('id', 3)
        ->where('active', 1)
        ->exists();

        $document_types_guide = DocumentType::whereIn('id', ['09'])->get()->transform(function ($row) {
            return [
                'id' => $row->id,
                'active' => (bool)$row->active,
                'short' => $row->short,
                'description' => ucfirst(mb_strtolower(str_replace('REMITENTE ELECTRÓNICA', 'REMITENTE', $row->description))),
            ];
        });

//        return compact('customers', 'establishments', 'series', 'document_types_invoice', 'document_types_note',
//                       'note_credit_types', 'note_debit_types', 'currency_types', 'operation_types',
//                       'discount_types', 'charge_types', 'company', 'document_type_03_filter',
//                       'document_types_guide');

        // return compact('customers', 'establishments', 'series', 'document_types_invoice', 'document_types_note',
        //                'note_credit_types', 'note_debit_types', 'currency_types', 'operation_types',
        //                'discount_types', 'charge_types', 'company', 'document_type_03_filter');

        $payment_destinations = $this->getPaymentDestinations();
        $affectation_igv_types = AffectationIgvType::whereActive(\App\Services\ExportInvoicePolicy::available(Company::firstOrFail()))->get();
        $user = $userType;
        // ########## INICIO CAMBIO CATÁLOGOS DE NOMBRES
        $global_discount_types = ChargeDiscountType::getGlobalDiscounts();
        // ######### FIN CAMBIO CATÁLOGOS DE NOMBRES
        $enable_consigned = Configuration::first()->enable_consigned;

        return compact(
            'document_id',
            'series_id',
            'customers',
            'establishments',
            'series',
            'document_types_invoice',
            'document_types_note',
            'note_credit_types',
            'note_debit_types',
            'currency_types',
            'operation_types',
            'special_tax_regimes',
            'discount_types',
            'charge_types',
            'company',
            'document_type_03_filter',
            'document_types_guide',
            'user',
            'sellers',
            'payment_method_types',
            'enabled_discount_global',
            'business_turns',
            'is_client',
            'select_first_document_type_03',
            'payment_destinations',
            'can_create_payment',
            'payment_conditions',
            'global_discount_types',
            'affectation_igv_types',
            'restaurant_tip_factor',
            'is_restaurant_active',
            'enable_consigned'
        );

    }

    public function item_tables()
    {
        // $items = $this->table('items');
        $items = SearchItemController::getItemsToDocuments();
        $categories = [];
        $affectation_igv_types = AffectationIgvType::whereActive(\App\Services\ExportInvoicePolicy::available(Company::firstOrFail()))->get();
        $price_types = PriceType::whereActive()->get();
        $special_tax_regimes = \App\Services\ExportInvoicePolicy::available(Company::firstOrFail()) ? \App\Services\SpecialTaxRegimePolicy::options() : [];
        $operation_types = OperationType::whereActive(\App\Services\ExportInvoicePolicy::available(Company::firstOrFail()))->get();
        $discount_types = ChargeDiscountType::whereType('discount')->whereLevel('item')->get();
        $charge_types = ChargeDiscountType::whereType('charge')->whereLevel('item')->get();
        $attribute_types = AttributeType::whereActive()->orderByDescription()->get();
        $is_client = $this->getIsClient();
        $validate_stock_add_item = InventoryConfiguration::getRecordIndividualColumn('validate_stock_add_item');

        $configuration = Configuration::first();

        /** Informacion adicional */
        $colors = collect([]);
        $CatItemSize = $colors;
        $CatItemStatus = $colors;
        $CatItemUnitBusiness = $colors;
        $CatItemMoldCavity = $colors;
        $CatItemPackageMeasurement = $colors;
        $CatItemUnitsPerPackage = $colors;
        $CatItemMoldProperty = $colors;
        $CatItemProductFamily = $colors;
        if ($configuration->isShowExtraInfoToItem()) {

            $colors = CatColorsItem::all();
            $CatItemSize = CatItemSize::all();
            $CatItemStatus = CatItemStatus::all();
            $CatItemUnitBusiness = CatItemUnitBusiness::all();
            $CatItemMoldCavity = CatItemMoldCavity::all();
            $CatItemPackageMeasurement = CatItemPackageMeasurement::all();
            $CatItemUnitsPerPackage = CatItemUnitsPerPackage::all();
            $CatItemMoldProperty = CatItemMoldProperty::all();
            $CatItemProductFamily = CatItemProductFamily::all();
        }


        /** Informacion adicional */

        return compact(
            'items',
            'categories',
            'affectation_igv_types',
            'price_types',
            'operation_types',
            'special_tax_regimes',
            'discount_types',
            'charge_types',
            'attribute_types',
            'is_client',
            'colors',
            'CatItemSize',
            'CatItemMoldCavity',
            'CatItemMoldProperty',
            'CatItemUnitBusiness',
            'CatItemStatus',
            'CatItemPackageMeasurement',
            'CatItemProductFamily',
            'validate_stock_add_item',
            'CatItemUnitsPerPackage');
    }

    public function table($table)
    {
        if ($table === 'customers') {
            $customers = Person::with('addresses')
                ->whereType('customers')
                ->whereSalesIdentityActive()
                ->whereIsEnabled()
                ->orderBy('name')
                ->take(20)
                ->get()->transform(function ($row) {
                    /** @var Person $row */
                    return $row->getCollectionData();
                    /** Se ha movido la salida, al modelo */
                    return [
                        'id' => $row->id,
                        'description' => $row->number . ' - ' . $row->name,
                        'name' => $row->name,
                        'number' => $row->number,
                        'identity_document_type_id' => $row->identity_document_type_id,
                        'identity_document_type_code' => $row->identity_document_type->code,
                        'addresses' => $row->addresses,
                        'address' => $row->address,
                        'internal_code' => $row->internal_code,
                    ];

                });
            return $customers;
        }

        if ($table === 'prepayment_documents') {
            $prepayment_documents = Document::whereHasPrepayment()->get()->transform(function ($row) {

                $total = round($row->pending_amount_prepayment, 2);
                // ########## INICIO CAMBIO AFECTACIÓN IVA
                $amount = ($row->affectation_type_prepayment == '10')
                    ? round($total / \App\Support\Venezuela\Localization::taxMultiplier(), 2)
                    : $total;
                // ######### FIN CAMBIO AFECTACIÓN IVA

                return [
                    'id' => $row->id,
                    'description' => $row->number_full,
                    'series' => $row->series,
                    'number' => $row->number,
                    'document_type_id' => ($row->document_type_id == '01') ? '02' : '03',
                    // 'amount' => $row->total_value,
                    // 'total' => $row->total,
                    'amount' => $amount,
                    'total' => $total,

                ];
            });
            return $prepayment_documents;
        }

        if ($table === 'payment_method_types') {
            // ######### INICIO CATÁLOGO MÉTODOS DE PAGO VENEZUELA #########
            return PaymentMethodType::getPaymentMethodTypes();
            // ######### FIN CATÁLOGO MÉTODOS DE PAGO VENEZUELA #########
        }

        if ($table === 'items') {

            return SearchItemController::getItemsToDocuments();

            $establishment_id = auth()->user()->establishment_id;
            $warehouse = ModuleWarehouse::where('establishment_id', $establishment_id)->first();
            // $items_u = Item::whereWarehouse()->whereIsActive()->whereNotIsSet()->orderBy('description')->take(20)->get();
            $items_u = Item::with('warehousePrices')
                ->whereIsActive()
                ->orderBy('description');
            $items_s = Item::with('warehousePrices')
                ->where('items.unit_type_id', 'SERV')
                ->whereIsActive()
                ->orderBy('description');
            $items_u = $items_u
                ->take(20)
                ->get();
            $items_s = $items_s
                ->take(10)
                ->get();
            $items = $items_u->merge($items_s);

            return collect($items)->transform(function ($row) use ($warehouse) {
                /** @var Item $row */
                return $row->getDataToItemModal($warehouse);
                $detail = $this->getFullDescription($row, $warehouse);
                return [
                    'id' => $row->id,
                    'full_description' => $detail['full_description'],
                    'model' => $row->model,
                    'brand' => $detail['brand'],
                    'warehouse_description' => $detail['warehouse_description'],
                    'category' => $detail['category'],
                    'stock' => $detail['stock'],
                    'internal_id' => $row->internal_id,
                    'description' => $row->description,
                    'currency_type_id' => $row->currency_type_id,
                    'currency_type_symbol' => $row->currency_type->symbol,
                    'sale_unit_price' => Item::getSaleUnitPriceByWarehouse($row, $warehouse->id),
                    'purchase_unit_price' => $row->purchase_unit_price,
                    'unit_type_id' => $row->unit_type_id,
                    'sale_affectation_igv_type_id' => $row->sale_affectation_igv_type_id,
                    'purchase_affectation_igv_type_id' => $row->purchase_affectation_igv_type_id,
                    'calculate_quantity' => (bool)$row->calculate_quantity,
                    'has_igv' => (bool)$row->has_igv,
                    'item_unit_types' => collect($row->item_unit_types)->transform(function ($row) {
                        return [
                            'id' => $row->id,
                            'description' => "{$row->description}",
                            'item_id' => $row->item_id,
                            'unit_type_id' => $row->unit_type_id,
                            'quantity_unit' => $row->quantity_unit,
                            'price1' => $row->price1,
                            'price2' => $row->price2,
                            'price3' => $row->price3,
                            'price_default' => $row->price_default,
                        ];
                    }),
                    'warehouses' => collect($row->warehouses)->transform(function ($row) use ($warehouse) {
                        return [
                            'warehouse_description' => $row->warehouse->description,
                            'stock' => $row->stock,
                            'warehouse_id' => $row->warehouse_id,
                            'checked' => ($row->warehouse_id == $warehouse->id) ? true : false,
                        ];
                    }),
                    'attributes' => $row->attributes ? $row->attributes : [],
                    'lots_group' => collect($row->lots_group)->transform(function ($row) {
                        return [
                            'id' => $row->id,
                            'code' => $row->code,
                            'quantity' => $row->quantity,
                            'date_of_due' => $row->date_of_due,
                            'checked' => false
                        ];
                    }),
                    'lots' => [],
                    'lots_enabled' => (bool)$row->lots_enabled,
                    'series_enabled' => (bool)$row->series_enabled,

                ];
            });
        }

        return [];
    }

    public function getFullDescription($row, $warehouse)
    {

        $desc = ($row->internal_id) ? $row->internal_id . ' - ' . $row->description : $row->description;
        $category = ($row->category) ? "{$row->category->name}" : "";
        $brand = ($row->brand) ? "{$row->brand->name}" : "";


        if ($row->unit_type_id != 'SERV') {
            if (isset($row['stock'])) {
                $warehouse_stock = number_format($row['stock'], 2);
            } else {
                $warehouse_stock = ($row->warehouses && $warehouse) ?
                    number_format($row->warehouses->where('warehouse_id', $warehouse->id)->first()->stock, 2) :
                    0;
            }

            $stock = ($row->warehouses && $warehouse) ? "{$warehouse_stock}" : "";
        } else {
            $stock = '';
        }

        $desc = "{$desc} - {$brand}";

        return [
            'full_description' => $desc,
            'brand' => $brand,
            'category' => $category,
            'stock' => $stock,
            'warehouse_description' => $warehouse->description,
        ];
    }


    public function record($id)
    {
        $this->forgetLegacyDocumentDetailCache($id);

        $document = Document::with([
            'items',
            'payments.payment_method_type',
            'payments.global_payment',
            'payments.payment_file',
            'state_type',
            'document_type',
            'user',
            'seller',
            'person.identity_document_type',
        ])->findOrFail($id);

        DocumentFiscalController::authorizeDocument($document);
        return new DocumentResource($document);
    }

    /**
     * Elimina claves de caché obsoletas del detalle (respuestas serializadas sin ítems).
     */
    protected function forgetLegacyDocumentDetailCache($id): void
    {
        foreach ([
            "document_detail_{$id}",
            "document_detail_v2_{$id}",
            "document_detail_v3_{$id}",
        ] as $cacheKey) {
            CacheHelper::forget(['document_detail'], $cacheKey);
        }
    }


    /**
     *
     * Generar cpe
     *
     * @param  DocumentRequest $request
     * @return array
     */
    public function store(DocumentRequest $request)
    {
        try
        {
            // Validar restricciones de plan ANTES de crear el documento
            $exceed_limit = (new DocumentHelper)->exceedLimitDocuments();
            if($exceed_limit['success']) {
                return [
                    'success' => false,
                    'message' => $exceed_limit['message']
                ];
            }
            $validate = $this->validateDocument($request);
            if (!$validate['success']) return $validate;

            if(!$this->validationOpenCash($request)) return $this->generalResponse(false, 'Ocurrió un error: Caja seleccionada en métodos de pago se encuentra cerrada');


            $data = $request->all();
            if (empty($data['source_module'])) {
                $data['source_module'] = 'WEB';
            }

            $res = $this->storeWithData($data, true);
            $document_id = $res['data']['id'];
            $this->associateDispatchesToDocument($request, $document_id);
            $this->associateSaleNoteToDocument($request, $document_id);

            return $res;
        }
        catch(\Illuminate\Validation\ValidationException | \Symfony\Component\HttpKernel\Exception\HttpException $e) { throw $e; }
        catch(Exception $e)
        {
            $this->generalWriteErrorLog($e);

            return $this->generalResponse(false, 'Ocurrió un error: '.$e->getMessage());
        }
    }

    public function validationOpenCash($request)
    {
        // busca una caja chica en el array de pagos
        $find_cash = array_search('cash', array_column($request->payments ?? [],'payment_destination_id'), true);
        // si ha seleccionado una caja chica
        if($find_cash !== false) {
            // no hay id de la caja seleccionada por lo que si es abierta una nueva será seleccionada como destino
            $cash = Cash::where([['user_id', auth()->user()->id],['state', true]])->first();
            if(!$cash){
                return false;
            }
        }
        return true;
    }


    /**
     * Validaciones previas al proceso de facturacion
     *
     * @param array $request
     * @return array
     */
    public function validateDocument($request)
    {

        return [
            'success' => true,
            'message' => ''
        ];

    }

    /**
     * Guarda los datos del hijo para el proceso de suscripcion. #952
     * Toma el valor de nota de venta y lo pasa para la boleta/factura
     *
     * @param $data
     */
    public static function setChildrenToData(&$data)
    {
        $request = request();
        if (
            $request != null &&
            $request->has('sale_note_id') &&
            $request->sale_note_id
        ) {
            $saleNote = SaleNote::find($request->sale_note_id);
            if ($saleNote != null && isset($data['customer'])) {
                $customer = $data['customer'];
                $customerNote = (array)$saleNote->customer;
                if (isset($customerNote['children'])) {
                    $customer['children'] = (array)$customerNote['children'];
                }
                $data['customer'] = $customer;
                $data['grade'] = $saleNote->getGrade();
                $data['section'] = $saleNote->getSection();
            }
        }
    }
    private function aplicarItineranciaSiCorresponde(array &$data)
    {
        $is_itinerant = (int) ($data['is_itinerant'] ?? 0);

        if (
            ($data['invoice']['operation_type_id'] ?? null) === '0101' &&
            $is_itinerant === 1
        ) {
            $data['legends'][] = [
                'code' => '2005',
                'value' => 'Venta realizada por emisor itinerante',
            ];

            // Campos a copiar del cliente al establecimiento
            // $fields = ['address', 'department_id', 'province_id', 'district_id', 'department', 'province', 'district'];

            // foreach ($fields as $field) {
            //     if (isset($data['customer'][$field])) {
            //         $data['establishment'][$field] = $data['customer'][$field];
            //     }
            // }

            // // Establecer claves directas
            // $data['establishment_address'] = $data['customer']['address'];
            // $data['establishment_department_id'] = $data['customer']['department_id'];
            // $data['establishment_province_id'] = $data['customer']['province_id'];
            // $data['establishment_district_id'] = $data['customer']['district_id'];
        }

        $data['is_itinerant'] = $is_itinerant === 1;
    }

    /**
     * @param array $data
     *
     * @return array
     * @throws \Throwable
     */
        public function storeWithData($data, bool $webExportInvoices = false)
        {
            $this->aplicarItineranciaSiCorresponde($data);
            self::setChildrenToData($data);
            $fact = DB::connection('tenant')->transaction(function () use ($data, $webExportInvoices) {
                $facturalo = new Facturalo();
                if ($webExportInvoices) $facturalo->forWebDocuments();
                $facturalo->save($data);
                $facturalo->createPdf();
                return $facturalo;
            });

            $document = $fact->getDocument();
            $response = $fact->getResponse();
            return [
                'success' => true,
                'message' => 'Venta guardada.',
                'data' => [
                    'id' => $document->id,
                    ...\App\Services\ThirdPartyInvoicePolicy::view($document),
                    ...\App\Services\SpecialTaxRegimePolicy::view($document),
                    'note_refunds' => \App\Services\Fiscal\NoteRefund::view($document),
                    'note_adjustments' => \App\Services\Fiscal\NoteAdjustment::view($document),
                    'number_full' => $document->number_full,
                    'response' => $response,
                    'iva_retention' => \App\Services\Fiscal\IvaRetentionService::view($document),
                    'islr_retention' => \App\Services\Fiscal\IslrRetentionService::view($document),
                    'fiscal_emission' => \App\Services\Fiscal\DocumentEmissionView::forDocument($document),
                    'email_delivery' => \App\Services\Fiscal\HkaMail::view($document),
                    'pdf_downloads' => \App\Services\Fiscal\HkaPdf::view($document, false),
                ],
                'links' => [
                    'print_ticket' => url('')."/print/document/{$document->external_id}/ticket"
                ]
            ];
        }

    private function associateSaleNoteToDocument(Request $request, int $documentId)
    {
        if ($request->sale_note_id) {
            SaleNote::where('id', $request->sale_note_id)
                ->update(['document_id' => $documentId]);
        }

        //notas de venta relacionadas cuando se genera cpe desde multiples nv
        $notes = $request->sale_notes_relateds;

        if ($notes) {

            foreach ($notes as $note) {

                $sale_note_id = $note['id'] ?? null;

                if ($sale_note_id) {

                    $sale_note = SaleNote::find($sale_note_id);

                    if (!empty($sale_note)) {
                        $sale_note->document_id = $documentId;
                        $sale_note->push();
                    }

                }

                // $noteArray = explode('-', $note);
                // if (count($noteArray) === 2) {
                //     $sale_note = SaleNote::where([
                //                                      'series'=> $noteArray[0],
                //                                      'number'=> $noteArray[1],
                //                                  ])->first();
                //     if(!empty($sale_note)) {
                //         $sale_note->document_id = $documentId;
                //         $sale_note->push();
                //     }
                // }
            }
        }
    }

    private function associateDispatchesToDocument(Request $request, int $documentId)
    {
        $dispatches_relateds = $request->dispatches_relateds;
        if (!$dispatches_relateds) return;
        $invoice = Document::findOrFail($documentId);
        foreach ($dispatches_relateds as $reference) {
            $parts = \App\Services\Fiscal\FiscalIdentity::parseNumberFull((string) $reference);
            if ($parts === null) continue;
            $dispatch = Dispatch::where('establishment_id', $invoice->establishment_id)
                ->where('fiscal_environment', $invoice->fiscal_environment)
                ->where('document_type_id', '09')
                ->where('series', \App\Services\SeriesNumbering::normalizeCode($parts[0]))
                ->where('number', $parts[1])->first();
            if ($dispatch) {
                $dispatch->update(['reference_document_id' => $documentId]);
                (new Facturalo())->createPdf($dispatch, 'dispatch', 'a4');
            }
        }
    }

    public function edit($documentId)
    {
        $document = Document::findOrFail($documentId);
        DocumentFiscalController::authorizeDocument($document);
        \App\Services\Fiscal\DocumentEditPolicy::assertEditable($document);
        if (auth()->user()->type == 'integrator') {
            return redirect('/documents');
        }
        $configuration = Configuration::first();
        $is_contingency = 0;
        $isUpdate = true;
        return view('tenant.documents.form', compact('is_contingency', 'configuration', 'documentId', 'isUpdate'));
    }

    /**
     * @param \App\Http\Requests\Tenant\DocumentUpdateRequest $request
     * @param                                                 $id
     *
     * @return array
     * @throws \Throwable
     */
    public function update(DocumentUpdateRequest $request, $id)
    {

        DocumentFiscalController::authorizeDocument(Document::findOrFail($id));
        $validate = $this->validateDocument($request);
        if (!$validate['success']) return $validate;

        $fact = DB::connection('tenant')->transaction(function () use ($request, $id) {
            $facturalo = (new Facturalo())->forWebDocuments();
            $facturalo->update($request->all(), $id);
            $facturalo->createPdf();

            return $facturalo;
        });

        $document = $fact->getDocument();
        $response = $fact->getResponse();
        $edit = \App\Services\Fiscal\DocumentEditPolicy::view($document);

        return [
            'success' => true,
            'message' => 'Factura actualizada. Los cobros registrados se conservaron. El envío HKA se realiza desde Enviar HKA.',
            'data' => array_merge($edit, \App\Services\ThirdPartyInvoicePolicy::view($document), \App\Services\SpecialTaxRegimePolicy::view($document), [
                'id' => $document->id,
                'is_editable' => $edit['can_edit'],
                'iva_retention' => \App\Services\Fiscal\IvaRetentionService::view($document),
                'islr_retention' => \App\Services\Fiscal\IslrRetentionService::view($document),
                    'fiscal_emission' => \App\Services\Fiscal\DocumentEmissionView::forDocument($document),
                'response' => $response,
            ]),
        ];
    }

    public function show($documentId)
    {
        $document = Document::with(['items', 'emission', 'received_retentions', 'guarantee_fund'])->findOrFail($documentId);
        DocumentFiscalController::authorizeDocument($document);
        foreach ($document->items as &$item) {
            $discounts = [];
            if($item->discounts) {
                foreach ($item->discounts as $discount) {
                    $discount_type = ChargeDiscountType::query()->find($discount->discount_type_id);
                    $discounts[] = [
                        'amount' => $discount->amount,
                        'base' => $discount->base,
                        'description' => $discount->description,
                        'discount_type_id' => $discount->discount_type_id,
                        'factor' => $discount->factor,
                        'percentage' => $discount->factor * 100,
                        'is_amount' => false,
                        'discount_type' => $discount_type
                    ];
                }
            }
            $item->discounts = $discounts;
        }

        return response()->json([
            'data' => array_merge($document->toArray(), \App\Services\Fiscal\DocumentEditPolicy::view($document), \App\Services\ThirdPartyInvoicePolicy::view($document), \App\Services\SpecialTaxRegimePolicy::view($document), ['iva_retention' => \App\Services\Fiscal\IvaRetentionService::view($document), 'islr_retention'=>\App\Services\Fiscal\IslrRetentionService::view($document),
                    'fiscal_emission' => \App\Services\Fiscal\DocumentEmissionView::forDocument($document)]),
            'success' => true,
        ], 200);
    }

    public function reStore($document_id)
    {
        $fact = DB::connection('tenant')->transaction(function () use ($document_id) {
            $document = Document::find($document_id);

            $type = 'invoice';
            if ($document->document_type_id === '07') {
                $type = 'credit';
            }
            if ($document->document_type_id === '08') {
                $type = 'debit';
            }

            $facturalo = new Facturalo();
            $facturalo->setDocument($document);
            $facturalo->setType($type);
            $facturalo->updateState('01');
            $facturalo->createPdf($document, $type, 'ticket');
        });

//        $document = $fact->getDocument();
//        $response = $fact->getResponse();

        return [
            'success' => true,
            'message' => 'El documento se volvio a generar.',
        ];
    }

    public function email(DocumentEmailRequest $request)
    {
        $document = Document::findOrFail($request->input('id'));
        DocumentFiscalController::authorizeDocument($document);
        if (\App\Services\Fiscal\HkaMail::applies($document)) {
            if (!$request->filled('request_id') && !$request->boolean('resend')
                && ($delivery = \App\Services\Fiscal\HkaMail::automaticDelivery($document, (array) $request->input('recipients', [])))) {
                return ['success' => $delivery['status'] === 'accepted', 'message' => $delivery['message'], 'email_delivery' => $delivery];
            }
            $request->validate(['request_id' => 'required|uuid']);
            $delivery = app(\App\Services\Fiscal\HkaMail::class)->send($document,
                $request->input('recipients'), $request->input('request_id'), $request->boolean('resend'));
            return ['success' => $delivery['status'] === 'accepted', 'message' => $delivery['message'], 'email_delivery' => $delivery];
        }
        $company = Company::active();
        EmailController::SendMail(implode(',', $request->input('recipients')),
            new DocumentEmail($company, $document), $document->id, 1);
        return ['success' => true, 'message' => 'El correo fue enviado satisfactoriamente.'];
    }

    public function searchCustomerById(Request $request, $id)
    {

        $customers = Person::with('addresses')->whereType('customers')
            ->whereSalesIdentityActive(\App\Services\ExportInvoicePolicy::isExport($request->operation_type_id))
            ->where('id', $id)
            ->get()->transform(function ($row) {
                /** @var  Person $row */
                return $row->getCollectionData(true);
                /* Movido al modelo */
                return [
                    'id' => $row->id,
                    'description' => $row->number . ' - ' . $row->name,
                    'name' => $row->name,
                    'number' => $row->number,
                    'identity_document_type_id' => $row->identity_document_type_id,
                    'identity_document_type_code' => $row->identity_document_type->code,
                    'addresses' => $row->addresses,
                    'address' => $row->address
                ];
            });

        return compact('customers');
    }

    public function getIdentityDocumentTypeId($document_type_id, $operation_type_id)
    {
        // ######## INICIO POLITICA IDENTIDAD ACTIVA EN VENTAS ########
        return \App\Services\SalesCustomerIdentityPolicy::activeIdentityTypeIds(\App\Services\ExportInvoicePolicy::isExport($operation_type_id));
        // ######## FIN POLITICA IDENTIDAD ACTIVA EN VENTAS ########
    }

    public function searchThirdParties(Request $request)
    {
        $request->validate(['input' => 'nullable|string|max:100']);
        if (!\App\Services\ExportInvoicePolicy::available(Company::firstOrFail())) {
            \App\Services\Fiscal\FiscalAmounts::error('third_party_id', 'La facturación por terceros requiere Medios digitales y DEMO.');
        }
        $input = trim((string) $request->input('input', ''));
        $customers = Person::whereType('customers')->where('enabled', true)->where('is_third_party', true)
            ->where('country_id', 'VE')->whereFilterCustomerBySeller('customers')
            ->when($input !== '', fn ($query) => $query->where(fn ($q) => $q->where('name', 'like', '%'.$input.'%')->orWhere('third_party_rif', 'like', '%'.\App\Support\System\Rif::normalize($input).'%')))
            ->orderBy('name')->limit(20)->get()->map(fn ($person) => $person->only(['id','name','third_party_rif','third_party_activity','address','email']));
        return compact('customers');
    }

    public function changeToRegisteredStatus($document_id)
    {
        $document = Document::find($document_id);
        if ($document->state_type_id === '01') {
            $document->state_type_id = '05';
            $document->save();

            return [
                'success' => true,
                'message' => 'El estado del documento fue actualizado.',
            ];
        }
    }

    public function import(Request $request)
    {
        if ($request->hasFile('file')) {
            try {
                $import = new DocumentsImport();
                $import->import($request->file('file'), null, Excel::XLSX);
                $data = $import->getData();
                return [
                    'success' => true,
                    'message' => __('app.actions.upload.success'),
                    'data' => $data
                ];
            } catch (Exception $e) {
                return [
                    'success' => false,
                    'message' => $e->getMessage()
                ];
            }
        }
        return [
            'success' => false,
            'message' => __('app.actions.upload.error'),
        ];
    }

    public function importTwoFormat(Request $request)
    {
        if ($request->hasFile('file')) {
            try {
                $import = new DocumentsImportTwoFormat();
                $import->import($request->file('file'), null, Excel::XLSX);
                $data = $import->getData();
                return [
                    'success' => true,
                    'message' => __('app.actions.upload.success'),
                    'data' => $data
                ];
            } catch (Exception $e) {
                return [
                    'success' => false,
                    'message' => $e->getMessage()
                ];
            }
        }
        return [
            'success' => false,
            'message' => __('app.actions.upload.error'),
        ];
    }

    public function messageLockedEmission()
    {

        $exceed_limit = (new DocumentHelper)->exceedLimitDocuments();

        if ($exceed_limit['success']) {
            return [
                'success' => false,
                'message' => $exceed_limit['message'],
            ];
        }

        // $configuration = Configuration::first();
        // $quantity_documents = Document::count();
        // $quantity_documents = $configuration->quantity_documents;

        // if($configuration->limit_documents !== 0 && ($quantity_documents > $configuration->limit_documents))
        //     return [
        //         'success' => false,
        //         'message' => 'Alcanzó el límite permitido para la emisión de comprobantes',
        //     ];


        return [
            'success' => true,
            'message' => '',
        ];
    }

    public function updateCustomFields(Request $request)
    {
        $request->validate([
            'id' => 'required|integer',
            'custom_fields_data' => 'nullable|array'
        ]);

        $Document = Document::findOrFail($request->input('id'));
        $Document->custom_fields_data = $request->input('custom_fields_data', []);
        $Document->save();

        return [
            'success' => true,
            'data' => $Document->custom_fields_data
        ];
    }

    public function getRecords($request)
    {
        $d_end = $request->d_end;
        $d_start = $request->d_start;
        $date_of_issue = $request->date_of_issue;
        $document_type_id = $request->document_type_id;
        $state_type_id = $request->state_type_id;
        $number = $request->number;
        $series = $request->series;
        $pending_payment = ($request->pending_payment == "true") ? true : false;
        $customer_id = $request->customer_id;
        $item_id = $request->item_id;
        $category_id = $request->category_id;
        $purchase_order = $request->purchase_order;
        $guides = $request->guides;
        $plate_numbers = $request->plate_numbers;
        $observations = $request->observations;
        $custom_fiels = $request->custom_fiels;

//        return $observations;
        $records = Document::query();

        if ($d_start && $d_end) {
            $records->whereBetween('date_of_issue', [$d_start, $d_end]);
        }
        if ($date_of_issue) {
            $records = Document::where('date_of_issue', 'like', '%' . $date_of_issue . '%');
        }
        /** @var Builder $records */
        if ($document_type_id) {
            $records->where('document_type_id', 'like', '%' . $document_type_id . '%');
        }
        $records->whereFiscalIdentifiers($series, $number, $request->control_number);
        if ($state_type_id) {
            $records->where('state_type_id', 'like', '%' . $state_type_id . '%');
        }
        if ($purchase_order) {
            $records->where('purchase_order', $purchase_order);
        }
        $records->whereTypeUser()->latest();

        if ($pending_payment) {
            $records->where('total_canceled', false);
        }

        if ($customer_id) {
            $records->where('customer_id', $customer_id);
        }

        if ($item_id) {
            $records->whereHas('items', function ($query) use ($item_id) {
                $query->where('item_id', $item_id);
            });
        }

        if ($category_id) {
            $records->whereHas('items', function ($query) use ($category_id) {
                $query->whereHas('relation_item', function ($q) use ($category_id) {
                    $q->where('category_id', $category_id);
                });
            });
        }
        if (!empty($guides)) {
            $records->where('guides', 'like', DB::raw("%\"number\":\"%") . $guides . DB::raw("%\"%"));
        }
        if ($plate_numbers) {
            $records->where('plate_number', 'like', '%' . $plate_numbers . '%');
        }

        if ($observations) {
            $records = $records->where('additional_information', 'like', '%' . $observations . '%');
        }

        return $records->with('fiscal_data');
    }

    public function data_table()
    {

        $customers = $this->table('customers');
        $items = $this->getItems();
        $categories = Category::orderBy('name')->get();
        $state_types = StateType::get();
        $document_types = DocumentType::whereIn('id', ['01', '03', '07', '08'])->get();
        // Series filtradas por contexto (oculta dedicadas / restringe al grupo activo). Ver SeriesResolver.
        $series = app(SeriesResolver::class)
            ->applyContext(Series::whereIn('document_type_id', ['01', '03', '07', '08']))
            ->get();
        $establishments = Establishment::where('id', auth()->user()->establishment_id)->get();// Establishment::all();

        return compact('customers', 'document_types', 'series', 'establishments', 'state_types', 'items', 'categories');

    }


    public function getItems()
    {

        $items = Item::orderBy('description')->take(20)->get()->transform(function ($row) {
            return [
                'id' => $row->id,
                'description' => ($row->internal_id) ? "{$row->internal_id} - {$row->description}" : $row->description,
            ];
        });

        return $items;

    }


    public function getDataTableItem(Request $request)
    {

        $items = Item::where('description', 'like', "%{$request->input}%")
            ->orWhere('internal_id', 'like', "%{$request->input}%")
            ->orderBy('description')
            ->get()->transform(function ($row) {
                return [
                    'id' => $row->id,
                    'description' => ($row->internal_id) ? "{$row->internal_id} - {$row->description}" : $row->description,
                ];
            });

        return $items;

    }


    private function updateMaxCountPayments($value)
    {
        if ($value > $this->max_count_payment) {
            $this->max_count_payment = $value;
        }
        // $this->max_count_payment = 20 ;//( $value > $this->max_count_payment) ? $value : $this->$max_count_payment;
    }

    private function transformReportPayment($resource)
    {

        $records = $resource->transform(function ($row) {

            $total_paid = collect($row->payments)->sum('payment');
            $total = $row->total;
            $total_difference = round($total - $total_paid, 2);

            $this->updateMaxCountPayments($row->payments->count());

            return (object)[

                'id' => $row->id,
                'ruc' => $row->customer->number,
                // 'date' =>  $row->date_of_issue->format('Y-m-d'),
                // 'date' =>  $row->date_of_issue,
                'date' => $row->date_of_issue->format('d/m/Y'),
                'invoice' => $row->number_full,
                'comercial_name' => $row->customer->trade_name,
                'business_name' => $row->customer->name,
                'zone' => $row->customer->department->description,
                'total' => number_format($row->total, 2, ".", ""),

                'payments' => $row->payments,

                /*'payment1' =>  ( isset($row->payments[0]) ) ?  number_format($row->payments[0]->payment, 2) : '',
                'payment2' =>  ( isset($row->payments[1]) ) ?  number_format($row->payments[1]->payment, 2) : '',
                'payment3' =>   ( isset($row->payments[2]) ) ?  number_format($row->payments[2]->payment, 2) : '',
                'payment4' =>   ( isset($row->payments[3]) ) ?  number_format($row->payments[3]->payment, 2) : '', */

                'balance' => $total_difference,
                'person_type' => isset($row->person->person_type->description) ? $row->person->person_type->description : '',
                'department' => $row->customer->department->description,
                'district' => $row->customer->district->description,

                /*'reference1' => ( isset($row->payments[0]) ) ?  $row->payments[0]->reference : '',
                'reference2' =>  ( isset($row->payments[1]) ) ?  $row->payments[1]->reference : '',
                'reference3' =>  ( isset($row->payments[2]) ) ?  $row->payments[2]->reference : '',
                'reference4' =>  ( isset($row->payments[3]) ) ?  $row->payments[3]->reference : '', */
            ];
        });

        return $records;
    }

    public function report_payments(Request $request)
    {
        // $month_format = Carbon::parse($month)->format('m');

        if ($request->anulled == 'true') {
            $records = Document::whereBetween('date_of_issue', [$request->date_start, $request->date_end])->get();
        } else {
            $records = Document::whereBetween('date_of_issue', [$request->date_start, $request->date_end])->where('state_type_id', '!=', '11')->get();
        }

        $source = $this->transformReportPayment($records);

        return (new PaymentExport)
            ->records($source)
            ->payment_count($this->max_count_payment)
            ->download('Reporte_Pagos_' . Carbon::now() . '.xlsx');

    }

    public function destroyDocument($document_id)
    {
        try {

            DB::connection('tenant')->transaction(function () use ($document_id) {

                $record = Document::findOrFail($document_id);
                $this->deleteAllPayments($record->payments);
                $record->delete();

            });

            return [
                'success' => true,
                'message' => 'Documento eliminado con éxito'
            ];

        } catch (Exception $e) {

            return ($e->getCode() == '23000') ? ['success' => false, 'message' => 'El Documento esta siendo usada por otros registros, no puede eliminar'] : ['success' => false, 'message' => 'Error inesperado, no se pudo eliminar el Documento'];

        }


    }

    public function storeCategories(CategoryRequest $request)
    {
        $id = $request->input('id');
        $category = Category::firstOrNew(['id' => $id]);
        $category->fill($request->all());
        $category->save();


        return [
            'success' => true,
            'message' => ($id) ? 'Categoría editada con éxito' : 'Categoría registrada con éxito',
            'data' => $category

        ];
    }

    public function storeBrands(BrandRequest $request)
    {
        $id = $request->input('id');
        $brand = Brand::firstOrNew(['id' => $id]);
        $brand->fill($request->all());
        $brand->save();


        return [
            'success' => true,
            'message' => ($id) ? 'Marca editada con éxito' : 'Marca registrada con éxito',
            'data' => $brand
        ];
    }

    public function searchExternalId(Request $request)
    {
        return response()->json(Document::where('external_id', $request->external_id)->first());
    }

    public function importExcelFormat(Request $request)
    {
        if ($request->hasFile('file')) {
            try {
                $import = new DocumentImportExcelFormat();
                $import->import($request->file('file'), null, Excel::XLSX);
                $data = $import->getData();

                return [
                    'success' => true,
                    'message' =>  'Se importaron '.$data['registered'].' de '.$data['total_records'].' registros',
                    'data' => $data
                ];
            } catch (Exception $e) {
                return [
                    'success' => false,
                    'message' =>  $e->getMessage()
                ];
            }
        }
        return [
            'success' => false,
            'message' =>  __('app.actions.upload.error'),
        ];
    }

    public function importExcelTables()
    {
        // ########## INICIO CAMBIO SOLO FACTURAS Y NOTAS DE VENTA
        $document_types = DocumentType::query()
            ->whereIn('id', ['01'])
            ->get();

        $series = app(SeriesResolver::class)->applyContext(Series::query()
            ->whereIn('document_type_id', ['01'])
            ->where('establishment_id', auth()->user()->establishment_id))
            ->get();
        // ######### FIN CAMBIO SOLO FACTURAS Y NOTAS DE VENTA

        return [
            'document_types' => $document_types,
            'series' => $series,
        ];
    }

    public function preview(DocumentRequest $request)
    {
        $validate = $this->validateDocument($request);
        if (!$validate['success']) return $validate;

        $facturalo = new Facturalo();
        $inputs = $request->all();
        if (!empty($inputs['is_itinerant']) && $inputs['is_itinerant'] === true) {
            if (isset($inputs['customer']['address'])) {
                $inputs['establishment']['address'] = $inputs['customer']['address'];
                $inputs['establishment']['province_id'] = $inputs['customer']['province_id'];
                $inputs['establishment']['province'] = $inputs['customer']['province'];
                $inputs['establishment']['district_id'] = $inputs['customer']['district_id'];
                $inputs['establishment']['district'] = $inputs['customer']['district'];
                $inputs['establishment']['department_id'] = $inputs['customer']['department_id'];
                $inputs['establishment']['department'] = $inputs['customer']['department'];
            }
        }
        $facturalo->setActions(array_key_exists('actions', $inputs) ? $inputs['actions'] : []);

        $document = new Document($inputs);

        $facturalo->setPaymentsPreview($document, $inputs['payments']);
        $facturalo->setFeePreview($document, $inputs['fee']);

        foreach ($inputs['items'] as $row) {
            $item = new \App\Models\Tenant\DocumentItem($row);
            $document->items[] = $item;
        }

        if ($inputs['hotel']) {
            $hotel = new \Modules\BusinessTurn\Models\DocumentHotel($inputs['hotel']);
            $document->hotel = $hotel;
        }

        if ($inputs['transport']) {
            $transport = new \Modules\BusinessTurn\Models\DocumentTransport($inputs['transport']);
            $document->transport = $transport;
        }

        $invoice = new \App\Models\Tenant\Invoice($inputs['invoice']);
        $document->invoice = $invoice;

        return $facturalo->previewPdf($document, $inputs['type']);
    }

}

// ######## FIN MIGRACIÓN MONEDA VENEZUELA ########
