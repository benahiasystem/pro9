<?php
namespace App\Http\Controllers\Tenant;

use App\CoreFacturalo\Helpers\Storage\StorageDocument;
use App\Http\Controllers\Controller;
use App\CoreFacturalo\Facturalo;
use App\Http\Controllers\Tenant\QuotationController;
use App\CoreFacturalo\Template;
use App\Models\Tenant\Company;
use App\Models\Tenant\Configuration;
use Mpdf\Mpdf;
use Exception;
use Illuminate\Support\Facades\Storage;
use App\Services\LocalFiscalDocumentPolicy;

class DownloadController extends Controller
{
    use StorageDocument;

    private function digitalPdf($document, string $format, bool $attachment)
    {
        $service = app(\App\Services\Fiscal\HkaPdf::class);
        $bytes = auth()->check() ? $service->download($document, $format) : $service->stored($document, $format);
        $filename = \App\Services\Fiscal\DocumentFileName::visible(app(\App\Services\Fiscal\HkaPdfStore::class)->filename($document)).($format === 'ticket' ? '-80mm' : '').'.pdf';
        return response($bytes, 200, ['Content-Type' => 'application/pdf',
            'Content-Disposition' => \Symfony\Component\HttpFoundation\HeaderUtils::makeDisposition($attachment ? 'attachment' : 'inline', $filename),
            'Cache-Control' => 'private, no-store', 'X-Content-Type-Options' => 'nosniff']);
    }

    public function downloadExternal($model, $type, $external_id, $format = null) {
        // ########## INICIO CAMBIO SIN XML CDR SUNAT
        if (LocalFiscalDocumentPolicy::enabled() && in_array($type, ['xml', 'cdr', 'cdr_xml'], true)) {
            abort(404);
        }
        // ######### FIN CAMBIO SIN XML CDR SUNAT
        $document_type = $model;
        $model = "App\\Models\\Tenant\\".ucfirst($model);
        $document = $model::where('external_id', $external_id)->first();

        if (!$document) throw new Exception("El código {$external_id} es inválido, no se encontró documento relacionado");

        if ($document instanceof \App\Models\Tenant\Document && \App\Services\Fiscal\HkaPdf::applies($document)
            && $type === 'pdf' && in_array($format ?? 'a4', ['a4', 'a5', 'ticket'], true)) {
            return $this->digitalPdf($document, $format ?? 'a4', true);
        }
        $type_pdf = $document_type;
        if ($type == 'pdf') {
            if ($document_type == 'document') {
                $type_pdf = 'invoice';
                if($document->document_type_id === '07') $type_pdf = 'credit';
                if($document->document_type_id === '08') $type_pdf = 'debit';
            }

            if ($document_type == 'document' && in_array($document->document_type_id, ['01'], true)) {
                if (trim(strip_tags(html_entity_decode($document->terms_condition ?? ''))) === '') {
                    $configuration = Configuration::select('terms_condition_sale')->first();
                    if ($configuration && trim(strip_tags(html_entity_decode($configuration->terms_condition_sale ?? ''))) !== '') {
                        $document->terms_condition = $configuration->terms_condition_sale;
                        $document->save();
                        $this->reloadPDF($document, $type_pdf, $format ?? 'a4');
                    }
                }
            }

            if ($format != null) {
                $this->reloadPDF($document, $type_pdf, $format);
            } else {
                // Validar la existencia física del PDF.
                // Si el formato es null y no existe en disco, forzar 'a4' y regenerar preventivamente con el tipo correcto.
                if (!$this->existFileInStorage($document->filename, 'pdf')) {
                    $format = 'a4';
                    $this->reloadPDF($document, $type_pdf, $format);
                }
            }
        }

        // Órdenes de entrega: siempre regenerar el PDF al descargar/imprimir para que tomen la plantilla actual (p. ej. marca de agua).
        if (
            isset($document->document_type_id)
            && $document->document_type_id === '09'
            && $type === 'pdf'
        ) {
            $this->reloadPDF($document, 'dispatch', $format ?? 'a4');
        }
        return $this->download($type, $document);
    }

    public function download($type, $document) {
        // ########## INICIO CAMBIO SIN XML CDR SUNAT
        if (LocalFiscalDocumentPolicy::enabled() && in_array($type, ['xml', 'cdr', 'cdr_xml'], true)) {
            abort(404);
        }
        // ######### FIN CAMBIO SIN XML CDR SUNAT
        if ($type === 'pdf' && $document instanceof \App\Models\Tenant\Document && \App\Services\Fiscal\HkaPdf::applies($document)) {
            return $this->digitalPdf($document, 'a4', true);
        }
        switch ($type) {
            case 'pdf':
                $folder = 'pdf';
                break;
            case 'xml':
                $folder = 'signed';
                break;
            case 'cdr_xml':
                $folder = 'cdr_xml';
                break;
            case 'cdr':
                $folder = 'cdr';
                break;
            case 'quotation':
                $folder = 'quotation';
                break;
            case 'sale_note':
                $folder = 'sale_note';
                break;

            default:
                throw new Exception('Tipo de archivo a descargar es inválido');
        }

        //borrar despues
        // solo desarrollo
        // $this->reloadPDF($document, 'dispatch', 'a4');
        // $temp = tempnam(sys_get_temp_dir(), 'pdf');
        // file_put_contents($temp, $this->getStorage($document->filename, 'pdf'));

        // return response()->file($temp);
        //borrar antes
        return $this->downloadStorage($document->filename, $folder);
    }

    /**
     * @param      $model
     * @param      $external_id
     * @param null $format
     *
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse
     * @throws \Exception
     */
    public function toPrint($model, $external_id, $format = 'a4') {
        $document_type = $model;

        // Ingresos y gastos (finanzas) viven en modulos y resuelven su propio PDF.
        // Se atienden aqui para exponerlos por la ruta publica print/* (con CORS), como cotizaciones.
        if ($document_type == 'income') {
            return app(\Modules\Finance\Http\Controllers\IncomeController::class)->toPrint($external_id, $format ?? 'a4');
        } elseif ($document_type == 'expense') {
            return app(\Modules\Expense\Http\Controllers\ExpenseController::class)->toPrint($external_id, $format ?? 'a4');
        }

        $model = "App\\Models\\Tenant\\".ucfirst($model);

        $document = $model::where('external_id', $external_id)->first();

        if (!$document) {
            throw new Exception("El código {$external_id} es inválido, no se encontro documento relacionado");
        }

        if ($document_type == 'quotation'){
            // Las cotizaciones tienen su propio controlador, si se generan por este medio, dará error
            $quotation = new QuotationController();
            return $quotation->toPrint($external_id,$format);
        }elseif($document_type =='salenote'){
            $saleNote = new SaleNoteController();
            return $saleNote->toPrint($external_id,$format);
        }
        if ($document instanceof \App\Models\Tenant\Document && \App\Services\Fiscal\HkaPdf::applies($document)
            && in_array($format ?? 'a4', ['a4', 'a5'], true)) {
            return $this->digitalPdf($document, $format ?? 'a4', false);
        }
        $type = 'invoice';
        if ($document_type == 'dispatch') {
            $type = 'dispatch';
        }
        if($document->document_type_id === '07') {
            $type = 'credit';
        }
        if($document->document_type_id === '08') {
            $type = 'debit';
        }

        if ($document instanceof \App\Models\Tenant\Document && \App\Services\Fiscal\HkaPdf::applies($document)
            && $format === 'ticket') {
            $bytes = (new Facturalo)->createPdf($document, $type, 'ticket', 'string');
            return response($bytes, 200, ['Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="ticket-80mm.pdf"', 'Cache-Control' => 'private, no-store']);
        }
        $this->reloadPDF($document, $type, $format);

        $temp = tempnam(sys_get_temp_dir(), 'pdf');

        file_put_contents($temp, $this->getStorage($document->filename, 'pdf'));

        /*
        $headers = [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="'.$document->filename.'.pdf'.'"'
        ];
        */

        return response()->file($temp, $this->generalPdfResponseFileHeaders($document->filename));
    }

    public function toTicket($model, $external_id, $format = null) {
        $model = "App\\Models\\Tenant\\".ucfirst($model);
        $document = $model::where('id', $external_id)->first();

        if (!$document) throw new Exception("El código {$external_id} es inválido, no se encontro documento relacionado");

        if ($format != null) return $this->reloadTicket($document, 'invoice', $format);

    }

    /**
     * Reload Ticket
     * @param  ModelTenant $document
     * @param  string $format
     * @return void
     */
    private function reloadTicket($document, $type, $format) {
        return (new Facturalo)->createPdf($document, $type, $format, 'html');
    }

    /**
     * Reload PDF
     * @param  ModelTenant $document
     * @param  string $format
     * @return void
     */
    private function reloadPDF($document, $type, $format) {
        (new Facturalo)->createPdf($document, $type, $format);
    }
}
