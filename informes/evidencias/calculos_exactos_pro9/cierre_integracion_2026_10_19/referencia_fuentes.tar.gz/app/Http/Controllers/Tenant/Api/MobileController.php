<?php

namespace App\Http\Controllers\Tenant\Api;

use App\Http\Controllers\Tenant\EmailController;
use Exception;
use Carbon\Carbon;
use App\Models\Tenant\Item;
use App\Models\Tenant\User;
use Illuminate\Http\Request;
use App\Models\Tenant\Person;
use App\Models\Tenant\Series;
use App\Services\SeriesResolver;
use App\Models\Tenant\Company;
use App\Models\Tenant\PaymentMethodType;
use App\Models\Tenant\Document;
use App\Models\Tenant\DocumentItem;
use App\Mail\Tenant\DocumentEmail;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Models\Tenant\Configuration;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Http\Requests\Tenant\PersonRequest;
use Modules\Item\Http\Requests\ItemRequest;
use Modules\Dashboard\Helpers\DashboardData;
use Modules\Finance\Helpers\UploadFileHelper;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Modules\Item\Http\Requests\ItemUpdateRequest;
use App\Models\Tenant\Catalogs\AffectationIgvType;
use App\Models\Tenant\Warehouse;
use Modules\Inventory\Models\ItemWarehouse;
use Modules\Finance\Traits\FinanceTrait;
use Modules\MobileApp\Models\AppConfiguration;
use Modules\Item\Models\{
    Category
};
use App\Http\Controllers\Tenant\ItemController as ItemWebController;
use App\Models\Tenant\Consigned;
use Modules\Dispatch\Models\DispatchAddress;
use App\Models\Tenant\PersonAddress;
use App\Models\Tenant\PriceLabel;
use App\Models\Tenant\SaleNote;
use Modules\QrApi\Http\Controllers\QrApiController;
use Modules\BusinessTurn\Models\BusinessTurn;
use Modules\MobileApp\Http\Controllers\Api\BankAccountController;

class MobileController extends Controller
{
    use  FinanceTrait;

    public function login(Request $request)
    {
        $credentials = request(['email', 'password']);
        if (!Auth::attempt($credentials)) {
            return [
                'success' => false,
                'message' => 'No Autorizado'
            ];
        }

        $company = Company::active();
        $configuration = Configuration::first();
        $business_turn_tap = BusinessTurn::where('value','tap')->first();

        $user = $request->user();
        $establishment = $user->establishment;
        return [
            'success' => true,
            'name' => $user->name,
            'email' => $user->email,
            'establishment_id' => auth()->user()->establishment->id,
            'seriedefault' => $user->series_id,
            'token' => $user->api_token,
            'restaurant_role_id' => $user->restaurant_role_id,
            'restaurant_role_code' => $user->restaurant_role_id ? $user->restaurant_role->code : null,
            'ruc' => $company->number,
            'app_logo' => $company->logo,
            'app_logo_base64' => '',//base64_encode(file_get_contents(config('app.url').'/storage/uploads/logos/'.$company->logo)),
            // El logo del establecimiento manda sobre el de la empresa. Ojo: aqui la ruta
            // ya viene completa (storage/uploads/logos/...), a diferencia de company->logo.
            'app_url_logo' => filled(optional($establishment)->logo)
                ? asset($establishment->logo)
                : Company::getAppUrlLogo(),
            'company' => [
                'name' => $company->name,
                'address' => auth()->user()->establishment->department->description.', '.auth()->user()->establishment->province->description.', '.auth()->user()->establishment->district->description.', '.auth()->user()->establishment->address,
                'phone' => auth()->user()->establishment->telephone,
                'email' => auth()->user()->establishment->email,
                'enable_list_product' => !$configuration->enable_list_product,
                'qr_api_enable_ws' => $configuration->qr_api_enable,
                'qr_api_url_ws' => $configuration->qr_api_url,
                'qr_api_key_ws' => $configuration->qr_api_apiKey,
                'url_logo' => ($company->logo)?asset('storage/uploads/logos/'.$company->logo):'',
                'logo_base64' => $company->logo ? 'data:image/png;base64,' . base64_encode(file_get_contents(public_path('storage/uploads/logos/' . $company->logo))) : '',
                'is_business_turn_tap' => ($business_turn_tap)?$business_turn_tap->active:0,
            ],
            'app_configuration' => $this->getAppConfiguration(),
            'pdf_configuration' => $this->getPdfConfiguration($configuration),
            'permission_edit_item_prices' => $user->permission_edit_item_prices,
            'sellerId' => $user->id,
        ];

    }


    /**
     *
     * Obtener configuracion para app
     *
     * @return array
     */
    public function getAppConfiguration()
    {
        return optional(AppConfiguration::first())->getRowResource();
    }

    /**
     *
     * Configuracion del PDF
     *
     * Solo se exponen las claves que realmente afectan el render de la plantilla
     * default/invoice_a4.blade.php. Las demas opciones de la pestania PDF aplican
     * a tickets, cotizaciones o etiquetas y no se envian a la app.
     *
     * @param  Configuration|null $configuration
     * @return array
     */
    public function getPdfConfiguration(?Configuration $configuration = null)
    {
        $configuration = $configuration ?: Configuration::first();

        if (!$configuration) {
            return [];
        }

        return [
            // Texto libre vigente del pie de página de ventas.
            'legend_footer_sale' => $configuration->legend_footer_sale,

            // Terminos y condiciones
            // se copia a $document->terms_condition (DocumentInput::196) e se imprime
            // en invoice_a4:1284
            'show_terms_condition' => (bool) $configuration->terms_condition_sale,
            'terms_condition_sale' => $configuration->terms_condition_sale,

            // Informacion que aparece en el PDF
            'show_bank_accounts_in_pdf' => (bool) $configuration->show_bank_accounts_in_pdf, // invoice_a4:1126
            // cuentas impresas en el pdf, mismo criterio de invoice_a4:15
            'bank_accounts' => $this->getBankAccountsForPdf(),
            'show_seller_in_pdf' => (bool) $configuration->show_seller_in_pdf, // invoice_a4:1262

            // Productos y contenido
            // las tres definen el valor de $row->name_product_pdf impreso en invoice_a4:724
            'show_pdf_name' => (bool) $configuration->show_pdf_name,
            'edit_name_product' => (bool) $configuration->edit_name_product,
            'item_name_pdf_description' => (bool) $configuration->item_name_pdf_description,

            // Decimales del precio unitario
            'change_decimal_quantity_unit_price_pdf' => (bool) $configuration->change_decimal_quantity_unit_price_pdf, // invoice_a4:835
            'decimal_quantity_unit_price_pdf' => (int) $configuration->decimal_quantity_unit_price_pdf, // invoice_a4:837

            // Comportamiento
            // TemplateHelper::canShowNewLineOnObservation() usado en invoice_a4:1117
            'print_new_line_to_observation' => (bool) $configuration->print_new_line_to_observation,
        ];
    }

    /**
     *
     * Cuentas bancarias que se imprimen en el pdf del comprobante
     *
     * Reutiliza el endpoint bank-accounts/for-pdf para no duplicar el criterio
     * (show_in_documents y establecimiento del usuario autenticado)
     *
     * @return array
     */
    public function getBankAccountsForPdf()
    {
        $response = app(BankAccountController::class)->forPdf();

        return $response['data']->resolve();
    }


    public function customers()
    {
        $customers = Person::whereType('customers')->whereSalesIdentityActive()->orderBy('name')->take(20)->get()->transform(function($row) {
            return [
                'id' => $row->id,
                'description' => $row->number.' - '.$row->name,
                'name' => $row->name,
                'number' => $row->number,
                'identity_document_type_id' => $row->identity_document_type_id,
                'identity_document_type_code' => $row->identity_document_type->code,
                'identity_document_type_description' => $row->identity_document_type->description,
                'address' => $row->address,
                'telephone' => $row->telephone,
                'country_id' => $row->country_id,
                'district_id' => $row->district_id,
                'email' => $row->email,
                'selected' => false,
                'addresses' => PersonAddress::where('person_id',$row->id)
                                ->get()
                                ->transform(function ($row) {
                                    $location_id = [$row->department_id,$row->province_id,$row->district_id];
                                    return [
                                        'id' => $row->id,
                                        'location_id' => $location_id,
                                        'address' => $row->address,
                                        'code' => $row->establishment_code,
                                        'has_consigned' => (bool)$row->has_consigned,
                                    ];
                                }),
            ];
        });

        return [
            'success' => true,
            'data' => array('customers' => $customers)
        ];

    }

    public function tables()
    {
        $affectation_igv_types = AffectationIgvType::whereActive()->get();
        /*$customers = Person::whereType('customers')->orderBy('name')->take(20)->get()->transform(function($row) {
            return [
                'id' => $row->id,
                'description' => $row->number.' - '.$row->name,
                'name' => $row->name,
                'number' => $row->number,
                'identity_document_type_id' => $row->identity_document_type_id,
                'identity_document_type_code' => $row->identity_document_type->code
            ];
        });*/
        $establishment_id = auth()->user()->establishment_id;
        $warehouse = Warehouse::where('establishment_id', $establishment_id)->first();
        $configuration =  Configuration::first();
        $decimal_units = (int)$configuration->decimal_quantity;

        $items = Item::with(['brand', 'category', 'item_unit_types.prices.priceLabel'])
                    ->whereWarehouse()
                    ->whereHasInternalId()
                    // ->whereNotIsSet()
                    ->whereIsActive()
                    ->orderBy('description')
                    ->take(20)
                    ->get()
                    ->transform(function($row) use($warehouse, $configuration, $decimal_units){
                        $full_description = ($row->internal_id)?$row->internal_id.' - '.$row->description:$row->description;

                        return [
                            'id' => $row->id,
                            'item_id' => $row->id,
                            'name' => $row->name,
                            'full_description' => $full_description,
                            'description' => $row->description,
                            'currency_type_id' => $row->currency_type_id,
                            'internal_id' => $row->internal_id,
                            'item_code' => $row->item_code,
                            'currency_type_symbol' => $row->currency_type->symbol,
                            'sale_unit_price' => $row->generalApplyNumberFormat($row->sale_unit_price),
                            // 'sale_unit_price' => number_format($row->sale_unit_price, 2),
                            'price' => $row->sale_unit_price,
                            'purchase_unit_price' => $row->purchase_unit_price,
                            'unit_type_id' => $row->unit_type_id,
                            'sale_affectation_igv_type_id' => $row->sale_affectation_igv_type_id,
                            'purchase_affectation_igv_type_id' => $row->purchase_affectation_igv_type_id,
                            'calculate_quantity' => (bool) $row->calculate_quantity,
                            'has_igv' => (bool) $row->has_igv,
                            'is_set' => (bool) $row->is_set,
                            'lots' => $row->lots,
                            'IdLoteSelected' => optional($row->item)->IdLoteSelected,
                            'aux_quantity' => 1,
                            'brand' => $row->brand->name,
                            'category' => $row->brand->name,
                            'item_unit_types' => $this->transformMobileItemUnitTypes($row->item_unit_types, $decimal_units),
                            'stock' => $row->getWarehouseCurrentStock($warehouse),
                            // 'stock' => $row->unit_type_id!='SERV' ? ItemWarehouse::where([['item_id', $row->id],['warehouse_id', $warehouse->id]])->first()->stock : '0',
                            'image' => $row->image != "imagen-no-disponible.jpg" ? url("/storage/uploads/items/" . $row->image) : url("/logo/" . $row->image),
                            'warehouses' => Item::transformWarehousesForApi($row->warehouses),
                            'favorite' => (bool) $row->favorite,
                        ];
                    });


        return [
            'success' => true,
            'data' => [
                'items' => $items,
                'affectation_types' => $affectation_igv_types,
                'categories' => Category::filterForTables()->get()
            ]
        ];

    }


    public function getSeries()
    {

        return app(SeriesResolver::class)->applyContext(
                    Series::where('establishment_id', auth()->user()->establishment_id)
                    ->whereIn('document_type_id', ['01', '09'])
                )->get()
                    ->transform(function($row) {
                        return $row->getApiRowResource();
                    });

    }

    public function getSeriesDispatch()
    {

        return app(SeriesResolver::class)->applyContext(Series::whereIn('document_type_id', ['09']))
                    ->get()
                    ->transform(function($row) {
                        return $row->getApiRowResource();
                    });
    }

    public function getPaymentmethod(){

        $payment_method_type = PaymentMethodType::active()->get();
        $payment_destinations = $this->getPaymentDestinations();
        return compact( 'payment_method_type','payment_destinations');
    }


    public function document_email(Request $request)
    {
        $company = Company::active();
        $document = Document::find($request->id);
        $customer_email = $request->email;

        $email = $customer_email;
        $mailable =new DocumentEmail($company, $document);
        $id =  $request->id;
        $sendIt = EmailController::SendMail($email, $mailable, $id, 1);
        /*
        Configuration::setConfigSmtpMail();
        $array_email = explode(',', $customer_email);
        if (count($array_email) > 1) {
            foreach ($array_email as $email_to) {
                $email_to = trim($email_to);
                if(!empty($email_to)) {
                    Mail::to($email_to)->send(new DocumentEmail($company, $document));
                }
            }
        } else {
            Mail::to($customer_email)->send(new DocumentEmail($company, $document));
        }
        */

        return [
            'success' => true,
            'message'=> 'Email enviado correctamente.'
        ];
    }


    public function item(ItemRequest $request)
    {

        $row = DB::connection('tenant')->transaction(function () use ($request) {

            $row = new Item();
            $row->item_type_id = '01';
            $row->fill($request->all());
            $temp_path = $request->input('temp_path');

            if($temp_path) {

                UploadFileHelper::checkIfValidFile($request->input('image'), $temp_path, true);

                $directory = 'public'.DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR.'items'.DIRECTORY_SEPARATOR;

                $file_name_old = $request->input('image');
                $file_name_old_array = explode('.', $file_name_old);
                $file_content = file_get_contents($temp_path);
                $datenow = date('YmdHis');
                $file_name = Str::slug($row->description).'-'.$datenow.'.'.$file_name_old_array[1];
                Storage::put($directory.$file_name, $file_content);
                $row->image = $file_name;

                //--- IMAGE SIZE MEDIUM
                $image = \Image::make($temp_path);
                $file_name = Str::slug($row->description).'-'.$datenow.'_medium'.'.'.$file_name_old_array[1];
                $image->resize(512, null, function ($constraint) {
                    $constraint->aspectRatio();
                    $constraint->upsize();
                });
                Storage::put($directory.$file_name,  (string) $image->encode('jpg', 30));
                $row->image_medium = $file_name;

                //--- IMAGE SIZE SMALL
                $image = \Image::make($temp_path);
                $file_name = Str::slug($row->description).'-'.$datenow.'_small'.'.'.$file_name_old_array[1];
                $image->resize(256, null, function ($constraint) {
                    $constraint->aspectRatio();
                    $constraint->upsize();
                });
                Storage::put($directory.$file_name,  (string) $image->encode('jpg', 20));
                $row->image_small = $file_name;



            }else if(!$request->input('image') && !$request->input('temp_path') && !$request->input('image_url')){
                $row->image = 'imagen-no-disponible.jpg';
            }

            $row->save();

            (new ItemWebController)->generateInternalId($row);

            return $row;

        });

        $full_description = ($row->internal_id)?$row->internal_id.' - '.$row->description:$row->description;

        return [
            'success' => true,
            'msg' => 'Producto registrado con éxito',
            'data' => (object)[
                'id' => $row->id,
                'item_id' => $row->id,
                'name' => $row->name,
                'full_description' => $full_description,
                'description' => $row->description,
                'currency_type_id' => $row->currency_type_id,
                'internal_id' => $row->internal_id,
                'item_code' => $row->item_code,
                'barcode' => $row->barcode,
                'currency_type_symbol' => $row->currency_type->symbol,
                'sale_unit_price' => number_format( $row->sale_unit_price, 2),
                'purchase_unit_price' => $row->purchase_unit_price,
                'unit_type_id' => $row->unit_type_id,
                'sale_affectation_igv_type_id' => $row->sale_affectation_igv_type_id,
                'purchase_affectation_igv_type_id' => $row->purchase_affectation_igv_type_id,
                'calculate_quantity' => (bool) $row->calculate_quantity,
                'has_igv' => (bool) $row->has_igv,
                'is_set' => (bool) $row->is_set,
                'aux_quantity' => 1,
                'favorite' => (bool) $row->favorite,
            ],
        ];

    }

    public function person(PersonRequest $request)
    {
        $row = new Person();
        if ($request->department_id === '-') {
            $request->merge([
                'department_id' => null,
                'province_id'   => null,
                'district_id'   => null
            ]);
        }
        $row->fill($request->all());
        $row->save();
        $addresses = $request->input('addresses');
        if (isset($addresses)) {
            foreach ($addresses as $address) {
                if (is_array($address["location_id"]) && count($address["location_id"]) === 3 && $address["address"]) {
                    $address["district_id"] = $address["location_id"][2];
                    $address["province_id"] = $address["location_id"][1];
                    $address["department_id"] = $address["location_id"][0];
                } else {
                    continue;
                }
                if($address['has_consigned']){
                    if($row['consigned_id']){
                        $consigned = Consigned::where('id', $address['consigned_id'])->first();
                        $consigned->telephone = $address["phone"];
                        $consigned->save();
                    }
                }else{
                    $address['consigned_id'] = null;
                }
                $row->addresses()->updateOrCreate(['id' => $address['id']], $address);
            }
        }

        return [
            'success' => true,
            'msg' => ($request->type == 'customers') ? 'Cliente registrado con éxito' : 'Proveedor registrado con éxito',
            'data' => (object)[
                'id' => $row->id,
                'description' => $row->number.' - '.$row->name,
                'name' => $row->name,
                'number' => $row->number,
                'identity_document_type_id' => $row->identity_document_type_id,
                'identity_document_type_code' => $row->identity_document_type->code,
                'address' => $row->address,
                'email' => $row->email,
                'telephone' => $row->telephone,
                'country_id' => $row->country_id,
                'district_id' => $row->district_id,
                'selected' => false
            ]
        ];
    }

    protected function transformMobileItemUnitTypes($itemUnitTypes, $decimal_units = 2)
    {
        return $itemUnitTypes->transform(function ($itemUnitType) use ($decimal_units) {
            $pricesByPosition = $itemUnitType->prices
                ->filter(function ($price) {
                    return optional($price->priceLabel)->position !== null;
                })
                ->keyBy(function ($price) {
                    return (int) $price->priceLabel->position;
                });

            $price1 = data_get($pricesByPosition->get(1), 'price', $itemUnitType->price1);
            $price2 = data_get($pricesByPosition->get(2), 'price', $itemUnitType->price2);
            $price3 = data_get($pricesByPosition->get(3), 'price', $itemUnitType->price3);

            return [
                'id' => $itemUnitType->id,
                'description' => $itemUnitType->description,
                'unit_type_id' => $itemUnitType->unit_type_id,
                'quantity_unit' => number_format($itemUnitType->quantity_unit, $decimal_units, '.', ''),
                'price1' => number_format((float) ($price1 ?? 0), 2, '.', ''),
                'price2' => number_format((float) ($price2 ?? 0), 2, '.', ''),
                'price3' => number_format((float) ($price3 ?? 0), 2, '.', ''),
                'price_default' => $itemUnitType->price_default,
            ];
        });
    }

    public function searchItems(Request $request)
    {
        $establishment_id = auth()->user()->establishment_id;
        $warehouse = Warehouse::where('establishment_id', $establishment_id)->first();
        $search_by_barcode = $request->has('search_by_barcode') && (bool) $request->search_by_barcode;
        $category_id = $request->category_id ?? null;
        $limit = $request->limit ?? null;

        $item_query = Item::with(['brand', 'category', 'item_unit_types.prices.priceLabel']);

        if($search_by_barcode)
        {
            $item_query->where('barcode', $request->input)->limit(1);
        }
        else
        {
            $item_query->where('description', 'like', "%{$request->input}%")->orWhere('internal_id', 'like', "%{$request->input}%");

            if($limit) $item_query->limit($limit);
        }

        $items = $item_query->whereHasInternalId()
                    ->whereWarehouse()
                    // ->whereNotIsSet()
                    ->filterByCategory($category_id)
                    ->whereIsActive()
                    ->orderBy('description')
                    ->get()
                    ->transform(function($row) use($warehouse){

                        $full_description = ($row->internal_id)?$row->internal_id.' - '.$row->description:$row->description;

                        return [
                            'id' => $row->id,
                            'item_id' => $row->id,
                            'name' => $row->name,
                            'full_description' => $full_description,
                            'description' => $row->description,
                            'currency_type_id' => $row->currency_type_id,
                            'internal_id' => $row->internal_id,
                            'item_code' => $row->item_code ?? '',
                            'currency_type_symbol' => $row->currency_type->symbol,
                            'lots' => $row->lots,
                            'sale_unit_price' => $row->generalApplyNumberFormat($row->sale_unit_price),
                            // 'sale_unit_price' => number_format( $row->sale_unit_price, 2),
                            'purchase_unit_price' => $row->purchase_unit_price,
                            'unit_type_id' => $row->unit_type_id,
                            'sale_affectation_igv_type_id' => $row->sale_affectation_igv_type_id,
                            'purchase_affectation_igv_type_id' => $row->purchase_affectation_igv_type_id,
                            'calculate_quantity' => (bool) $row->calculate_quantity,
                            'has_igv' => (bool) $row->has_igv,
                            'is_set' => (bool) $row->is_set,
                            'aux_quantity' => 1,
                            'barcode' => $row->barcode ?? '',
                            'brand_id' => $row->brand_id,
                            'brand' => optional($row->brand)->name,
                            'category_id' => $row->category_id,
                            'category' => optional($row->category)->name,
                            'stock' => $row->getWarehouseCurrentStock($warehouse),
                            // 'stock' => $row->unit_type_id!='SERV' ? ItemWarehouse::where([['item_id', $row->id],['warehouse_id', $warehouse->id]])->first()->stock : '0',
                            'image' => $row->image != "imagen-no-disponible.jpg" ? url("/storage/uploads/items/" . $row->image) : url("/logo/" . $row->image),
                            'warehouses' => Item::transformWarehousesForApi($row->warehouses),
                            'item_unit_types' => $this->transformMobileItemUnitTypes($row->item_unit_types),
                            'favorite' => (bool) $row->favorite,
                        ];
                    });

        return [
            'success' => true,
            'data' => array('items' => $items)
        ];
    }

    public function searchCustomers(Request $request)
    {

        $identity_document_type_id = $this->getIdentityDocumentTypeId($request->document_type_id);

        $customers = Person::where(function ($query) use ($request): void {
                                $query->where('name', 'like', "%{$request->input}%" )
                                    ->orWhere('number','like', "%{$request->input}%");
                            })->whereType('customers')
                            ->whereSalesIdentityActive()
                            ->whereIn('identity_document_type_id', $identity_document_type_id)
                            ->orderBy('name')
                            ->get()
                            ->transform(function($row) {
                                return [
                                    'id' => $row->id,
                                    'description' => $row->number.' - '.$row->name,
                                    'name' => $row->name,
                                    'number' => $row->number,
                                    'identity_document_type_id' => $row->identity_document_type_id,
                                    'identity_document_type_code' => $row->identity_document_type->code,
                                    'identity_document_type_description' => $row->identity_document_type->description,
                                    'address' => $row->address,
                                    'telephone' => $row->telephone,
                                    'email' => $row->email,
                                    'country_id' => $row->country_id,
                                    'district_id' => $row->district_id,
                                    'selected' => false,
                                    'addresses' => PersonAddress::where('person_id',$row->id)
                                        ->get()
                                        ->transform(function ($row) {
                                            $location_id = [$row->department_id,$row->province_id,$row->district_id];
                                            return [
                                                'id' => $row->id,
                                                'location_id' => $location_id,
                                                'address' => $row->address,
                                                'code' => $row->establishment_code
                                            ];
                                        }),
                                ];
                            });

        return [
            'success' => true,
            'data' => array('customers' => $customers)
        ];
    }


    public function getIdentityDocumentTypeId($document_type_id){
        // ######## INICIO POLITICA IDENTIDAD ACTIVA EN VENTAS ########
        return \App\Services\SalesCustomerIdentityPolicy::activeIdentityTypeIds();
        // ######## FIN POLITICA IDENTIDAD ACTIVA EN VENTAS ########

    }

    public function report()
    {
        $request = [
            'customer_id' => null,
            'date_end' => date('Y-m-d'),
            'date_start' => date('Y-m-d'),
            'enabled_expense' => null,
            'enabled_move_item' => false,
            'enabled_transaction_customer' => false,
            'establishment_id' => 1,
            'item_id' => null,
            'month_end' => date('Y-m'),
            'month_start' => date('Y-m'),
            'period' => 'month',
        ];

        return [
            'data' => (new DashboardData())->data_mobile($request)
        ];
    }

    public function updateItem(ItemUpdateRequest $request, $itemId)
    {
        $row = Item::findOrFail($itemId);

        $row->fill($request->only('internal_id', 'barcode', 'model', 'has_igv', 'description', 'sale_unit_price', 'stock_min', 'item_code'));
        $row->save();

        $full_description = ($row->internal_id)?$row->internal_id.' - '.$row->description:$row->description;

        return [
            'success' => true,
            'msg' => 'Producto editado con éxito',
            'data' => (object)[
                'id' => $row->id,
                'item_id' => $row->id,
                'name' => $row->name,
                'full_description' => $full_description,
                'description' => $row->description,
                'currency_type_id' => $row->currency_type_id,
                'internal_id' => $row->internal_id,
                'item_code' => $row->item_code,
                'currency_type_symbol' => $row->currency_type->symbol,
                'sale_unit_price' => number_format( $row->sale_unit_price, 2),
                'purchase_unit_price' => $row->purchase_unit_price,
                'unit_type_id' => $row->unit_type_id,
                'sale_affectation_igv_type_id' => $row->sale_affectation_igv_type_id,
                'purchase_affectation_igv_type_id' => $row->purchase_affectation_igv_type_id,
                'calculate_quantity' => (bool) $row->calculate_quantity,
                'has_igv' => (bool) $row->has_igv,
                'is_set' => (bool) $row->is_set,
                'aux_quantity' => 1,
            ],
        ];
    }

    //subir imagen app
    public function upload(Request $request)
    {

        $validate_upload = UploadFileHelper::validateUploadFile($request, 'file', 'jpg,jpeg,png,gif,svg,webp');

        if(!$validate_upload['success']){
            return $validate_upload;
        }

        if ($request->hasFile('file')) {
            $new_request = [
                'file' => $request->file('file'),
                'type' => $request->input('type'),
            ];

            return $this->upload_image($new_request);
        }
        return [
            'success' => false,
            'message' =>  __('app.actions.upload.error'),
        ];
    }


    function upload_image($request)
    {
        $file = $request['file'];
        $type = $request['type'];

        $temp = tempnam(sys_get_temp_dir(), $type);
        file_put_contents($temp, file_get_contents($file));

        $mime = mime_content_type($temp);
        $data = file_get_contents($temp);

        return [
            'success' => true,
            'data' => [
                'filename' => $file->getClientOriginalName(),
                'temp_path' => $temp,
                'temp_image' => 'data:' . $mime . ';base64,' . base64_encode($data)
            ]
        ];
    }

    public function getDataToDispatch($id)
    {

        $document = Document::find($id);
        if(!$document){
            return [
                'success'=> false,
                'message'=> 'No éxiste documento'
            ];
        }
        $document_data =[];
        $company = Company::active();
        if($document){
            $document_data = [
                'establishment_id' => $document->establishment_id,
                'customer_id' => $document->customer_id,
                'document_related' => [
                    'documento'=>[
                        'id' =>  $document->document_type_id,
                        // ########## INICIO CAMBIO CATÁLOGOS DE NOMBRES
                        'descripcion' => $document->document_type->description
                        // ######### FIN CAMBIO CATÁLOGOS DE NOMBRES
                    ],
                    'document_type_id' => $document->document_type_id,
                    'serie' => $document->series,
                    'numero' => $document->number_full,
                    'empresa' => $company->name,
                    'ruc' => $company->number
                ]
            ];
        }
        $document_items = DocumentItem::where('document_id', $id)->get();
        $customer = Person::where('id', $document->customer_id)->first();
        $customer_data = [];
        if ($customer) {
            $customer_data = [
                'id' => $customer->id,
                'description' => $customer->number . ' - ' . $customer->name,
                'name' => $customer->name,
                'number' => $customer->number,
                'identity_document_type_id' => $customer->identity_document_type_id,
                'identity_document_type_code' => $customer->identity_document_type->code,
                'identity_document_type_description' => $customer->identity_document_type->description,
                'address' => $customer->address,
                'telephone' => $customer->telephone,
                'country_id' => $customer->country_id,
                'district_id' => $customer->district_id,
                'email' => $customer->email,
                'selected' => false,
                'addresses' => PersonAddress::where('person_id', $customer->id)
                    ->get()
                    ->map(function ($row) {
                        $location_id = [$row->department_id, $row->province_id, $row->district_id];
                        return [
                            'id' => $row->id,
                            'location_id' => $location_id,
                            'address' => $row->address,
                            'code' => $row->establishment_code
                        ];
                    }),
            ];
        }

        return [
            'success'=> true,
            'data' =>[
                'document' => $document_data,
                'items' => $document_items,
                'customer' => $customer_data
            ],
            'message' => 'Documento encontrado con éxito'
        ];

    }

    public function record_qrapi(Request $request)
    {
        return app(QrApiController::class)->getConfig();
    }

    public function configWeb() {
        $configuration = Configuration::first();

        return [
            "success" => true,
            "data" => [
                "enable_consigned" => $configuration->enable_consigned
            ]
        ];
    }

    public function priceLabels()
    {
        $labels = PriceLabel::active()->ordered()->get();

        return response()->json([
            'success' => true,
            'data' => $labels->map->getCollectionData(),
            'label_default' => (Configuration::first()->price1_label) ? Configuration::first()->price1_label : 'Precio principal'
        ]);
    }

    public function destroyItem($id)
    {
        $item = \App\Models\Tenant\Item::findOrFail($id);

        \DB::connection('tenant')->statement('SET FOREIGN_KEY_CHECKS=0;');
        $item->delete();
        \DB::connection('tenant')->statement('SET FOREIGN_KEY_CHECKS=1;');

        return [
            'success' => true,
            'message' => '¡Producto eliminado con éxito.!'
        ];
    }

    public function stats($startDate = null, $endDate = null)
    {
        // Sin orderBy: la consulta solo devuelve agregados y no lleva GROUP BY, asi que
        // ordenar por una columna normal hace que MySQL responda el error 1140.
        $documents = Document::whereTypeUser();
        $sale_notes = SaleNote::whereTypeUser();

        if ($startDate != null)
        {
            $documents->whereBetween('date_of_issue', [$startDate, $endDate]);
            $sale_notes->whereBetween('date_of_issue', [$startDate, $endDate]);
        }

        $documents = $documents
                ->selectRaw("
                    COUNT(CASE WHEN document_type_id = '01' THEN 1 END) AS facturas,
                    COALESCE(SUM(total), 0) AS total,
                    COUNT(*) AS count
                ")->first();

        $sale_notes = $sale_notes
                ->selectRaw("
                    COUNT(*) AS notasVenta,
                    COALESCE(SUM(total), 0) AS total
                ")->first();

        return [
            'total' => round((float) $documents->total + (float) $sale_notes->total, 2),
            'count' => (int) $documents->count + (int) $sale_notes->notasVenta,
            'facturas' => (int) $documents->facturas,
            'notasVenta' => (int) $sale_notes->notasVenta,
        ];
    }
}
