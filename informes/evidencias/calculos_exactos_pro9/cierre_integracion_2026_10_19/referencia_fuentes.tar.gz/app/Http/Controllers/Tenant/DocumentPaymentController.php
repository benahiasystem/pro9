<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tenant\DocumentPaymentRequest;
use App\Http\Requests\Tenant\DocumentRequest;
use App\Http\Resources\Tenant\DocumentPaymentCollection;
use App\Models\Tenant\Document;
use App\Models\Tenant\DocumentPayment;
use App\Models\Tenant\PaymentMethodType;
use App\Exports\DocumentPaymentExport;
use Exception, Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf as PDF;
use Modules\Finance\Traits\FinanceTrait;
use Modules\Finance\Traits\FilePaymentTrait;
use Carbon\Carbon;
use App\Models\Tenant\CashDocumentCredit;
use App\Models\Tenant\Cash;

class DocumentPaymentController extends Controller
{
    use FinanceTrait, FilePaymentTrait;

    public function records($document_id)
    {
        DocumentFiscalController::authorizeDocument(Document::findOrFail($document_id));
        $records = DocumentPayment::where('document_id', $document_id)->whereNull('receipt_parent_id')->get();

        return new DocumentPaymentCollection($records);
    }

    public function tables()
    {
        return [
            'payment_method_types' => PaymentMethodType::getPaymentMethodTypes(),
            'payment_destinations' => $this->getPaymentDestinations(),
            'permissions' => auth()->user()->getPermissionsPayment()
        ];
    }

    public function document($document_id)
    {
        $document = Document::find($document_id);

        DocumentFiscalController::authorizeDocument($document);
        $paidExact = \App\Support\Exact\Decimal::sum($document->payments()->whereNull('reversed_at')->get()->map(fn($r)=>$r->exactValue('payment')));
        $balance = $document->exactBalance();
        $total = \App\Support\Exact\Decimal::represent($balance->plus($paidExact));
        $total_paid = \App\Support\Exact\Decimal::represent($paidExact);
        $total_difference = \App\Support\Exact\Decimal::represent($balance);

        return [
            'number_full' => $document->number_full,
            'document_type_id' => $document->document_type_id,
            'iva_retention' => \App\Services\Fiscal\IvaRetentionService::view($document),
            'islr_retention' => \App\Services\Fiscal\IslrRetentionService::view($document),
            'total_paid' => $total_paid,
            'total' => $total,
            'total_difference' => $total_difference,
            'amount_payable' => \App\Support\Exact\Decimal::represent($balance,2,true),
            'calculation_snapshot' => \App\Support\Exact\Decimal::snapshot(['total'=>$balance->plus($paidExact),'total_paid'=>$paidExact,'total_difference'=>$balance]),
            'currency_type_id' => $document->currency_type_id,
            'exchange_rate_sale' => \App\Services\ExchangeRates\ExchangeRateMath::rate($document->exchange_rate_sale),
            // 'credit_notes_total' => $credit_notes_total,
            'external_id' => $document->external_id,
        ];

    }

    public function store(DocumentPaymentRequest $request)
    {
        // dd($request->all());

        abort_unless(auth()->user()->type==='admin' || auth()->user()->create_payment,403);
        $id = $request->input('id');

        $data = DB::connection('tenant')->transaction(function () use ($id, $request) {

            $document = Document::findOrFail($request->input('document_id'));
            DocumentFiscalController::authorizeDocument($document);
            $record = \App\Services\Fiscal\FiscalDocumentPersistence::payment($document, $request->all());
            if (!$record->global_payment && $request->filled('payment_destination_id')) {
                $this->createGlobalPayment($record, $request->all());
                $this->saveFiles($record, $request, 'documents');
                $this->createCashDocumentPayment($record,true);
            }
            return $record;
        });

        $adjustment = \App\Models\Tenant\DocumentTax::where('document_payment_id',$data->id)->where('document_id','!=',$data->document_id)->first();
        $adjustmentDocument = $adjustment ? Document::findOrFail($adjustment->document_id) : null;
        if ($adjustmentDocument && !\App\Services\Fiscal\HkaIgtfNote::applies($adjustmentDocument) && !$adjustmentDocument->isVoidedOrRejected()) (new \App\CoreFacturalo\Facturalo())->createPdf($adjustmentDocument,'debit','a4');
        $document_balance = (object)$this->document($request->document_id);

        if (\App\Models\Tenant\Document::findOrFail($request->document_id)->exactBalance()->isLessThanOrEqualTo(0)) {

            $credit = CashDocumentCredit::where([
                ['status', 'PENDING'],
                ['document_id', $request->document_id]
            ])->first();

            if ($credit) {

                $cash = Cash::where([
                    ['user_id', auth()->user()->id],
                    ['state', true],
                ])->first();

                $credit->status = 'PROCESSED';
                $credit->cash_id_processed = optional($cash)->id;
                $credit->save();

                // $req = [
                //     'document_id' => $request->document_id,
                //     'sale_note_id' => null
                // ];

                // $cash->cash_documents()->updateOrCreate($req);

            }

        }

        return [
            'success' => true,
            'message' => ($id) ? 'Pago editado con éxito' : 'Pago registrado con éxito',
            'id' => $data->id,
            'igtf_adjustment' => $adjustmentDocument ? ['id'=>$adjustmentDocument->id,'number'=>$adjustmentDocument->number_full,'external_id'=>$adjustmentDocument->external_id,'fiscal_emission'=>\App\Services\Fiscal\DocumentEmissionView::forDocument($adjustmentDocument)] : null,
        ];
    }


    public function destroy($id, \Illuminate\Http\Request $request)
    {
        abort_unless(auth()->user()->type==='admin' || auth()->user()->delete_payment,403);
        $item = DocumentPayment::findOrFail($id);
        DocumentFiscalController::authorizeDocument($item->document);
        \App\Services\Fiscal\FiscalDocumentPersistence::reverse($item, $request->input('reason', 'Reversión solicitada por el operador'));

        return [
            'success' => true,
            'message' => 'Pago revertido con éxito'
        ];
    }

    public function initialize_balance()
    {

        DB::connection('tenant')->transaction(function () {

            $documents = Document::get();

            foreach ($documents as $document) {

                if ($document->exactBalance()->isLessThanOrEqualTo(0)) {

                    $document->total_canceled = true;
                    $document->update();

                } else {

                    $document->total_canceled = false;
                    $document->update();
                }

            }

        });

        return [
            'success' => true,
            'message' => 'Acción realizada con éxito'
        ];
    }

    public function report($start, $end, $type = 'pdf')
    {
        $documents = DocumentPayment::whereBetween('date_of_payment', [$start, $end])->get();

        $records = collect($documents)->transform(function ($row) {
            return [
                'id' => $row->id,
                'date_of_payment' => $row->date_of_payment->format('d/m/Y'),
                'payment_method_type_description' => $row->payment_method_type->description,
                'destination_description' => ($row->global_payment) ? $row->global_payment->destination_description : null,
                'change' => $row->change,
                'payment' => $row->reversed_at ? 0 : $row->cash_received_amount,
                'currency_type_id' => $row->currency_type_id,
                'applied_payment' => $row->payment,
                'reference' => $row->reference,
                'customer' => $row->document->customer->name,
                'number' => $row->document->number_full,
                'total' => $row->document->total,
            ];
        });

        if ($type == 'pdf') {
            $pdf = PDF::loadView('tenant.document_payments.report', compact("records"));

            $filename = "Reporte_Pagos";

            return $pdf->stream($filename . '.pdf');
        } elseif ($type == 'excel') {
            $filename = "Reporte_Pagos";

            // $pdf = PDF::loadView('tenant.document_payments.report', compact("records"))->download($filename.'.xlsx');

            // return $pdf->stream($filename.'.xlsx');

            return (new DocumentPaymentExport)
                ->records($records)
                ->download($filename . Carbon::now() . '.xlsx');
        }

    }

}
