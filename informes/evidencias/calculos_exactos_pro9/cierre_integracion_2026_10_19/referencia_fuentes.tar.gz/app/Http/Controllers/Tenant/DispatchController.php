<?php

namespace App\Http\Controllers\Tenant;

use App\CoreFacturalo\Facturalo;
use App\CoreFacturalo\Helpers\Storage\StorageDocument;
use App\Http\Controllers\Controller;
use App\Http\Requests\Tenant\DispatchRequest;
use App\Http\Resources\Tenant\DispatchCollection;
use App\Models\Tenant\Catalogs\AffectationIgvType;
use App\Models\Tenant\Catalogs\DocumentType;
use App\Models\Tenant\Catalogs\TransferReasonType;
use App\Models\Tenant\Catalogs\TransportModeType;
use App\Models\Tenant\Catalogs\UnitType;
use App\Models\Tenant\Company;
use App\Models\Tenant\Configuration;
use App\Models\Tenant\Dispatch;
use App\Models\Tenant\DispatchItem;
use App\Models\Tenant\Document;
use App\Models\Tenant\Establishment;
use App\Models\Tenant\Item;
use App\Models\Tenant\PaymentMethodType;
use App\Models\Tenant\Person;
use App\Models\Tenant\Quotation;
use App\Models\Tenant\SaleNote;
use App\Models\Tenant\Series;
use App\Services\SeriesResolver;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Modules\Dispatch\Http\Controllers\DispatcherController;
use Modules\Dispatch\Http\Controllers\DriverController;
use Modules\Dispatch\Http\Controllers\OriginAddressController;
use Modules\Dispatch\Http\Controllers\TransportController;
use Modules\Dispatch\Models\Dispatcher;
use Modules\Dispatch\Models\Driver;
use Modules\Dispatch\Models\OriginAddress;
use Modules\Dispatch\Models\Transport;
use Modules\Document\Traits\SearchTrait;
use Modules\Finance\Traits\FinanceTrait;
use Modules\Inventory\Models\Warehouse as ModuleWarehouse;
use Modules\Order\Http\Resources\DispatchResource;
use Modules\Order\Mail\DispatchEmail;
use Modules\Order\Models\OrderNote;
use App\Models\Tenant\PaymentCondition;
use App\Models\Tenant\Catalogs\RelatedDocumentType;
use Illuminate\Support\Facades\Log;
use Modules\Purchase\Models\Purchase;


/**
 * Class DispatchController
 *
 * @package App\Http\Controllers\Tenant
 * @mixin Controller
 */
class DispatchController extends Controller
{
    use FinanceTrait;
    use SearchTrait;
    use StorageDocument;

    public function __construct()
    {
        $this->middleware(function ($request,$next) { \App\Services\Fiscal\DeliveryOrderInput::authorize();return $next($request); });
        $this->middleware('input.request:dispatch,web', ['only' => ['store']]);
    }

    public function index()
    {
        $configuration = Configuration::getPublicConfig();
        return view('tenant.dispatches.index', compact('configuration'));
    }

    public function columns()
    {
        return [
            'number' => 'Número'
        ];
    }

    public function records(Request $request)
    {
        $records = $this->getRecords($request);

        return new DispatchCollection($records->paginate(config('tenant.items_per_page')));
    }


    public function getRecords($request)
    {

        $d_end = $request->d_end;
        $d_start = $request->d_start;
        $number = $request->number;
        $series = $request->series;
        $customer_id = $request->customer_id;


        if ($d_start && $d_end) {
            $query = Dispatch::query()
                ->where('document_type_id', '09')
                ->whereBetween('date_of_issue', [$d_start, $d_end]);
        } else {
            $query = Dispatch::query()
                ->where('document_type_id', '09')
;
        }

        if (auth()->user()->type!=='admin') $query->where('establishment_id',auth()->user()->establishment_id);
        $query->whereFiscalIdentifiers($series, $number, $request->control_number);

        if ($customer_id) {
            $query->where('customer_id', $customer_id);
        }

        if ((new Dispatch)->getConnection()->getSchemaBuilder()->hasTable('dispatch_emissions')) $query->with('emission');
        return $query->latest();
    }

    public function updateCustomFields(Request $request)
    {
        $request->validate([
            'id' => 'required|integer',
            'custom_fields_data' => 'nullable|array'
        ]);

        $dispatch = Dispatch::findOrFail($request->input('id'));
        $dispatch->custom_fields_data = $request->input('custom_fields_data', []);
        $dispatch->save();

        return [
            'success' => true,
            'data' => $dispatch->custom_fields_data
        ];
    }

    public function data_table()
    {
        $customers = Person::whereType('customers')->orderBy('name')->take(20)->get()->transform(function ($row) {
            return [
                'id' => $row->id,
                'description' => $row->number . ' - ' . $row->name,
                'name' => $row->name,
                'number' => $row->number,
                'identity_document_type_id' => $row->identity_document_type_id,
            ];
        });

        // Series filtradas por contexto (oculta dedicadas / restringe al grupo activo). Ver SeriesResolver.
        $series = app(SeriesResolver::class)->applyContext(Series::where('document_type_id', '09'))->get();

        return compact('customers', 'series');

    }


    public function create($document_id = null, $type = null, $dispatch_id = null)
    {
        if ($dispatch_id) return $this->createNew('dispatch',$dispatch_id);
        if (!$document_id) return view('tenant.dispatches.create');
        return $this->createNew($type==='q' ? 'quotation':($type==='on' ? 'order_note':'document'),$document_id);
    }

    public function createNew($parentTable, $parentId)
    {
        $query = null;
        $reference_document_id = null;
        $reference_quotation_id = null;
        $reference_sale_note_id = null;
        $reference_order_form_id = null;
        $reference_order_note_id = null;
        $reference_purchase_id = null;

        if ($parentTable === 'document') {
            $reference_document_id = $parentId;
            $query = Document::query();
        } elseif ($parentTable === 'quotation') {
            $reference_quotation_id = $parentId;
            $query = Quotation::query();
        } elseif ($parentTable === 'sale_note') {
            $reference_sale_note_id = $parentId;
            $query = SaleNote::query();
        } elseif ($parentTable === 'order_note') {
            $reference_order_note_id = $parentId;
            $query = OrderNote::query();
        } elseif ($parentTable === 'dispatch') {
            $query = Dispatch::query();
        } elseif ($parentTable === 'purchases') {
            $query = Purchase::query();
            $reference_purchase_id = $parentId;
        }

        abort_unless($query,404);
        $document = $query->findOrFail($parentId);
        \App\Services\Fiscal\DeliveryOrderInput::authorize((int)$document->establishment_id);
        if ($parentTable==='dispatch') \App\Services\Fiscal\DeliveryOrderPersistence::assertEditable($document);
        $configuration = Configuration::query()->first();
        $items = [];
        foreach ($document->items as $item) {
            $name_product_pdf = ($configuration->show_pdf_name) ? strip_tags($item->name_product_pdf) : null;
            $description = $item->item->description;
            $presentation = !empty($item->item->presentation) ? $item->item->presentation->description : '';
            $unit_type = !empty($item->item->presentation) ? $item->item->presentation->unit_type_id : $item->item->unit_type_id;
            $IdLoteSelected = !empty($item->item->IdLoteSelected) ? $item->item->IdLoteSelected : null;
            $weight = $item->item->weight ?? 0;
            $items[] = [
                'item_id' => $item->item_id,
                'item' => $item,
                'quantity' => $item->quantity,
                'description' => $description.' '.$presentation,
                'unit_type_id' => $unit_type,
                'weight' => $weight,
                'name_product_pdf' => $name_product_pdf,
                'IdLoteSelected' => $IdLoteSelected,
                'unit_price' => $item->item->unit_price ?? 0,
                'total' => $item->item->total ?? 0,
            ];
        }

        if ($parentTable === 'dispatch') {
            $data = [
                'id' => $document->id,
                'creation_key' => $document->creation_key,
                'hka_data' => $document->hka_data ?? [],
                'time_of_issue' => $document->time_of_issue,
                'series' => $document->series,
                'number' => $document->number,
                'establishment_id' => $document->establishment_id,
                'customer_id' => $document->customer_id,
                'items' => $items ?? [],
                'date_of_issue' => $document->date_of_issue->format('Y-m-d'),
                'date_of_shipping' => $document->date_of_shipping->format('Y-m-d'),
                'packages_number' => $document->packages_number,
                'total_weight' => $document->total_weight,
                'transfer_reason_type_id' => $document->transfer_reason_type_id,
                'transfer_reason_description' => $document->transfer_reason_description,
                'transport_mode_type_id' => $document->transport_mode_type_id,
                'transshipment_indicator' => $document->transshipment_indicator,
                'unit_type_id' => $document->unit_type_id,
                'observations' => $document->observations,
                'driver_id' => $document->driver_id,
                'dispatcher_id' => $document->dispatcher_id,
                'transport_id' => $document->transport_id,
                'secondary_drivers' => $document->secondary_drivers,
                'secondary_transports' => $document->secondary_transports,
                'has_transport_driver_01' => $document->has_transport_driver_01,
                'origin_address_id' => $document->origin_address_id,
                'delivery_address_id' => $document->delivery_address_id,
                'date_delivery_to_transport' => $document->date_delivery_to_transport?$document->date_delivery_to_transport->format('Y-m-d'):null,
                'reference_document_id' => $document->reference_document_id,
                'reference_quotation_id' => $document->reference_quotation_id,
                'reference_sale_note_id' => $document->reference_sale_note_id,
                'reference_order_form_id' => $document->reference_order_form_id,
                'reference_order_note_id' => $document->reference_order_note_id,
                'reference_purchase_id' => $document->reference_purchase_id,
                'document_data' => $document->reference_documents?? [],
                'reference_documents' => $document->reference_documents?? [],
                'custom_fields_data' => $document->custom_fields_data
            ];
        } else {
            $observations = '';
            if ($parentTable === 'quotation') {
                $observations = $document->description;
            } else if ($parentTable === 'sale_note' ) {
                $observations = $document->observation;
            }
            $company = Company::first();

            $total_weight_from_attributes = 0;
            if ($parentTable === 'quotation') {
                foreach ($document->items as $item) {
                    $raw_attributes = $item->getRawOriginal('attributes');
                    if ($raw_attributes) {
                        $attrs = json_decode($raw_attributes, true);
                        if (is_array($attrs) && count($attrs) > 0) {
                            $first_attr = $attrs[0];
                            $total_weight_from_attributes += (float)($first_attr['value'] ?? 0) * (float)$item->quantity;
                        }
                    }
                }
            }

            $data = [
                'establishment_id' => $document->establishment_id,
                'customer_id' => $document->customer_id,
                'items' => $items,
                'reference_document_id' => $reference_document_id,
                'reference_quotation_id' => $reference_quotation_id,
                'reference_sale_note_id' => $reference_sale_note_id,
                'reference_order_form_id' => $reference_order_form_id,
                'reference_order_note_id' => $reference_order_note_id,
                'reference_purchase_id' => $reference_purchase_id,
                'document_data' => [
                    'document_type_id' => $document->document_type_id,
                    'serie' => $document->series,
                    'number' => $document->number,
                    'customer' => $parentTable == 'purchases' ? $document->supplier->number : $company->number,
                    'name' => $parentTable == 'purchases' ? $document->supplier->name : $company->name
                ],
                'observations' => $observations,
                'total_weight' => $total_weight_from_attributes,
            ];
        }

        return view('tenant.dispatches.form', [
            'document' => $data,
            'parentTable' => $parentTable,
            'parentId' => $parentId
        ]);
    }

    public function generate($sale_note_id)
    {
        return $this->createNew('sale_note',$sale_note_id);
    }


    public function store(DispatchRequest $request)
    {
        $company = Company::query()
            ->select('fiscal_environment')
            ->first();
        $configuration = Configuration::first();
        $res = [];
        if (str_starts_with((string) $request->series, 'T')) {
            /** @var Facturalo $fact */
            $fact = DB::connection('tenant')->transaction(function () use ($request, $configuration) {
                $facturalo = new Facturalo();
                $facturalo->save($request->all());
                $document = $facturalo->getDocument();
                $facturalo->createPdf();
                return $facturalo;
            });

            $document = $fact->getDocument();
//            if ($company->fiscal_environment === 'production') {
//            }
            // $response = $fact->getResponse();
        } else {
            /** @var Facturalo $fact */
            $fact = DB::connection('tenant')->transaction(function () use ($request) {
                $facturalo = new Facturalo();
                $facturalo->save($request->all());
                $facturalo->createPdf();

                return $facturalo;
            });

            $document = $fact->getDocument();
            // $response = $fact->getResponse();
        }

        if (!empty($document->reference_document_id) && $configuration->getUpdateDocumentOnDispaches()) {
            $reference = Document::find($document->reference_document_id);
            if (!empty($reference)) {
                $reference->updatePdfs();
            }
        }

        // ########## INICIO CAMBIO CATÁLOGOS DE NOMBRES
        $message = "Se creó la orden de entrega {$document->number_full}";
        // ######### FIN CAMBIO CATÁLOGOS DE NOMBRES

        return [
            'success' => true,
            'message' => $message,
            'fiscal_emission' => \App\Services\Fiscal\HkaDispatchEmission::view($document),
            'pdf_downloads' => \App\Services\Fiscal\HkaDispatchPdf::view($document),
            'data' => [
                'id' => $document->id,
            ],
        ];
    }

    /**
     * Tables
     *
     * @param Request $request
     *
     * @return array
     */
    public function tables(Request $request)
    {
        $itemsFromSummary = null;
        if ($request->itemIds) {
            $itemsFromSummary = Item::query()
                ->with('lots_group')
                ->whereIn('id', $request->itemIds)
                ->where('item_type_id', '01')
                ->orderBy('description')
                ->get()
                ->transform(function ($row) {
                    $full_description = ($row->internal_id) ? $row->internal_id . ' - ' . $row->description : $row->description;

                    return [
                        'id' => $row->id,
                        'full_description' => $full_description,
                        'description' => $row->description,
                        'model' => $row->model,
                        'internal_id' => $row->internal_id,
                        'currency_type_id' => $row->currency_type_id,
                        'currency_type_symbol' => $row->currency_type->symbol,
                        'sale_unit_price' => $row->sale_unit_price,
                        'purchase_unit_price' => $row->purchase_unit_price,
                        'unit_type_id' => $row->unit_type_id,
                        'sale_affectation_igv_type_id' => $row->sale_affectation_igv_type_id,
                        'attributes' => $row->attributes ? $row->attributes : [],
                        'purchase_affectation_igv_type_id' => $row->purchase_affectation_igv_type_id,
                        'has_igv' => $row->has_igv,
                        'lots_group' => $row->lots_group->each(function ($lot) {
                            return [
                                'id' => $lot->id,
                                'code' => $lot->code,
                                'quantity' => $lot->quantity,
                                'date_of_due' => $lot->date_of_due,
                                'checked' => false
                            ];
                        }),
                        'lots' => [],
                        'lots_enabled' => (bool)$row->lots_enabled,
                    ];
                });
        }
        $items = Item::query()
            ->with('lots_group')
            ->where('item_type_id', '01')
            ->orderBy('description')
            ->take(20)
            ->get()
            ->transform(function ($row) {
                $full_description = ($row->internal_id) ? $row->internal_id . ' - ' . $row->description : $row->description;
                return [
                    'id' => $row->id,
                    'full_description' => $full_description,
                    'description' => $row->description,
                    'model' => $row->model,
                    'internal_id' => $row->internal_id,
                    'currency_type_id' => $row->currency_type_id,
                    'currency_type_symbol' => $row->currency_type->symbol,
                    'sale_unit_price' => $row->sale_unit_price,
                    'purchase_unit_price' => $row->purchase_unit_price,
                    'unit_type_id' => $row->unit_type_id,
                    'sale_affectation_igv_type_id' => $row->sale_affectation_igv_type_id,
                    'attributes' => $row->attributes ? $row->attributes : [],
                    'purchase_affectation_igv_type_id' => $row->purchase_affectation_igv_type_id,
                    'has_igv' => $row->has_igv,
                    'lots_group' => $row->lots_group->each(function ($lot) {
                        return [
                            'id' => $lot->id,
                            'code' => $lot->code,
                            'quantity' => $lot->quantity,
                            'date_of_due' => $lot->date_of_due,
                            'checked' => false
                        ];
                    }),
                    'lots' => [],
                    'lots_enabled' => (bool)$row->lots_enabled,
                    'warehouses' => $row->getDataWarehouses(),
                ];
            });

        $identities = ['6', '4', '1', '0'];

        // $dni_filter = config('tenant.document_type_03_filter');
        // if($dni_filter){
        //     array_push($identities, '1');
        // }

        $customers = Person::with('addresses')
            ->whereHas('identity_document_type',fn($q)=>$q->where('active',true)->where('id','!=','ND'))
            ->whereType('customers')
            ->orderBy('name')
            ->whereIsEnabled()
            ->get()
            ->transform(function ($row) {
                return [
                    'id' => $row->id,
                    'description' => $row->number . ' - ' . $row->name,
                    'name' => $row->name,
                    'trade_name' => $row->trade_name,
                    'country_id' => $row->country_id,
                    'address' => $row->address,
                    'addresses' => $row->addresses,
                    'email' => $row->email,
                    'telephone' => $row->telephone,
                    'number' => $row->number,
                    'district_id' => $row->district_id,
                    'department_id' => $row->department_id,
                    'province_id' => $row->province_id,
                    'identity_document_type_id' => $row->identity_document_type_id,
                    'identity_document_type_code' => $row->identity_document_type->code
                ];
            });

        $countries = func_get_countries();
        $locations = func_get_locations();
        $identityDocumentTypes = func_get_identity_document_types();

        $transferReasonTypes = TransferReasonType::whereContractActive()->get();
        $transportModeTypes = TransportModeType::whereActive()->get();
        // ######## INICIO CONTRATO UNIDADES DE MEDIDA VENEZUELA ########
        $unitTypes = UnitType::query()
            ->where('active', true)
            ->whereIn('id', ['KG', 'TON'])->get()->transform(function ($r) {
                return [
                    'id' => $r->id,
                    'description' => $r->description,
                ];
            });
        // ######## FIN CONTRATO UNIDADES DE MEDIDA VENEZUELA ########

        $establishments = Establishment::query()->when(auth()->user()->type!=='admin',fn($q)=>$q->where('id',auth()->user()->establishment_id))->get();
        $series = app(SeriesResolver::class)->applyContext(Series::query())->get()->toArray();
        $company = Company::select('number', 'name', 'identity_document_type_id','fiscal_emission_mode','fiscal_environment')->first();
        $hkaCatalogs=[];foreach (['product_types'=>'cat_product_types','product_origins'=>'cat_product_origins','taxation_products'=>'cat_taxation_products'] as $name=>$table) $hkaCatalogs[$name]=DB::connection('tenant')->table($table)->where('active',true)->get(['id','description']);
        $drivers = (new DriverController())->getOptions();
        $transports = (new TransportController())->getOptions();
        $dispatchers = (new DispatcherController())->getOptions();
        $related_document_types = RelatedDocumentType::available();

        return compact(
            'establishments',
            'customers',
            'series',
            'transportModeTypes',
            'transferReasonTypes',
            'unitTypes',
            'countries',
            // 'departments',
            // 'provinces',
            // 'districts',
            'identityDocumentTypes',
            'items',
            'locations',
            'company',
            'hkaCatalogs',
            'drivers',
            'dispatchers',
            'transports',
            'related_document_types',
            'itemsFromSummary'
        );
    }

    public function downloadExternal($type, $external_id)
    {
        $retention = Dispatch::where('external_id', $external_id)->first();

        if (!$retention) {
            throw new Exception("El código {$external_id} es inválido, no se encontro documento relacionado");
        }

        if ($type !== 'pdf') {
            throw new Exception('Tipo de archivo a descargar es inválido');
        }

        $folder = 'pdf';
        // Validar existencia física del PDF.
        // Si el archivo fue purgado, reconstruir la orden de entrega.
        if (!$this->existFileInStorage($retention->filename, $folder)) {
            (new \App\CoreFacturalo\Facturalo)->createPdf($retention, 'dispatch', 'a4');
        }

        return $this->downloadStorage($retention->filename, $folder);
    }

    public function record($id)
    {
        $record = new DispatchResource(\App\Services\Fiscal\DeliveryOrderInput::order($id));

        return $record;
    }

    public function email(Request $request)
    {
        $record = \App\Services\Fiscal\DeliveryOrderInput::order($request->input('id'));
        $customer_email = $request->input('customer_email');
        $email = $customer_email;
        $mailable = new DispatchEmail($record);
        $id = $request->input('id');
        $model = __FILE__ . ";;" . __LINE__;
        $sendIt = EmailController::SendMail($email, $mailable, $id, 4);
        /*
        Configuration::setConfigSmtpMail();
        $array_email = explode(',', $customer_email);
        if (count($array_email) > 1) {
            foreach ($array_email as $email_to) {
                $email_to = trim($email_to);
                if(!empty($email_to)) {
                    Mail::to($email_to)->send(new DispatchEmail($record));
                }
            }
        } else {
            Mail::to($customer_email)->send(new DispatchEmail($record));
        }
        */
        return [
            'success' => true
        ];
    }

    public function generateDocumentTables($id)
    {
        $dispatch = \App\Services\Fiscal\DeliveryOrderInput::order($id);
        $establishment = Establishment::findOrFail($dispatch->establishment_id);
        $establishment_id = $establishment->id;
        $warehouse = ModuleWarehouse::where('establishment_id', $establishment_id)->first();
        $relation_external_document = $dispatch->getRelationExternalDocument();
        $set_unit_price_dispatch_related_record = Configuration::getUnitPriceDispatchRelatedRecord();

        $itemsId = $dispatch->items->pluck('item_id')->all();

        $items = Item::whereIn('id', $itemsId)->get()->transform(function ($row) use ($warehouse, $dispatch, $relation_external_document, $set_unit_price_dispatch_related_record) {

            $detail = $this->getFullDescription($row, $warehouse);

            $sale_unit_price = $this->getDispatchSaleUnitPrice($row, $dispatch, $relation_external_document, $set_unit_price_dispatch_related_record);

            return [
                'id' => $row->id,
                'full_description' => $detail['full_description'],
                'model' => $row->model,
                'brand' => $detail['brand'],
                'category' => $detail['category'],
                'stock' => $detail['stock'],
                'internal_id' => $row->internal_id,
                'description' => $row->description,
                'currency_type_id' => $row->currency_type_id,
                'currency_type_symbol' => $row->currency_type->symbol,
                'sale_unit_price' => number_format($sale_unit_price, 4, '.', ''),
                // 'sale_unit_price'                  => number_format($row->sale_unit_price, 4, '.', ''),
                'purchase_unit_price' => $row->purchase_unit_price,
                'unit_type_id' => $row->unit_type_id,
                'sale_affectation_igv_type_id' => $row->sale_affectation_igv_type_id,
                'purchase_affectation_igv_type_id' => $row->purchase_affectation_igv_type_id,
                'calculate_quantity' => (bool)$row->calculate_quantity,
                'has_igv' => (bool)$row->has_igv,
                'item_unit_types' => collect($row->item_unit_types)->transform(function ($row) {
                    return [
                        'id' => $row->id,
                        'description' => "{$row->description}",
                        'item_id' => $row->item_id,
                        'unit_type_id' => $row->unit_type_id,
                        'quantity_unit' => $row->quantity_unit,
                        'price1' => $row->price1,
                        'price2' => $row->price2,
                        'price3' => $row->price3,
                        'price_default' => $row->price_default,
                    ];
                }),
                'warehouses' => collect($row->warehouses)->transform(function ($row) use ($warehouse) {
                    return [
                        'warehouse_description' => $row->warehouse->description,
                        'stock' => $row->stock,
                        'warehouse_id' => $row->warehouse_id,
                        'checked' => ($row->warehouse_id == $warehouse->id) ? true : false,
                    ];
                }),
                'attributes' => $row->attributes ? $row->attributes : [],
                'lots_group' => collect($row->lots_group)->transform(function ($row) {
                    return [
                        'id' => $row->id,
                        'code' => $row->code,
                        'quantity' => $row->quantity,
                        'date_of_due' => $row->date_of_due,
                        'checked' => false
                    ];
                }),
                'lots' => [],
                'lots_enabled' => (bool)$row->lots_enabled,
                'series_enabled' => (bool)$row->series_enabled,
            ];
        });

        // Series filtradas por contexto (oculta dedicadas / restringe al grupo activo). Ver SeriesResolver.
        $series = app(SeriesResolver::class)->applyContext(Series::where('establishment_id', $establishment->id))->get();
        // ########## INICIO CAMBIO SOLO FACTURAS Y NOTAS DE VENTA
        $document_types_invoice = DocumentType::whereIn('id', ['01'])->get();
        // ######### FIN CAMBIO SOLO FACTURAS Y NOTAS DE VENTA
        // $document_types_invoice = DocumentType::whereIn('id', ['01', '03', '80'])->get();
        $payment_method_types = PaymentMethodType::active()->get();
        $payment_destinations = $this->getPaymentDestinations();
        $affectation_igv_types = AffectationIgvType::whereActive()->get();
        $payment_conditions = PaymentCondition::get();

        return response()->json([
            'dispatch' => $dispatch,
            'document_types_invoice' => $document_types_invoice,
            'establishments' => $establishment,
            'payment_destinations' => $payment_destinations,
            'series' => $series,
            'success' => true,
            'payment_method_types' => $payment_method_types,
            'items' => $items,
            'affectation_igv_types' => $affectation_igv_types,
            'payment_conditions' => $payment_conditions,
        ], 200);

    }


    /**
     * Obtener precio unitario desde registro relacionado a la orden de entrega - convertir orden de entrega a CPE
     *
     * @param Item $item
     * @param Dispatch $dispatch
     * @param mixed $relation_external_document
     * @param bool $set_unit_price_dispatch_related_record
     * @return float
     */
    public function getDispatchSaleUnitPrice($item, $dispatch, $relation_external_document, $set_unit_price_dispatch_related_record)
    {
        if ($dispatch->isGeneratedFromExternalDocument($relation_external_document) && $set_unit_price_dispatch_related_record) {
            $exist_item = $relation_external_document->items->where('item_id', $item->id)->first();
            if ($exist_item) return $exist_item->unit_price;
        }

        return $item->sale_unit_price;
    }

    public function setDocumentId($id)
    {
        \App\Services\Fiscal\DeliveryOrderInput::order($id);
        request()->validate(['document_id' => 'required|exists:tenant.documents,id']);
        DB::connection('tenant')->beginTransaction();
        try {
            Company::lockForUpdate()->firstOrFail();
            $invoice=Document::lockForUpdate()->findOrFail(request('document_id'));
            \App\Services\Fiscal\HkaDispatchRelations::attach($invoice,['dispatch_id'=>$id]);
            DB::connection('tenant')->afterCommit(fn()=>\App\Services\Fiscal\HkaDispatchRelations::resumeInvoice($invoice->fresh()));

            $dispatch = \App\Services\Fiscal\DeliveryOrderInput::order($id);
            $facturalo = new Facturalo();
            $facturalo->createPdf($dispatch, 'dispatch', 'a4');

            DB::connection('tenant')->commit();
            return response()->json([
                'success' => true,
                'message' => 'Información actualiza'
            ], 200);
        } catch (\Throwable $th) {
            DB::connection('tenant')->rollBack();

            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al asociar la orden de entrega con el comprobante. Detalles: ' . $th->getMessage()
            ], 500);
        }

    }

    public function dispatchesByClient($clientId)
    {
        $records = Dispatch::without(['user', 'fiscal_environment_type', 'state_type', 'document_type', 'unit_type', 'transport_mode_type',
            'transfer_reason_type', 'items', 'reference_document'])
            ->select('series', 'number', 'id', 'date_of_issue')
            ->where('customer_id', $clientId)
            ->when(auth()->user()->type!=='admin',fn($q)=>$q->where('establishment_id',auth()->user()->establishment_id))
            ->whereNull('reference_document_id')
            ->whereStateTypeAccepted()
            ->orderBy('series')
            ->orderBy('number', 'desc')
            ->take(20)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $records,
        ], 200);
    }

    public function getItemsFromDispatches(Request $request)
    {
        $request->validate([
            'dispatches_id' => 'required|array|min:1',
            'dispatches_id.*' => 'required|integer|distinct|exists:tenant.dispatches,id',
        ]);

        $orders=Dispatch::whereIn('id',$request->dispatches_id)->get();
        $customer=$orders->first()->customer_id;$branch=$orders->first()->establishment_id;
        foreach ($orders as $order) {
            \App\Services\Fiscal\DeliveryOrderInput::authorize((int)$order->establishment_id);
            if ($order->customer_id!==$customer || $order->establishment_id!==$branch || $order->reference_document_id || in_array($order->state_type_id,['09','11'],true)) \App\Services\Fiscal\FiscalAmounts::error('dispatches_id','Seleccione órdenes vigentes del mismo cliente y sucursal, pendientes de facturación.');
        }
        $items = DispatchItem::whereIn('dispatch_id', $request->dispatches_id)
            ->select('item_id', 'quantity')
            ->get()->groupBy('item_id')->map(fn($rows,$itemId)=>['item_id'=>(int)$itemId,'quantity'=>$rows->sum('quantity')])->values();

        return response()->json([
            'success' => true,
            'data' => $items,
            'establishment_id'=>$branch,
        ], 200);
    }

    /**
     * Devuelve el tipo de documento disponible para órdenes de entrega.
     *
     * @return DocumentType[]|\Illuminate\Database\Eloquent\Collection|\Illuminate\Database\Query\Builder[]|\Illuminate\Support\Collection
     */
    public function getDocumentTypeToDispatches()
    {
        $doc_type = ['09'];
        $document_types_guide = DocumentType::whereIn('id', $doc_type)->get()->transform(function ($row) {
            return [
                'id' => $row->id,
                'active' => (bool)$row->active,
                'short' => $row->short,
                'description' => ucfirst(mb_strtolower(str_replace('REMITENTE ELECTRÓNICA', 'REMITENTE', $row->description))),
            ];
        });

        return $document_types_guide;
    }

    public function getOriginAddresses($id)
    {
        $records = [];
        \App\Services\Fiscal\DeliveryOrderInput::authorize((int)$id);
        $record = Establishment::query()
            ->findOrFail($id);
        $records[] = [
            'id' => 0,
            'location_id' => [
                $record->department_id,
                $record->province_id,
                $record->district_id,
            ],
            'address' => $record->address,
        ];

        $origin_addresses = OriginAddress::query()
            ->where('is_active', true)
            ->where('establishment_id',$id)
            ->get();
        foreach ($origin_addresses as $row) {
            $records[] = [
                'id' => $row->id,
                'address' => $row->address,
                'location_id' => $row->location_id,
            ];
        }

        return $records;
    }

    public function getAddressesOtherEstablishments($id)
    {
        $records = [];

        \App\Services\Fiscal\DeliveryOrderInput::authorize((int)$id);
        $other_establishments = Establishment::query()
            ->where('id', '!=', $id)->orderBy('id')
            ->get();

        foreach ($other_establishments as $establishment) {
            $records[] = [
                'id' => $establishment->id,
                'location_id' => [
                    $establishment->department_id,
                    $establishment->province_id,
                    $establishment->district_id,
                ],
                'address' => $establishment->address,
            ];
        }

        $origin_addresses = OriginAddress::query()
            ->where('is_active', true)
            ->where('establishment_id', '!=', $id)->orderBy('id')
            ->get();

        foreach ($origin_addresses as $row) {
            $records[] = [
                'id' => $row->id,
                'address' => $row->address,
                'location_id' => $row->location_id,
            ];
        }

        foreach ($records as $index => &$record) {
            $record['id'] = $index + 1;
        }

        return $records;
    }

    public function getDeliveryAddresses($id)
    {
        \App\Services\Fiscal\DeliveryOrderInput::authorize();
        $customer = Person::where('type', 'customers')->where('enabled', true)->findOrFail($id);
        $records = [];
        if (trim($customer->address ?? '') !== '' && $customer->address !== '-') {
            $records[] = [
                'id' => 0,
                'location_id' => [$customer->department_id, $customer->province_id, $customer->district_id],
                'address' => $customer->address,
            ];
        }
        foreach (\App\Models\Tenant\PersonAddress::where('person_id', $customer->id)->where('has_consigned', false)->orderBy('id')->get() as $row) {
            $records[] = [
                'id' => $row->id,
                'location_id' => [$row->department_id, $row->province_id, $row->district_id],
                'address' => $row->address,
            ];
        }
        return $records;
    }

    /**
     * Anulación interna de orden de entrega.
     * No comunica con SUNAT; solo cambia el estado y restaura stock si el motivo descuenta.
     */
    public function anulate($id)
    {
        $dispatch = \App\Services\Fiscal\DeliveryOrderInput::order($id);
        \App\Services\Fiscal\DeliveryOrderPersistence::assertEditable($dispatch);

        if ($dispatch->document_type_id !== '09') {
            return [
                'success' => false,
                'message' => 'Solo se pueden anular órdenes de entrega del remitente.',
            ];
        }

        if (!$dispatch->discountsPhysicalStock()) {
            return [
                'success' => false,
                'message' => 'Solo se pueden anular órdenes de entrega que descontaron stock en el sistema.',
            ];
        }

        if (in_array($dispatch->state_type_id, ['09', '11'], true)) {
            return [
                'success' => false,
                'message' => 'La orden de entrega ya se encuentra anulada o rechazada.',
            ];
        }

        $dispatch->getConnection()->transaction(function () use($dispatch) {
            Company::lockForUpdate()->firstOrFail();$locked=Dispatch::lockForUpdate()->findOrFail($dispatch->id);
            \App\Services\Fiscal\DeliveryOrderPersistence::assertEditable($locked);$locked->state_type_id='11';$locked->save();
        });

        return [
            'success' => true,
            'message' => 'Orden de entrega anulada internamente con éxito',
        ];
    }
}
