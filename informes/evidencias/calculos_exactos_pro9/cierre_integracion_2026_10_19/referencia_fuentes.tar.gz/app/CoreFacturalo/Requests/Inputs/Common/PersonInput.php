<?php

namespace App\CoreFacturalo\Requests\Inputs\Common;

use App\Models\Tenant\Person as PersonModel;
use App\Models\Tenant\PersonAddress;
use App\Models\Tenant\Catalogs\Country;
use App\Models\Tenant\Catalogs\Department;
use App\Models\Tenant\Catalogs\District;

//dd($customer_address, $person->telephone, $customer_address->telephone ?? null);

class PersonInput
{
    public static function set($person_id, $address_id = null, $itinerant = false)
    {
        $person = PersonModel::find($person_id);

        if(!$person) {
            return null;
        }

        $customer_address = null;
        if($address_id)
        {
            $customer_address = PersonAddress::where('person_id', $person->id)->find($address_id);
            if (!$customer_address) {
                \App\Services\Fiscal\FiscalAmounts::error('customer_address_id', 'La dirección seleccionada no pertenece al cliente.');
            }
        } else if($itinerant) {
            $customer_address = ((object) $itinerant )?? null;
        }

        if ($person->identity_document_type_id === 'ND') {
            $country = $customer_address ? $customer_address->country_id : $person->country_id;
            $address = $customer_address ? $customer_address->address : $person->address;
            if (!$country || $country === 'VE' || !trim((string) $address)) {
                \App\Services\Fiscal\FiscalAmounts::error('customer_address_id', 'Seleccione una dirección extranjera completa.');
            }
        }

        return [
            'identity_document_type_id' => $person->identity_document_type_id,
            'external_identity_type' => $person->external_identity_type,
            'identity_document_type' => [
                'id' => $person->identity_document_type_id,
                'description' => $person->identity_document_type->description,
            ],
            'number' => $person->number,
            'name' => $person->name,
            'trade_name' => $person->trade_name,
            'country_id' => ($customer_address) ? $customer_address->country_id : $person->country_id,
            'country' => [
                'id' => ($customer_address) ? $customer_address->country_id : $person->country_id,
                'description' => ($itinerant) == true ?  optional($customer_address->country)->description :  optional($person->country)->description,
            ],
            'department_id' =>  ($customer_address) ? $customer_address->department_id : $person->department_id,
            'department' => [
                'id' =>  ($customer_address) ? $customer_address->department_id : $person->department_id,  //$person->department_id,
                'description' => ($itinerant) == true ? optional($customer_address->department)->description :  optional($person->department)->description, // optional($person->department)->description,
            ],
            'province_id' => ($customer_address) ? $customer_address->province_id : $person->province_id, //$person->province_id,
            'province' => [
                'id' => ($customer_address) ? $customer_address->province_id : $person->province_id, //$person->province_id,
                'description' => ($itinerant) == true ?  optional($customer_address->province)->description :  optional($person->province)->description, //optional($person->province)->description,
            ],
            'district_id' =>  ($customer_address) ? $customer_address->district_id : $person->district_id, //$person->district_id,
            'district' => [
                'id' => ($customer_address) ? $customer_address->district_id : $person->district_id, //$person->district_id,
                'description' => ($itinerant) == true ?  optional($customer_address->district)->description :  optional($person->district)->description, //optional($person->district)->description,
            ],
            'address' =>  ($customer_address) ? $customer_address->address : $person->address,//$person->address,
            'email' => ($itinerant) == true ? $customer_address  : $person->email,  //$person->email,
            'telephone' => ($customer_address && $customer_address->telephone)? $customer_address->telephone : $person->telephone, //$person->telephone,
            'perception_agent' => $person->perception_agent,
            'address_id' => $address_id,
            'internal_code' => $person->internal_code,
            'address_type_id' => $person->address_type_id,
            'address_type' => [
                'id' => $person->address_type_id,
                'description' => optional($person->address_type)->description,
            ],
        ];
    }
}
