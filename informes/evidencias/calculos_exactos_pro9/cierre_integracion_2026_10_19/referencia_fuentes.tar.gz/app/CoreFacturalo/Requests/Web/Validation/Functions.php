<?php

namespace App\CoreFacturalo\Requests\Web\Validation;

use App\Models\Tenant\{
    Configuration,
    Establishment,
    Document,
    Series,
    Person,
    Item
};
use App\Models\Tenant\Catalogs\UnitType;
use App\Services\SeriesCodeGenerator;
use App\Services\SalesCustomerIdentityPolicy;
use App\Support\Venezuela\IdentityDocument;
use Exception;

class Functions
{
    public static function establishment($inputs)
    {
        $establishment = Establishment::where('code', $inputs['code'])->first();

        if ($establishment) {
            return $establishment->id;
        }

        throw new Exception("El código ingresado del establecimiento es incorrecto.");
    }

    public static function validateSeries($inputs)
    {
        return \App\Services\SeriesNumbering::resolve($inputs['document_type_id'], $inputs['series'] ?? null, (int) $inputs['establishment_id']);
    }

    public static function person($inputs, $type)
    {
        if (isset($inputs['id'])) return Person::find($inputs['id'])->id;

        $district_id = $inputs['district_id'];
        $province_id = ($district_id) ? substr($district_id, 0, 4) : null;
        $department_id = ($district_id) ? substr($district_id, 0, 2) : null;

        $person = Person::updateOrCreate([
            'type' => $type,
            'identity_document_type_id' => $inputs['identity_document_type_id'],
            'number' => $inputs['number'],
        ], [
            'name' => $inputs['name'],
            'trade_name' => $inputs['trade_name'],
            'country_id' => $inputs['country_id'],
            'department_id' => $department_id,
            'province_id' => $province_id,
            'district_id' => $district_id,
            'address' => $inputs['address'],
            'email' => $inputs['email'],
            'telephone' => $inputs['telephone'],
        ]);

        return $person->id;
    }

    public static function item($inputs)
    {
        // ######## INICIO CONTRATO UNIDADES DE MEDIDA VENEZUELA ########
        $inputs['unit_type_id'] = UnitType::requireActiveCode($inputs['unit_type_id'] ?? null);
        // ######## FIN CONTRATO UNIDADES DE MEDIDA VENEZUELA ########
        $item = Item::updateOrCreate([
            'internal_id' => $inputs['internal_id'],
        ], [
            'description' => $inputs['description'],
            'item_type_id' => $inputs['item_type_id'],
            'item_code' => $inputs['item_code'],
            'item_code_gs1' => $inputs['item_code_gs1'],
            'unit_type_id' => $inputs['unit_type_id'],
            'currency_type_id' => $inputs['currency_type_id'],
            'unit_price' => $inputs['unit_price'],
        ]);

        return $item->id;
    }

    public static function findAffectedDocumentByExternalId($external_id)
    {
        $document = Document::where('external_id', $external_id)
            ->first();

        if (!$document) {
            throw new Exception("No se encontró el documento con código externo {$external_id}.");
        }
        return $document;
    }

    public static function findSeries($inputs)
    {
        $code = $inputs['series'] ?? null;
        if (!empty($inputs['series_id'])) {
            $series = Series::findOrFail($inputs['series_id']);
            $code = $series->number;
        }
        if ($code !== null && !is_string($code)) throw new Exception('La serie debe ser un texto.');
        return \App\Services\SeriesNumbering::resolve($inputs['document_type_id'], $code, (int) $inputs['establishment_id']);
    }

    private static function validateNrusSeries($series): void
    {
        if (! $series || ! (bool) optional(Configuration::first())->isNrus()) {
            return;
        }

        if (! in_array($series->document_type_id, SeriesCodeGenerator::nrusDocumentTypeIds(), true)) {
            throw new Exception("Para empresas NRUS solo están disponibles las series de Nota de venta.");
        }
    }

    public static function findAffectedDocument($inputs)
    {
        return Document::find($inputs['affected_document_id']);
    }

    public static function DNI($inputs)
    {
    }

    public static function identityDocumentTypeInvoice($inputs)
    {
        // ######## INICIO POLITICA IDENTIDAD ACTIVA EN VENTAS ########
        SalesCustomerIdentityPolicy::assertCustomerAllowed($inputs['customer_id'] ?? null, \App\Services\ExportInvoicePolicy::isExport(\App\Services\ExportInvoicePolicy::operation($inputs)));
        // ######## FIN POLITICA IDENTIDAD ACTIVA EN VENTAS ########
    }

}
