<?php

namespace App\CoreFacturalo\Requests\Api\Transform;

use App\CoreFacturalo\Requests\Api\Transform\Common\EstablishmentTransform;
use App\CoreFacturalo\Requests\Api\Transform\Common\PersonTransform;
use App\CoreFacturalo\Requests\Api\Transform\Common\ActionTransform;
use App\CoreFacturalo\Requests\Api\Transform\Common\LegendTransform;
use App\Models\Tenant\User;
use App\Support\Venezuela\VendeyaDocumentPayloadNormalizer;

class DocumentTransform
{
    public static function transform($inputs)
    {
        $inputs = \App\Support\Venezuela\RetiredDetractionFields::discard($inputs);
        // ######## INICIO MIGRACIÓN MONEDA VENEZUELA ########
        // ########## INICIO CAMBIO AFECTACIÓN IVA
        $inputs = VendeyaDocumentPayloadNormalizer::normalize($inputs);
        // ######### FIN CAMBIO AFECTACIÓN IVA
        // ######## FIN MIGRACIÓN MONEDA VENEZUELA ########

        if (strtoupper((string) ($inputs['source_module'] ?? '')) === 'VENDEYA') {
            $sellerId = $inputs['codigo_vendedor'] ?? null;

            if (!$sellerId || !User::query()->whereKey($sellerId)->exists()) {
                $inputs['codigo_vendedor'] = auth()->id();
            }
        }

        $totals = $inputs['totales'];

        // foreach ($inputs['items'] as $key => $value) {
        //     $inputs['items'][$key]['codigo_interno'] = ($inputs['items'][$key]['codigo_interno']) ? $inputs['items'][$key]['codigo_interno']:'';
        //     $inputs['items'][$key]['codigo_producto_sunat'] = ($inputs['items'][$key]['codigo_producto_sunat']) ? $inputs['items'][$key]['codigo_producto_sunat']:'';
        // }

        $inputs_transform = [
            'series' => Functions::valueKeyInArray($inputs, 'serie_documento'),
            'number' => Functions::valueKeyInArray($inputs, 'numero_documento'),
            'consigned_id' => Functions::valueKeyInArray($inputs, 'codigo_consignado'),
            'consigned_address_id' => Functions::valueKeyInArray($inputs, 'codigo_direccion_consignado'),
            'consigned_ubigeo' => Functions::valueKeyInArray($inputs, 'consignado_ubigeo'),
            'consigned_address' => Functions::valueKeyInArray($inputs, 'consignado_direccion'),
            'date_of_issue' => Functions::valueKeyInArray($inputs, 'fecha_de_emision'),
            'time_of_issue' => Functions::valueKeyInArray($inputs, 'hora_de_emision'),
            'document_type_id' => Functions::valueKeyInArray($inputs, 'codigo_tipo_documento'),
            'currency_type_id' => Functions::valueKeyInArray($inputs, 'codigo_tipo_moneda'),
            'taxes' => $inputs['taxes'] ?? [],
            'fiscal_data' => $inputs['fiscal_data'] ?? [],
            'received_retentions' => $inputs['received_retentions'] ?? [],
            'islr_retention_prevision' => $inputs['islr_retention_prevision'] ?? null,
            'iva_retention_prevision' => $inputs['iva_retention_prevision'] ?? null,
            'guarantee_fund' => $inputs['guarantee_fund'] ?? null,
            'exchange_rate_source' => $inputs['exchange_rate_source'] ?? 'manual',
            'exchange_rate_date' => $inputs['exchange_rate_date'] ?? null,
            'exchange_rate_sale' => Functions::valueKeyInArray($inputs, 'factor_tipo_de_cambio', 1),
            'purchase_order' => Functions::valueKeyInArray($inputs, 'numero_orden_de_compra'),
            'plate_number' => Functions::valueKeyInArray($inputs, 'numero_de_placa'),
            'folio' => Functions::valueKeyInArray($inputs, 'folio'),
//            'establishment' => EstablishmentTransform::transform($inputs['datos_del_emisor']),
            'customer' => PersonTransform::transform($inputs['datos_del_cliente_o_receptor']),
            'total_prepayment' => Functions::valueKeyInArray($totals, 'total_anticipos'),
            'total_discount' => Functions::valueKeyInArray($totals, 'total_descuentos'),
            'total_charge' => Functions::valueKeyInArray($totals, 'total_cargos'),
            'total_exportation' => Functions::valueKeyInArray($totals, 'total_exportacion'),
            'total_taxed' => Functions::valueKeyInArray($totals, 'total_operaciones_gravadas'),
            'total_exonerated' => Functions::valueKeyInArray($totals, 'total_operaciones_exoneradas'),
            'total_igv' => Functions::valueKeyInArray($totals, 'total_igv'),
            'total_base_other_taxes' => Functions::valueKeyInArray($totals, 'total_base_otros_impuestos'),
            'total_other_taxes' => Functions::valueKeyInArray($totals, 'total_otros_impuestos'),
            'total_taxes' => Functions::valueKeyInArray($totals, 'total_impuestos'),
            'total_value' => Functions::valueKeyInArray($totals, 'total_valor'),
            'subtotal' => (Functions::valueKeyInArray($totals, 'subtotal_venta')) ? $totals['subtotal_venta'] : $totals['total_venta'],
            'total' => Functions::valueKeyInArray($totals, 'total_venta'),
            'total_pending_payment' => Functions::valueKeyInArray($totals, 'total_pendiente_pago'),
            'has_prepayment' => Functions::valueKeyInArray($inputs, 'pago_anticipado',0),
            'is_itinerant' => Functions::valueKeyInArray($inputs, 'es_itinerante', false),
            'items' => self::items($inputs),
            'charges' => self::charges($inputs),
            'discounts' => self::discounts($inputs),
            'prepayments' => self::prepayments($inputs),
            'guides' => self::guides($inputs),
            'related' => self::related($inputs),
            'legends' => LegendTransform::transform($inputs),
            'additional_information' => Functions::valueKeyInArray($inputs, 'informacion_adicional'),
            'additional_data' => Functions::valueKeyInArray($inputs, 'dato_adicional'),
            'actions' => ActionTransform::transform($inputs),
            'hotel' => Functions::valueKeyInArray($inputs, 'hotel',[]),
            'transport' => Functions::valueKeyInArray($inputs, 'transport',[]),
            'payments' => self::payments($inputs),
            'data_json' => $inputs,
            'fee' => self::fee($inputs),
            'payment_condition_id' => Functions::valueKeyInArray($inputs, 'codigo_condicion_de_pago', '01'),
            'sale_note_id' => Functions::valueKeyInArray($inputs, 'codigo_nota_venta'),
            'seller_id' => Functions::valueKeyInArray($inputs, 'codigo_vendedor'),
            'terms_condition' => Functions::valueKeyInArray($inputs, 'terminos_condiciones'),
            'source_module' => Functions::valueKeyInArray($inputs, 'source_module'),
            'hotel_rent_id' => Functions::valueKeyInArray($inputs, 'hotel_rent_id'),
        ];

        $inputs_transform = self::invoice($inputs_transform, $inputs);
        $inputs_transform = self::note($inputs_transform, $inputs);

        return $inputs_transform;
    }


    private static function items($inputs)
    {
        if(key_exists('items', $inputs)) {
            $items = [];
            foreach ($inputs['items'] as $row) {
                $item = [
                    'internal_id' => isset($row['codigo_interno']) ? $row['codigo_interno']:'',
                    'description' => $row['descripcion'],
                    'name' => Functions::valueKeyInArray($row, 'nombre'),
                    'second_name' => Functions::valueKeyInArray($row, 'nombre_secundario'),
                    'item_type_id' => Functions::valueKeyInArray($row, 'codigo_tipo_item', '01'),
                    'item_code' => Functions::valueKeyInArray($row, 'codigo_producto_sunat'),
                    'item_code_gs1' => Functions::valueKeyInArray($row, 'codigo_producto_gsl'),
                    'unit_type_id' => strtoupper($row['unidad_de_medida']),
                    'currency_type_id' => $inputs['codigo_tipo_moneda'],

                    'quantity' => Functions::valueKeyInArray($row, 'cantidad'),
                    'unit_value' => Functions::valueKeyInArray($row, 'valor_unitario'),
                    'price_type_id' => Functions::valueKeyInArray($row, 'codigo_tipo_precio'),
                    'unit_price' => Functions::valueKeyInArray($row, 'precio_unitario'),
                    'price_input' => $row['price_input'] ?? null,
                    'quantity_input' => $row['quantity_input'] ?? null,

                    'affectation_igv_type_id' => Functions::valueKeyInArray($row, 'codigo_tipo_afectacion_igv'),
                    'total_base_igv' => Functions::valueKeyInArray($row, 'total_base_igv'),
                    'percentage_igv' => Functions::valueKeyInArray($row, 'porcentaje_igv'),
                    'total_igv' => Functions::valueKeyInArray($row, 'total_igv'),

                    'total_base_other_taxes' => Functions::valueKeyInArray($row, 'total_base_otros_impuestos'),
                    'percentage_other_taxes' => Functions::valueKeyInArray($row, 'porcentaje_otros_impuestos'),
                    'total_other_taxes' => Functions::valueKeyInArray($row, 'total_otros_impuestos'),

                    'total_taxes' => Functions::valueKeyInArray($row, 'total_impuestos'),
                    'total_value' => Functions::valueKeyInArray($row, 'total_valor_item'),
                    'total_charge' => Functions::valueKeyInArray($row, 'total_cargos'),
                    'total_discount' => Functions::valueKeyInArray($row, 'total_descuentos'),
                    'total' => Functions::valueKeyInArray($row, 'total_item'),

                    'attributes' => self::attributes($row),
                    'discounts' => self::discounts($row),
                    'charges' => self::charges($row),
                    'additional_information' => Functions::valueKeyInArray($row, 'informacion_adicional'),
                    'lots' => Functions::valueKeyInArray($row, 'lots', []),
                    'update_description' => Functions::valueKeyInArray($row, 'actualizar_descripcion', true), //variable para determinar si se actualiza la descripcion del item cuando se envia desde api
                    'name_product_pdf' => Functions::valueKeyInArray($row, 'nombre_producto_pdf'),
                    'additional_data' => Functions::valueKeyInArray($row, 'dato_adicional'),
                    'esFusionado' => Functions::valueKeyInArray($row, 'esFusionado', false),
                ];

                $presentation = Functions::valueKeyInArray($row, 'presentacion');
                if (!empty($presentation)) {
                    $item['item'] = [
                        'unit_type_id' => strtoupper($row['unidad_de_medida']),
                        'presentation' => $presentation,
                    ];
                }

                $items[] = $item;
            }

            return $items;
        }
        return null;
    }

    private static function attributes($inputs)
    {
        if(key_exists('datos_adicionales', $inputs)) {
            $attributes = [];
            foreach ($inputs['datos_adicionales'] as $row)
            {
                $attributes[] = [
                    'attribute_type_id' => $row['codigo'],
                    'description' => $row['descripcion'],
                    'value' => Functions::valueKeyInArray($row, 'valor'),
                    'start_date' => Functions::valueKeyInArray($row, 'fecha_inicio'),
                    'end_date' => Functions::valueKeyInArray($row, 'fecha_fin'),
                    'duration' => Functions::valueKeyInArray($row, 'duracion'),
                ];
            }

            return $attributes;
        }
        return null;
    }

    private static function charges($inputs)
    {
        if(key_exists('cargos', $inputs)) {
            $charges = [];
            foreach ($inputs['cargos'] as $row)
            {
                $charges[] = [
                    'charge_type_id' => $row['codigo'],
                    'description' => $row['descripcion'],
                    'factor' => $row['factor'],
                    'amount' => $row['monto'],
                    'base' =>  $row['base'],
                ];
            }

            return $charges;
        }
        return null;
    }

    private static function discounts($inputs)
    {
        if(key_exists('descuentos', $inputs)) {
            $discounts = [];
            foreach ($inputs['descuentos'] as $row) {
                // $is_amount = $row['is_amount'] ?? null; //registra si el descuento fue por monto o porcentaje
                // ########## INICIO CAMBIO IGV A IVA
                $amount_without_rounded = $row['cantidad_sin_redondeo'] ?? null; // monto sin redondear para cálculos posteriores, principalmente para descuentos que afectan base imponible del IVA
                // ######### FIN CAMBIO IGV A IVA
                $from_global_distribution = $row['global_distribucion'] ?? null;
                $discounts[] = [
                    'discount_type_id' => $row['codigo'],
                    'description' => $row['descripcion'],
                    'from_global_distribution' => $from_global_distribution, // para identificar si el descuento viene de una distribución global o es un descuento directo del item
                    'factor' => $row['factor'],
                    'amount' => $row['monto'],
                    'base' =>  $row['base'],
                    'amount_without_rounded'  => $amount_without_rounded,
                    // 'is_amount' => $is_amount,
                ];
            }

            return $discounts;
        }
        return null;
    }


    private static function parseLocation($district_id)
    {
        $province_id = $district_id ? substr($district_id, 0 ,4) : null;
        $department_id = $district_id ? substr($district_id, 0 ,2) : null;

        return [
            $department_id,
            $province_id,
            $district_id
        ];
    }






    private static function prepayments($inputs)
    {
        if(key_exists('anticipos', $inputs)) {
            $prepayments = [];
            foreach ($inputs['anticipos'] as $row)
            {
                $prepayments[] = [
                    'number' => $row['numero'],
                    'document_type_id' => $row['codigo_tipo_documento'],
                    'amount' => $row['monto'],
                    'total' => $row['total']
                ];
            }

            return $prepayments;
        }
        return null;
    }

    private static function guides($inputs)
    {
        if(key_exists('guias', $inputs)) {
            $guides = [];
            foreach ($inputs['guias'] as $row)
            {
                $guides[] = [
                    'number' => $row['numero'],
                    'document_type_id' => $row['codigo_tipo_documento'],
                ];
            }

            return $guides;
        }
        return null;
    }

    private static function related($inputs)
    {
        if(key_exists('relacionados', $inputs)) {
            $related = [];
            foreach ($inputs['relacionados'] as $row)
            {
                $related[] = [
                    'number' => $row['numero'],
                    'document_type_id' => $row['codigo_tipo_documento'],
                    'amount' => $row['monto']
                ];
            }

            return $related;
        }
        return null;
    }

    private static function invoice($inputs_transform, $inputs)
    {
        if($inputs['codigo_tipo_documento'] === '01') {
            $inputs_transform['operation_type_id'] = Functions::valueKeyInArray($inputs, 'codigo_tipo_operacion');
            $inputs_transform['date_of_due'] = Functions::valueKeyInArray($inputs, 'fecha_de_vencimiento');
        }
        return $inputs_transform;
    }

    private static function note($inputs_transform, $inputs)
    {
        if(in_array($inputs['codigo_tipo_documento'], ['07', '08'])) {
            $inputs_transform['note_credit_or_debit_type_id'] = Functions::valueKeyInArray($inputs, 'codigo_tipo_nota');
            $inputs_transform['note_description'] = Functions::valueKeyInArray($inputs, 'motivo_o_sustento_de_nota');
            $inputs_transform['affected_document_external_id'] = Functions::valueKeyInArray($inputs['documento_afectado'], 'external_id');

            if(!$inputs_transform['affected_document_external_id']){


                $inputs_transform['data_affected_document']['number'] = Functions::valueKeyInArray($inputs['documento_afectado'], 'numero_documento');
                $inputs_transform['data_affected_document']['series'] = Functions::valueKeyInArray($inputs['documento_afectado'], 'serie_documento');
                $inputs_transform['data_affected_document']['document_type_id'] = Functions::valueKeyInArray($inputs['documento_afectado'], 'codigo_tipo_documento');

                // dd($inputs);
            }
        }
        return $inputs_transform;
    }


    private static function payments($inputs)
    {
        if($inputs['codigo_tipo_documento'] === '01') {

            $payments = [];

            if(key_exists('pagos', $inputs)) {

                foreach ($inputs['pagos'] as $row) {
                    if (isset($row['currency_type_id'])) {
                        validator($row,['operation_key'=>'required|uuid'])->validate();
                        if ($row['currency_type_id'] !== $inputs['codigo_tipo_moneda']) {
                            validator($row,['original_amount'=>'required|numeric|gt:0','exchange_rate'=>'required|numeric|gt:0'])->validate();
                        }
                    }
                    $payments[] = [
                        'date_of_payment' => Functions::valueKeyInArray($inputs, 'fecha_de_emision'),
                        'payment_method_type_id' => $row['codigo_metodo_pago'],
                        'payment_destination_id' => $row['codigo_destino_pago'],
                        'reference' => Functions::valueKeyInArray($row, 'referencia'),
                        'payment' => Functions::valueKeyInArray($row, 'monto', 0),
                        'original_amount' => $row['original_amount'] ?? $row['monto'],
                        'currency_type_id' => $row['currency_type_id'] ?? $inputs['codigo_tipo_moneda'],
                        'exchange_rate' => $row['exchange_rate'] ?? $inputs['tipo_cambio_venta'],
                        'exchange_rate_source' => $row['exchange_rate_source'] ?? 'manual',
                        'exchange_rate_date' => $row['exchange_rate_date'] ?? $inputs['fecha_de_emision'],
                        'igtf_status' => $row['igtf_status'] ?? 'not_applicable',
                        'exemption_reason' => $row['exemption_reason'] ?? null,
                        'exception_basis' => $row['exception_basis'] ?? null,
                        'financial_intermediation' => $row['financial_intermediation'] ?? null,
                        'operation_key' => $row['operation_key'] ?? (string) \Illuminate\Support\Str::uuid(),
                        'payment_received' => Functions::valueKeyInArray($row, 'pago_recibido'),
                    ];
                }

            }

            return $payments;

        }

        return [];
    }

    private static function fee($inputs)
    {
        $fee = [];
        if (key_exists('cuotas', $inputs)) {
            foreach ($inputs['cuotas'] as $row) {
                $fee[] = [
                    'date' => $row['fecha'],
                    'currency_type_id' => $row['codigo_tipo_moneda'],
                    'amount' => $row['monto'],
                    'payment_method_type_id' => Functions::valueKeyInArray($row, 'codigo_metodo_de_pago'),
                ];
            }
        }

        return $fee;
    }
}
