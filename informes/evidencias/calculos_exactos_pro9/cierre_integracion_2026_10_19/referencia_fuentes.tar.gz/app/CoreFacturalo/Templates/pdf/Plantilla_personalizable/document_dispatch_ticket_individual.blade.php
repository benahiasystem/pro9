@php
    $customer = $document->customer;
    $document_number = \App\Services\Fiscal\FiscalIdentity::numberFull($document->series, $document->number);
@endphp
<html>
<body class="ticket">
    @php
        $count = (int)$document->itemChunk->quantity;
    @endphp

    <br>
    <table class="full-width" style="border: 1px solid #000;">
        <tr>
            <td class="desc">@include('pdf.partials.company_document_header_names_plain')</td>
            <td class="text-right desc">Fecha: {{ $document->created_at->format('Y-m-d H:i') }}</td>
        </tr>
        <tr>
            <td></td>
            <td class="text-right desc">{{ $document_number }}</td>
        </tr>
        <tr>
            <td colspan="2" class="text-center">
                <h4>{{ $document->itemChunk->item->description }} {{ $document->currency_type->symbol }} {{ \App\Support\Exact\PdfPrice::configured(\App\Support\Exact\Decimal::read($document->itemChunk, 'unit_price'))}}</h4>
            </td>
        </tr>
        <tr>
            <td colspan="2" class="text-center desc">
                VÁLIDO SOLO POR HOY
            </td>
        </tr>
    </table>
</body>
</html>
