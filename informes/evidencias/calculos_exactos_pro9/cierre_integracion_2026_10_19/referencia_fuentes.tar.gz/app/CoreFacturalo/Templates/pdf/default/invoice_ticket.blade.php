{{-- ######## INICIO PERSISTENCIA FISCAL VENEZUELA ######## --}}
{{-- ######## INICIO MIGRACIÓN MONEDA VENEZUELA ######## --}}
@php
    use Modules\Template\Helpers\TemplatePdf;

    $establishment = $document->establishment;
    $customer = $document->customer;
    $invoice = $document->invoice;
    //$path_style = app_path('CoreFacturalo'.DIRECTORY_SEPARATOR.'Templates'.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.'style.css');
    /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$document_number = $document->number_full;
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */

    // $accounts = \App\Models\Tenant\BankAccount::where('show_in_documents', true)->get();
    $accounts = (new TemplatePdf)->getBankAccountsForPdf($document->establishment_id);

    $document_base = ($document->note) ? $document->note : null;
    $payments = $document->payments;
    $third_party_sale = \App\Services\Fiscal\HkaDomesticInvoicePolicy::applies($document);
    $discount_for_totals = $third_party_sale ? (float) $document->total_discount : (float) $document->total_discount_with_igv;
    $igtf_for_totals = $third_party_sale ? collect($document->taxes ?? [])->where('tax_kind', 'IGTF')->sum('amount') : 0;

    if($document_base) {
        /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$affected_document_number = $document_base->affected_document ? $document_base->affected_document->number_full : \App\Services\Fiscal\FiscalIdentity::numberFull($document_base->data_affected_document->series ?? '', $document_base->data_affected_document->number);
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */

    } else {
        $affected_document_number = null;
    }
    $document->load('reference_guides');

    $total_payment = $document->payments->sum('payment');
    $balance = $document instanceof \App\Models\Tenant\Document ? $document->balance : (($document->total - $total_payment) - $document->payments->sum('change'));


    $logo = "storage/uploads/logos/{$company->logo}";
    if($establishment->logo) {
        $logo = "{$establishment->logo}";
    }

    $configurationInPdf= App\CoreFacturalo\Helpers\Template\TemplateHelper::getConfigurationInPdf();

    $max_chars_description = config('tenant.enabled_template_ticket_80') ? 46 : 47;

@endphp
<html>
<head>
    {{--<title>{{ $document_number }}</title>--}}
    {{--<link href="{{ $path_style }}" rel="stylesheet" />--}}
</head>
<body class="ticket">

@if($company->logo)
    <div class="text-center company_logo_box pt-5">
        <img
            src="data:{{mime_content_type(public_path("{$logo}"))}};base64, {{base64_encode(file_get_contents(public_path("{$logo}")))}}"
            alt="{{ \App\CoreFacturalo\Helpers\CompanyDocumentDisplay::logoAlt($company) }}" class="company_logo_ticket contain">
    </div>
    {{--@else--}}
    {{--<div class="text-center company_logo_box pt-5">--}}
    {{--<img src="{{ asset('logo/logo.jpg') }}" class="company_logo_ticket contain">--}}
    {{--</div>--}}
@endif

@if($document->state_type->id == '11')
    <div class="company_logo_box" style="position: absolute; text-align: center; top:500px">
        <img
            src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png")))}}"
            alt="anulado" class="" style="opacity: 0.6;">
    </div>
@endif
@if($document->state_type->id == '09')
    <div style="position: absolute; width: 100%; text-align: center; top:30%; left: 0; right: 0; margin: auto;">
        <img
            src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png")))}}"
            alt="rechazado" class="" style="opacity: 0.6; width: 50%;">
    </div>
@endif
@if(isset($configuration['is_preview']) && $configuration['is_preview'])
    <div style="position: absolute; width: 100%; text-align: center; top:30%; left: 0; right: 0; margin: auto;">
        <img
            src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."vista_previa.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."vista_previa.png")))}}"
            alt="vista previa" class="" style="opacity: 0.6; width: 50%;">
    </div>
@endif
<table class="full-width">
    <tr>
        <td class="text-center">@include('pdf.partials.company_document_header_names')</td>
    </tr>
    {{--<tr>
        <td class="text-center"><h5>{{ $company->trade_name }}</h5></td>
    </tr>--}}
    <tr>
        <td class="text-center"><h5>{{ 'RIF '.$company->number }}</h5></td>
    </tr>
    <tr>
        <td class="text-center" style="text-transform: uppercase;">
            {{ ($establishment->address !== '-')? $establishment->address : '' }}
            {{ ($establishment->district_id !== '-')? ', '.$establishment->district->description : '' }}
            {{ ($establishment->province_id !== '-')? ', '.$establishment->province->description : '' }}
            {{ ($establishment->department_id !== '-')? '- '.$establishment->department->description : '' }}
        </td>
    </tr>

    @isset($establishment->trade_address)
        <tr>
            <td class="text-center ">{{  ($establishment->trade_address !== '-')? 'D. Comercial: '.$establishment->trade_address : ''  }}</td>
        </tr>
    @endisset
    <tr>
        <td class="text-center ">{{ ($establishment->telephone !== '-')? 'Central telefónica: '.$establishment->telephone : '' }}</td>
    </tr>
    <tr>
        <td class="text-center">{{ ($establishment->email !== '-')? 'Email: '.$establishment->email : '' }}</td>
    </tr>
    @isset($establishment->web_address)
        <tr>
            <td class="text-center">{{ ($establishment->web_address !== '-')? 'Web: '.$establishment->web_address : '' }}</td>
        </tr>
    @endisset

    @isset($establishment->aditional_information)
        <tr>
            <td class="text-center pb-3">{{ ($establishment->aditional_information !== '-')? $establishment->aditional_information : '' }}</td>
        </tr>
    @endisset
    <tr>
        <td class="text-center pt-3 border-top"><h3>{{ 'R.I.F. '.$company->number }}</h3></td>
    </tr>
    <tr>
        <td class="text-center"><h4>{{ \App\Services\ExportInvoicePolicy::isExport($invoice->operation_type_id ?? '') ? 'FACTURA DE EXPORTACIÓN · '.\App\Services\ExportInvoicePolicy::INCOTERMS[$invoice->operation_type_id] : $document->document_type->description }}</h4>
        </td>
    </tr>
    <tr>
        <td class="text-center pb-3 border-bottom"><h3>{{ $document_number }}</h3></td>
    </tr>
</table>
<table class="full-width">
    <tr>
        <td width="" class="pt-3"><p class="desc">F. Emisión:</p></td>
        <td width="" class="pt-3"><p class="desc">{{ $document->date_of_issue->format('Y-m-d') }}</p></td>
    </tr>
    <tr>
        <td width=""><p class="desc">H. Emisión:</p></td>
        <td width=""><p class="desc">{{ $document->time_of_issue }}</p></td>
    </tr>
    @isset($invoice->date_of_due)
        <tr>
            <td><p class="desc">F. Vencimiento:</p></td>
            <td><p class="desc">{{ $invoice->date_of_due->format('Y-m-d') }}</p></td>
        </tr>
    @endisset

    <tr>
        <td class="align-top"><p class="desc">Cliente:</p></td>
        <td><p class="desc">{{ $customer->name }}</p></td>
    </tr>
    <tr>
        <td><p class="desc">{{ ($customer->identity_document_type_id ?? '') === 'ND' ? $customer->external_identity_type : $customer->identity_document_type->description }}:</p></td>
        <td><p class="desc">{{ format_identity_document($customer->identity_document_type_id ?? null, $customer->number) }}</p></td>
    </tr>
    @if ($customer->address !== '')
        <tr>
            <td class="align-top"><p class="desc">Dirección:</p></td>
            <td>
                <p class="desc">
                    {{ $customer->address }}
                    @if(($customer->identity_document_type_id ?? '') === 'ND')
                        {{ ', '.$customer->country->description }}
                    @else
                        {{ ($customer->district->description ?? '') !== '' ? ', '.$customer->district->description : '' }}
                        {{ ($customer->province->description ?? '') !== '' ? ', '.$customer->province->description : '' }}
                        {{ ($customer->department->description ?? '') !== '' ? '- '.$customer->department->description : '' }}
                    @endif
                </p>
            </td>
        </tr>
    @endif
    @if ($document->consigned_id)
    @php
        $consigned = App\Models\Tenant\Consigned::where('id',$document->consigned_id)->first();
        $district = App\Models\Tenant\Catalogs\District::where('id', $document->consigned_ubigeo)->first();
        $consigned_phone = App\Models\Tenant\PersonAddress::where('person_id', $document->customer_id)
            ->where('address', $document->consigned_address)
            ->where('consigned_id', $document->consigned_id)
            ->first();

        if($district){
            $department = $district->province->department;
            $province = $district->province;
        }
    @endphp
    <tr>
        <td class="align-top"><p class="desc">Consignado:</p></td>
        <td>
            <p class="desc">
                {{ $consigned->number }} -
                {{ $consigned->name }} -
                {{ ($consigned_phone->phone)? $consigned_phone->phone : ' ' }} -
                {{ $document->consigned_address }}
                {{($district) ? ' , '.$district->description.' , '.$province->description.' , '.$department->description: ' '}}
            </p>
        </td>
    </tr>
@endif


    @if ($document->reference_data)
        <tr>
            <td class="align-top"><p class="desc">D. Referencia:</p></td>
            <td>
                <p class="desc">
                    {{ $document->reference_data }}
                </p>
            </td>
        </tr>
    @endif

    @if ($document->isPointSystem())
        <tr>
            <td><p class="desc">P. Acumulados:</p></td>
            <td><p class="desc">{{ $document->person->accumulated_points }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">Puntos por la compra:</p></td>
            <td><p class="desc">{{ $document->getPointsBySale() }}</p></td>
        </tr>
    @endif






    @if ($document->prepayments)
        @foreach($document->prepayments as $p)
            <tr>
                <td><p class="desc">Anticipo :</p></td>
                <td><p class="desc">{{$p->number}}</p></td>
            </tr>
        @endforeach
    @endif
    @if ($document->purchase_order)
        <tr>
            <td><p class="desc">Orden de Compra:</p></td>
            <td><p class="desc">{{ $document->purchase_order }}</p></td>
        </tr>
    @endif
    @if ($document->quotation_id)
        <tr>
            <td><p class="desc">Cotización:</p></td>
            <td><p class="desc">{{ $document->quotation->identifier }}</p></td>
        </tr>
    @endif
    @isset($document->quotation->delivery_date)
        <tr>
            <td><p class="desc">F. Entrega</p></td>
            <td>
                <p class="desc">{{ $document->date_of_issue->addDays($document->quotation->delivery_date)->format('d-m-Y') }}</p>
            </td>
        </tr>
    @endisset
    @isset($document->quotation->sale_opportunity)
        <tr>
            <td><p class="desc">O. Venta</p></td>
            <td><p class="desc">{{ $document->quotation->sale_opportunity->number_full}}</p></td>
        </tr>
    @endisset
    @if ($document->plate_number !== null)
    <tr>
        <td ><p class="desc">N° Placa:</p></td>
        <td ><p class="desc">{{ $document->plate_number }}</p></td>
    </tr>
    @endif
</table>

@if ($document->guides)
    {{--<strong>Órdenes de entrega:</strong>--}}
    <table>
        @foreach($document->guides as $guide)
            <tr>
                @if(isset($guide->document_type_description))
                    <td class="desc">{{ $guide->document_type_description }}</td>
                @else
                    <td class="desc">{{ $guide->document_type_id }}</td>
                @endif
                <td class="desc">:</td>
                <td class="desc">{{ $guide->number }}</td>
            </tr>
        @endforeach
    </table>
@endif


@if ($document->transport)
    <p class="desc"><strong>Transporte de pasajeros</strong></p>

    @php
        $transport = $document->transport;
        $origin_district_id = (array)$transport->origin_district_id;
        $destinatation_district_id = (array)$transport->destinatation_district_id;
        $origin_district = Modules\Order\Services\AddressFullService::getDescription($origin_district_id[2]);
        $destinatation_district = Modules\Order\Services\AddressFullService::getDescription($destinatation_district_id[2]);
    @endphp


    <table class="full-width mt-3">
        <tr>
            <td><p class="desc">{{ $transport->identity_document_type->description }}:</p></td>
            <td><p class="desc">{{ $transport->number_identity_document }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">Nombre:</p></td>
            <td><p class="desc">{{ $transport->passenger_fullname }}</p></td>
        </tr>


        <tr>
            <td><p class="desc">N° Asiento:</p></td>
            <td><p class="desc">{{ $transport->seat_number }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">M. Pasajero:</p></td>
            <td><p class="desc">{{ $transport->passenger_manifest }}</p></td>
        </tr>

        <tr>
            <td><p class="desc">F. Inicio:</p></td>
            <td><p class="desc">{{ $transport->start_date }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">H. Inicio:</p></td>
            <td><p class="desc">{{ $transport->start_time }}</p></td>
        </tr>


        <tr>
            <td><p class="desc">U. Origen:</p></td>
            <td><p class="desc">{{ $origin_district }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">D. Origen:</p></td>
            <td><p class="desc">{{ $transport->origin_address }}</p></td>
        </tr>

        <tr>
            <td><p class="desc">U. Destino:</p></td>
            <td><p class="desc">{{ $destinatation_district }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">D. Destino:</p></td>
            <td><p class="desc">{{ $transport->destinatation_address }}</p></td>
        </tr>

    </table>
@endif


@if ($document->dispatch)
    <br/>
    <strong>Órdenes de entrega</strong>
    <table>
        <tr>
            <td>{{ $document->dispatch->number_full }}</td>
        </tr>
    </table>

@elseif (count($document->reference_guides) > 0)
    <br/>
    <strong>Órdenes de entrega</strong>
    <table>
        @foreach($document->reference_guides as $guide)
            <tr>
                <td>{{ $guide->series }}</td>
                <td>-</td>
                <td>{{ $guide->number }}</td>
            </tr>
        @endforeach
    </table>
@endif

@if(!is_null($document_base))
    <table>
        <tr>
            <td class="desc">Documento Afectado:</td>
            <td class="desc">{{ $affected_document_number }}</td>
        </tr>
        <tr>
            <td class="desc">Tipo de nota:</td>
            <td class="desc">{{ ($document_base->note_type === 'credit')?$document_base->note_credit_type->description:$document_base->note_debit_type->description}}</td>
        </tr>
        <tr>
            <td class="align-top desc">Descripción:</td>
            <td class="text-left desc">{{ $document_base->note_description }}</td>
        </tr>
    </table>
@endif

<table class="full-width mt-10 mb-10">
    <thead class="">
    <tr>
        <th colspan="2" class="border-top-bottom desc-9 text-left">DESCRIPCIÓN</th>
        <th class="border-top-bottom desc-9 text-right">IMPORTE</th>
    </tr>
    </thead>
    <tbody>
    @php
        $data_json_items = collect($document->data_json->items ?? []);
        $fusionados = $data_json_items->filter(function($item) {return !empty($item->esFusionado);});
        $hay_fusionados = $fusionados->isNotEmpty();
        $cantidad_fusionada = \App\Support\Exact\Decimal::sum($fusionados->map(fn ($item) => \App\Support\Exact\Decimal::read($item, 'cantidad')));

        $total_fusionado = \App\Support\Exact\Decimal::sum($fusionados->map(fn ($item) => \App\Support\Exact\Decimal::read($item, 'total_item')));
    @endphp
    @if($hay_fusionados)
        <tr>
            <td colspan="3" class="text-left desc-9 align-top pt-2">
                <span style="font-size: 7px;">001</span> Por consumo
            </td>
        </tr>
        <tr>
            <td colspan="2" class="text-left desc-9 pb-2">
                {{ \App\Support\Exact\Decimal::represent($cantidad_fusionada) }} UND x {{ \App\Support\Exact\PdfPrice::configured($cantidad_fusionada->isZero() ? 0 : $total_fusionado->dividedBy($cantidad_fusionada)) }}
            </td>
            <td class="text-right desc-9 font-bold pb-2">{{ \App\Support\Exact\Decimal::format($total_fusionado) }}</td>
        </tr>
        <tr><td colspan="3" class="border-bottom"></td></tr>
    @else
        @foreach($document->items as $row)
            @php
                $item_code = $row->item->internal_id;
                $item_quantity = ((int)$row->quantity != $row->quantity) ? $row->quantity : number_format($row->quantity, 0);
                $use_name_product_pdf = !empty($row->name_product_pdf);
                $item_description_html = null;

                if ($use_name_product_pdf) {
                    $item_description_html = \App\CoreFacturalo\Helpers\Template\TemplateHelper::formatNameProductPdfForTicket($row->name_product_pdf);
                    if (!empty($row->item->presentation)) {
                        $item_description_html .= '<br/>'.$row->item->presentation->description;
                    }
                    $item_description = strip_tags($item_description_html);
                } else {
                    $item_description = $row->item->description;
                    if (!empty($row->item->presentation)) {
                        $item_description .= ' '.$row->item->presentation->description;
                    }
                    $item_description = trim(preg_replace('/\s+/', ' ', html_entity_decode(strip_tags((string) $item_description))));
                }

                $show_item_code = $item_code !== '' && $item_code !== null
                    && mb_strpos(strip_tags((string) $item_description), (string) $item_code) === false;

                if (!$use_name_product_pdf) {
                    $available_chars = $max_chars_description;
                    if ($show_item_code) {
                        $available_chars -= (int) ceil(mb_strlen((string) $item_code) * 7 / 9) + 1;
                    }
                    if (mb_strlen($item_description) > $available_chars) {
                        $item_description = rtrim(mb_substr($item_description, 0, max($available_chars - 1, 1))).'.';
                    }
                }
            @endphp
            <tr>
                <td colspan="3" class="text-left desc-9 align-top pt-2">
                    @if($show_item_code)<span style="font-size: 7px;">{{ $item_code }}</span> @endif
                    @if($use_name_product_pdf)
                        {!! $item_description_html !!}
                    @else
                        {{ $item_description }}
                    @endif

                    {{-- ########## INICIO SIN DETRACCIONES E ISC --}}




                    @foreach($row->additional_information as $information)
                        @if ($information)
                            <br/>{{ $information }}
                        @endif
                    @endforeach

                    @if($row->attributes)
                        @foreach($row->attributes as $attr)
                            {{-- Excluir atributos de placa (diferentes variaciones de texto) --}}
                            @if(!in_array(strtoupper(trim($attr->description)), [
                                'PLACA',
                                'NRO PLACA',
                                'NUMERO DE PLACA',
                                'NÚMERO DE PLACA',
                                'N° PLACA',
                                'NUMERO PLACA',
                                'NRO DE PLACA'
                            ]))
                                <br/>{!! $attr->description !!} : {{ $attr->value }}
                            @endif
                        @endforeach
                    @endif
                    @if($row->discounts)
                        @foreach($row->discounts as $dtos)
                            @if(!($dtos->from_global_distribution ?? false))
                                <br/><small>{{ ($dtos->is_amount ?? false) ? '' : ($dtos->factor * 100).'%' }} {{$dtos->description ?? 'Descuento' }}</small>
                            @endif
                        @endforeach
                    @endif

                    @if($row->charges)
                        @foreach($row->charges as $charge)
                            <br/><small>{{ $document->currency_type->symbol}} {{ $charge->amount}}
                                ({{ $charge->factor * 100 }}%) {{$charge->description ?? 'Cargo' }}</small>
                        @endforeach
                    @endif

                    @if($row->item->is_set == 1)

                        <br>
                        @inject('itemSet', 'App\Services\ItemSetService')
                        @foreach ($itemSet->getItemsSet($row->item_id) as $item)
                            {{$item}}<br>
                        @endforeach
                        {{-- {{join( "-", $itemSet->getItemsSet($row->item_id) )}} --}}
                    @endif

                    @if($row->item->used_points_for_exchange ?? false)
                        <br>
                        <small>*** Canjeado por {{$row->item->used_points_for_exchange}} puntos ***</small>
                    @endif

                    @if($document->has_prepayment)
                        <br>
                        *** Pago Anticipado ***
                    @endif
                    @inject('itemLotGroup', 'App\Services\ItemLotsGroupService')
                    @php
                        $lot = optional($row->item)->IdLoteSelected ? $itemLotGroup->getLote($row->item->IdLoteSelected) : '';
                        $date_due = optional($row->item)->IdLoteSelected ? $itemLotGroup->getLotDateOfDue($row->item->IdLoteSelected) : '';
                    @endphp
                    @if($lot)
                        <small style="display:block; font-weight: normal; font-size: 7px;">
                            Lote: {{ ltrim($lot, '/') }}
                            <br>
                            FV:
                            @if($date_due != '')
                                {{ ltrim($date_due, '/') }}
                            @elseif($row->relation_item->date_of_due)
                                {{ $row->relation_item->date_of_due->format('y-m-d') }}
                            @endif
                            <br>
                        </small>
                    @endif
                    <small style="display:block; font-weight: normal; font-size: 7px;">
                        @isset($row->item->lots)
                            @foreach($row->item->lots as $lot)
                                @if( isset($lot->has_sale) && $lot->has_sale)
                                    <span> Serie: {{ $lot->series }}</span><br>
                                @endif
                            @endforeach
                        @endisset
                    </small>
                </td>
            </tr>
            <tr>
                <td colspan="2" class="text-left desc-9 pb-2">
                    {{ $item_quantity }} {{ $row->item->unit_type_id }} x {{ $row->formatPdfUnitPrice() }}
                </td>
                <td class="text-right desc-9 font-bold pb-2">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($row, 'total'), 2) }}</td>
            </tr>
            @if($loop->last)
                <tr>
                    <td colspan="3" class="border-bottom"></td>
                </tr>
            @endif
        @endforeach
    @endif
    @if ($document->prepayments)
        @foreach($document->prepayments as $p)
            <tr>
                <td colspan="3" class="text-left desc-9 align-top pt-2">
                    ANTICIPO: FACTURA NRO. {{$p->number}}
                </td>
            </tr>
            <tr>
                <td colspan="2" class="text-left desc-9 pb-2">
                    1 UND x -{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($p, 'total'), 2) }}
                </td>
                <td class="text-right desc-9 font-bold pb-2">-{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($p, 'total'), 2) }}</td>
            </tr>
            <tr>
                <td colspan="3" class="border-bottom"></td>
            </tr>
        @endforeach
    @endif

    @if($document->total_exportation > 0)
        <tr>
            <td colspan="2" class="text-right font-bold desc">OP.
                EXPORTACIÓN: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exportation'), 2) }}</td>
        </tr>
    @endif


    @if($document->total_exonerated > 0)
        <tr>
            <td colspan="2" class="text-right font-bold desc">OP.
                EXONERADAS: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exonerated'), 2) }}</td>
        </tr>
    @endif

    @if ($document->document_type_id === '07')
        @if($document->total_taxed >= 0)
            <tr>
                <td colspan="2" class="text-right font-bold desc">OP.
                    GRAVADAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_taxed'), 2) }}</td>
            </tr>
        @endif
    @elseif($document->total_taxed > 0)
        <tr>
            <td colspan="2" class="text-right font-bold desc">OP. GRAVADAS: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_taxed'), 2) }}</td>
        </tr>
    @endif


    <tr>
        {{-- ########## INICIO CAMBIO IGV A IVA --}}
        <td colspan="2" class="text-right font-bold desc">IVA: {{ $document->currency_type->symbol }}</td>
        {{-- ######### FIN CAMBIO IGV A IVA --}}
        <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_igv'), 2) }}</td>
    </tr>

    {{-- ########## INICIO SIN DETRACCIONES E ISC --}}


    @if($document->subtotal > 0)
        @php
            $labelSubtotal = $discount_for_totals > 0 ? 'SUMA DE IMPORTES' : 'SUBTOTAL';
            $subtotal = $document->subtotal + $discount_for_totals - ($third_party_sale ? $document->total_charge : 0);
        @endphp
        <tr>
            <td colspan="2" class="text-right font-bold desc">{{ $labelSubtotal }}: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format($subtotal, 2) }}</td>
        </tr>
    @endif

    @if($discount_for_totals > 0)
        <tr>
            <td colspan="2" class="text-right font-bold desc">DESCUENTO
                TOTAL: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ number_format($discount_for_totals, 2) }}</td>
        </tr>
    @endif

    @if($document->total_charge > 0)
        @if($document->charges)
            @php
                $total_factor = 0;
                foreach($document->charges as $charge) {
                    $total_factor = ($total_factor + $charge->factor) * 100;
                }
            @endphp
            <tr>
                <td colspan="2" class="text-right font-bold desc">CARGOS ({{$total_factor}}
                    %): {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_charge'), 2) }}</td>
            </tr>
        @else
            <tr>
                <td colspan="2" class="text-right font-bold desc">CARGOS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_charge'), 2) }}</td>
            </tr>
        @endif
    @endif
    @if($igtf_for_totals > 0)
        <tr>
            <td colspan="2" class="text-right font-bold desc">IGTF: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ number_format($igtf_for_totals, 2) }}</td>
        </tr>
    @endif

        <tr>
            <td class="text-left font-bold desc" style="white-space: nowrap;">Productos: {{ rtrim(rtrim(number_format(collect($document->items)->sum(function ($item) { return (float) data_get($item, 'quantity', 0); }), 2, '.', ''), '0'), '.') }}</td>
            <td class="text-right font-bold desc" style="white-space: nowrap;">TOTAL A PAGAR: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total'), 2) }}</td>
        </tr>




    @if($balance < 0)
        <tr>
            <td colspan="2" class="text-right font-bold desc">VUELTO: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ number_format(abs($balance),2, ".", "") }}</td>
        </tr>
    @endif
    </tbody>
</table>
<table class="full-width">
    @foreach(array_reverse((array) $document->legends) as $row)
        <tr>
            @if ($row->code == "1000")
                <td class="desc pt-3" colspan="2">Son: <span class="font-bold">{{ $row->value }} {{ $document->currency_type->description }}</span></td>
            @else
                <td class="desc pt-3" colspan="2">{{$row->code}}: {{ $row->value }}</td>
            @endif
        </tr>
    @endforeach
    <tr>
        <td class="text-left pt-1 align-top">
            <!-- HKA_TICKET_QR -->
        </td>
        <td class="align-top">
            @foreach($document->additional_information as $information)
                @if ($information)
                    @if ($loop->first)
                        <strong>Información adicional</strong>
                    @endif
                    <p class="desc">{{ $information }}</p>
                @endif
            @endforeach

            @if(isset($configurationInPdf) && $configurationInPdf->show_bank_accounts_in_pdf)
                @if(((string) $document->document_type->id === '01'))
                    @foreach($accounts as $account)
                        <p class="desc">
                            <small>
                                <span class="font-bold desc">{{$account->bank->description}}</span> {{$account->currency_type->description}}
                                <span class="font-bold desc">N°:</span> {{$account->number}}
                                @if($account->cci)
                                <span class="font-bold desc">CCI:</span> {{$account->cci}}
                                @endif
                            </small>
                        </p>
                    @endforeach
                @endif
            @endif


            @php
                $paymentCondition = \App\CoreFacturalo\Helpers\Template\TemplateHelper::getDocumentPaymentCondition($document);
            @endphp
            {{-- Condicion de pago  Crédito / Contado --}}
            <p class="desc pt-5">
                <strong>CONDICIÓN DE PAGO: {{ $paymentCondition }} </strong>
            </p>

            @if($document->payment_method_type_id)
                <p class="desc pt-5">
                    <strong>MÉTODO DE PAGO: </strong>{{ $document->payment_method_type->description }}
                </p>
            @endif

            @if ($document->payment_condition_id === '01')

                @if($payments->count())
                        <p class="desc pt-5">
                            <strong>PAGOS:</strong>
                        </p>
                    @foreach($payments as $row)
                        <p>
                            <span class="desc">&#8226; {{ $row->payment_method_type->description }} - {{ $row->reference ? $row->reference.' - ':'' }} {{ $document->currency_type->symbol }} {{ $row->payment + $row->change }}</span>
                        </p>
                    @endforeach
                @endif
            @else
                @foreach($document->fee as $key => $quote)
                    <p class="desc pt-5">
                        <span class="desc">&#8226; {{ (empty($quote->getStringPaymentMethodType()) ? 'Cuota #'.( $key + 1) : $quote->getStringPaymentMethodType()) }} / Fecha: {{ $quote->date->format('d-m-Y') }} / Monto: {{ $quote->currency_type->symbol }}{{ $quote->amount }}</span>
                    </p>
                @endforeach
            @endif
            @if(isset($configurationInPdf) && $configurationInPdf->show_seller_in_pdf)
            <tr>
                <td class="desc">
                    <strong>Vendedor:</strong>
                </td>
            </tr>
            <tr>
                @if ($document->seller)
                    <td class="desc">{{ $document->seller->name }}</td>
                @else
                    <td class="desc">{{ $document->user->name }}</td>
                @endif
            </tr>
            @endif

        </td>
    </tr>
</table>
<table class="full-width">
@if ($document->terms_condition)
        <tr>
            <td class="desc">
                <br>
                <h6 style="font-size: 9px; font-weight: bold;">Términos y condiciones del servicio</h6>
                <div style="font-size: 9px;">
                    {!! $document->terms_condition !!}
                </div>
            </td>
        </tr>
    @endif
    </tr>
</table>
{!! view()->file(app_path('CoreFacturalo/Templates/pdf/default/partials/footer.blade.php'), ['document' => $document])->render() !!}
</body>
</html>
{{-- ######## FIN MIGRACIÓN MONEDA VENEZUELA ######## --}}

{{-- ######## FIN PERSISTENCIA FISCAL VENEZUELA ######## --}}
