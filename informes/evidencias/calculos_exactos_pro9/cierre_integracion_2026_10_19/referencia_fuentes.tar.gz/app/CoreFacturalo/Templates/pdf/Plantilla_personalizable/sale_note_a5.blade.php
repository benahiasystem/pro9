@php
    use Modules\Template\Helpers\TemplatePdf;

    $establishment = $document->establishment;
    $customer = $document->customer;
    //$path_style = app_path('CoreFacturalo'.DIRECTORY_SEPARATOR.'Templates'.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.'style.css');
    $left = $document->series;
    $tittle = \App\Services\Fiscal\FiscalIdentity::numberFull($left, $document->number);
    $payments = $document->payments;
    // $accounts = \App\Models\Tenant\BankAccount::all();
    $accounts = (new TemplatePdf)->getBankAccountsForPdf($document->establishment_id);
    $configurationInPdf= App\CoreFacturalo\Helpers\Template\TemplateHelper::getConfigurationInPdf();
    
    $logo = "storage/uploads/logos/{$company->logo}";
    if($establishment->logo) {
        $logo = "{$establishment->logo}";
    }

    // Obtener configuración de columnas para Plantilla_personalizable
    $columnsConfig = \App\Models\Tenant\TemplateColumnsConfig::where('establishment_id', $document->establishment_id)
        ->where('template_name', 'Plantilla_personalizable')
        ->first();

    $showColumns = $columnsConfig ? $columnsConfig->columns_config : [
        'codigo' => true,
        'cantidad' => true,
        'unidad' => true,
        'descripcion' => true,
        'serie' => false,
        'modelo' => false,
        'marca' => false,
        'lote' => false,
        'fecha_vencimiento' => false,
        'precio_unitario' => true,
        'descuento' => true,
        'total' => true,
        'nro_producto' => false,
    ];

@endphp
<html>
<head>
    {{--<title>{{ $tittle }}</title>--}}
    {{--<link href="{{ $path_style }}" rel="stylesheet" />--}}
</head>
<body>
<table class="full-width">
    <tr>
        @if($company->logo)
            <td width="20%">
                <div class="company_logo_box">
                    <img
                        src="data:{{mime_content_type(public_path("{$logo}"))}};base64, {{base64_encode(file_get_contents(public_path("{$logo}")))}}"
                        alt="{{ \App\CoreFacturalo\Helpers\CompanyDocumentDisplay::logoAlt($company) }}" class="company_logo" style="max-width: 150px;">
                </div>
            </td>
            <td width="50%" class="text-center">
                <div class="text-left">
                    @include('pdf.partials.company_document_header_names')
                    <h5>{{ 'RIF '.$company->number }}</h5>
                    <h6 style="text-transform: uppercase;">
                        {{ ($establishment->address !== '-')? $establishment->address : '' }}
                        {{ ($establishment->district_id !== '-')? ', '.$establishment->district->description : '' }}
                        {{ ($establishment->province_id !== '-')? ', '.$establishment->province->description : '' }}
                        {{ ($establishment->department_id !== '-')? '- '.$establishment->department->description : '' }}
                    </h6>
                    <h6>{{ ($establishment->email !== '-')? $establishment->email : '' }}</h6>
                    <h6>{{ ($establishment->telephone !== '-')? $establishment->telephone : '' }}</h6>
                </div>
            </td>
            <td width="30%" class="border-box py-4 px-2 text-center">
                <h5 class="text-center">NOTA DE VENTA</h5>
                <h3 class="text-center">{{ $tittle }}</h3>
            </td>
        @else
            <td width="50%" class="pl-1">
                <div class="text-left">
                    @include('pdf.partials.company_document_header_names')
                    <h5>{{ 'RIF '.$company->number }}</h5>
                    <h6 style="text-transform: uppercase;">
                        {{ ($establishment->address !== '-')? $establishment->address : '' }}
                        {{ ($establishment->district_id !== '-')? ', '.$establishment->district->description : '' }}
                        {{ ($establishment->province_id !== '-')? ', '.$establishment->province->description : '' }}
                        {{ ($establishment->department_id !== '-')? '- '.$establishment->department->description : '' }}
                    </h6>
                    <h6>{{ ($establishment->email !== '-')? $establishment->email : '' }}</h6>
                    <h6>{{ ($establishment->telephone !== '-')? $establishment->telephone : '' }}</h6>
                </div>
            </td>
            <td width="30%" class="border-box py-4 px-2 text-center">
                <h5 class="text-center">NOTA DE VENTA</h5>
                <h3 class="text-center">{{ $tittle }}</h3>
            </td>
        @endif        
    </tr>
</table>
<table class="full-width mt-5">
    <tr>
        <td width="15%">Cliente:</td>
        <td width="45%">{{ $customer->name }}</td>
        <td width="25%">Fecha de emisión:</td>
        <td width="15%">{{ $document->date_of_issue->format('Y-m-d') }}</td>
    </tr>
    <tr>
        <td>{{ $customer->identity_document_type->description }}:</td>
        <td>{{ format_identity_document($customer->identity_document_type_id ?? null, $customer->number) }}</td>
        
        @if ($document->due_date)
            <td class="align-top">Fecha Vencimiento:</td>
            <td>{{ $document->getFormatDueDate() }}</td>
        @endif

    </tr>
    @php
        $addressParts = [];

        if (!empty($customer->address)) {
            $addressParts[] = $customer->address;
        }

        if (!empty($customer->district_id) && $customer->district_id !== '-' && isset($customer->district) && !empty($customer->district->description)) {
            $addressParts[] = $customer->district->description;
        }

        if (!empty($customer->province_id) && $customer->province_id !== '-' && isset($customer->province) && !empty($customer->province->description)) {
            $addressParts[] = $customer->province->description;
        }

        if (!empty($customer->department_id) && $customer->department_id !== '-' && isset($customer->department) && !empty($customer->department->description)) {
            $addressParts[] = $customer->department->description;
        }

        $fullAddress = implode(', ', $addressParts);
    @endphp

    <tr>
        <td class="align-top">Dirección:</td>
        <td>
            {{ $fullAddress ?: 'No disponible' }}
        </td>
    </tr>
    <tr>
        <td>Teléfono:</td>
        <td>{{ $customer->telephone }}</td>
        @if(isset($configurationInPdf) && $configurationInPdf->show_seller_in_pdf)
            <td>Vendedor:</td>
            <td>@if($document->seller_id != 0){{$document->seller->name }} @else {{ $document->user->name }}@endif</td>
        @endif
    </tr>
    @if ($document->plate_number !== null)
    <tr>
        <td >N° Placa:</td>
        <td >{{ $document->plate_number }}</td>
    </tr>
    @endif
    @if ($document->total_canceled)
    <tr>
        <td class="align-top">Estado:</td>
        <td colspan="3">CANCELADO</td>
    </tr>
    @else
    <tr>
        <td class="align-top">Estado:</td>
        <td colspan="3">PENDIENTE DE PAGO</td>
    </tr>
    @endif
    @if ($document->observation)
    <tr>
        <td class="align-top">Observación:</td>
        <td colspan="3">{{ $document->observation }}</td>
    </tr>
    @endif
    @if ($document->reference_data)
        <tr>
            <td class="align-top">D. Referencia:</td>
            <td colspan="3">{{ $document->reference_data }}</td>
        </tr>
    @endif
    @if ($document->purchase_order)
        <tr>
            <td class="align-top">Orden de compra:</td>
            <td colspan="3">{{ $document->purchase_order }}</td>
        </tr>
    @endif
</table>

@if ($document->guides)
<br/>
{{--<strong>Órdenes de entrega:</strong>--}}
<table>
    @foreach($document->guides as $guide)
        <tr>
            @if(isset($guide->document_type_description))
            <td>{{ $guide->document_type_description }}</td>
            @else
            <td>{{ $guide->document_type_id }}</td>
            @endif
            <td>:</td>
            <td>{{ $guide->number }}</td>
        </tr>
    @endforeach
</table>
@endif

@php
$showModelColumn = false;
$showBrandColumn = false;

foreach ($document->items as $row) {
    if (!empty($row->item->model)) {
        $showModelColumn = true;
    }
    if (!empty($row->relation_item->brand->name ?? null)) {
        $showBrandColumn = true;
    }

    if ($showModelColumn && $showBrandColumn) break;
}
@endphp

<table class="full-width mt-10 mb-10">
    <thead class="">
    <tr class="bg-grey">
        @if($showColumns['cantidad']) <th class="border-top-bottom text-center py-2" width="8%">CANT.</th> @endif
        @if($showColumns['unidad']) <th class="border-top-bottom text-center py-2" width="8%">UNIDAD</th> @endif
        @if($showColumns['descripcion']) <th class="border-top-bottom text-left py-2">DESCRIPCIÓN</th> @endif
        @if($showColumns['modelo'] && $showModelColumn)
            <th class="border-top-bottom text-left py-2 px-1">MODELO</th>
        @endif
        @if($showColumns['marca'] && $showBrandColumn)
            <th class="border-top-bottom text-center py-2 px-1">MARCA</th>
        @endif  
        @php
            $showSerieColumn = false;
            $showLoteColumn = false;

            foreach ($document->items as $row) {
                if (isset($row->item->lots) && $row->item->lots) {
                    $showSerieColumn = true;
                    break;
                }
            }

            foreach ($document->items as $row) {
                if (isset($row->item->IdLoteSelected)) {
                    $showLoteColumn = true;
                    break;
                }
            }
        @endphp
        @if($showColumns['serie'] && $showSerieColumn) <th class="border-top-bottom text-left py-2"> SERIE </th> @endif
        @if($showColumns['lote'] && $showLoteColumn) <th class="border-top-bottom text-center py-2" width="8%">
             LOTE 
        </th> @endif
        @if($showColumns['fecha_vencimiento'] && $showLoteColumn) <th class="border-top-bottom text-center py-2" width="8%"> F. VENC. </th> @endif
        @if($showColumns['precio_unitario'])<th class="border-top-bottom text-right py-2 col-total">P.UNIT</th>
        @endif
        @if($showColumns['descuento'])<th class="border-top-bottom text-right py-2" width="8%">DTO.</th>
        @endif
        @if($showColumns['total'])<th class="border-top-bottom text-right py-2 col-total">TOTAL</th>
        @endif
    </tr>
    </thead>
    <tbody>
        @php
            $colspan_total = 0;
                
            if($showColumns['cantidad']) $colspan_total++;
            if($showColumns['unidad']) $colspan_total++;
            if($showColumns['descripcion']) $colspan_total++;
            if($showColumns['serie'] && $showSerieColumn) $colspan_total++;
            if($showColumns['modelo'] && $showModelColumn) $colspan_total++;
            if($showColumns['marca'] && $showBrandColumn) $colspan_total++;
            if($showColumns['lote'] && $showLoteColumn) $colspan_total++;
            if($showColumns['fecha_vencimiento'] && $showLoteColumn) $colspan_total++;
            if($showColumns['precio_unitario']) $colspan_total++;
            if($showColumns['descuento']) $colspan_total++;
            if($showColumns['total']) $colspan_total++;
        @endphp

        @foreach($document->items as $row)
        <tr>
            @if($showColumns['cantidad'])<td class="text-center align-top">
                @if(((int)$row->quantity != $row->quantity))
                    {{ $row->quantity }}
                @else
                    {{ number_format($row->quantity, 0) }}
                @endif
            </td> @endif
            @if($showColumns['unidad'])<td class="text-center align-top">{{ $row->item->unit_type_id }}</td> @endif
            @if($showColumns['descripcion'])<td class="text-left">

                @if($row->name_product_pdf)
                    {!!$row->name_product_pdf!!}
                @else
                    {!!$row->item->description!!}
                @endif
                    @if (!empty($row->item->presentation)) {!!$row->item->presentation->description!!} @endif
                @if($row->attributes)
                    @foreach($row->attributes as $attr)
                        <br/><span style="font-size: 9px">{!! $attr->description !!} : {{ $attr->value }}</span>
                    @endforeach
                @endif
                @if($row->discounts)
                    @foreach($row->discounts as $dtos)
                        @if(!($dtos->from_global_distribution ?? false))
                            <br/><span style="font-size: 9px">{{ ($dtos->is_amount ?? false) ? '' : ($dtos->factor * 100).'%' }} {{$dtos->description }}</span>
                        @endif
                    @endforeach
                @endif
                @if($row->item->is_set == 1)

                 <br>
                 @inject('itemSet', 'App\Services\ItemSetService')
                 @foreach ($itemSet->getItemsSet($row->item_id) as $item)
                     {{$item}}<br>
                 @endforeach
                @endif
            </td> @endif
            @if($showColumns['serie'] && $showSerieColumn) <td class="text-left align-top">
                @isset($row->item->lots)
                    @foreach($row->item->lots as $lot)
                        @if( isset($lot->has_sale) && $lot->has_sale)
                            <span style="font-size: 9px">{{ $lot->series }}</span><br>
                        @endif
                    @endforeach
                @endisset
            </td> @endif
            @if($showColumns['modelo'] && $showModelColumn)
                <td class="text-left align-top">{{ $row->item->model ?? '' }}</td>
            @endif
            @if($showColumns['marca'] && $showBrandColumn)
                <td class="text-left align-top">{{ $row->relation_item->brand->name ?? '' }}</td>
            @endif
            @inject('itemLotGroup', 'App\Services\ItemLotsGroupService')
            @php
                $lot = optional($row->item)->IdLoteSelected ? $itemLotGroup->getLote($row->item->IdLoteSelected) : '';
                $date_due = optional($row->item)->IdLoteSelected ? $itemLotGroup->getLotDateOfDue($row->item->IdLoteSelected) : '';
            @endphp

            @if($showColumns['lote'] && $showLoteColumn)
                <td class="text-center align-top">
                    @if($lot)
                        @foreach(explode('/', $lot) as $code)
                            @if(trim($code) !== '')
                                {{ trim($code) }}<br>
                            @endif
                        @endforeach
                    @endif
                </td>
            @endif
            @if($showColumns['fecha_vencimiento'] && $showLoteColumn)
                <td class="text-center align-top">
                    @php
                        $cleanedDate = $date_due != ''
                            ? ltrim($date_due, '/')
                            : ($row->relation_item->date_of_due ? $row->relation_item->date_of_due->format('Y-m-d') : '');
                    @endphp
            
                    {{ $cleanedDate }}
                </td>
            @endif
            @if($showColumns['precio_unitario']) <td class="text-right align-top">{{ $row->formatPdfUnitPrice() }}</td> @endif
            @if($showColumns['descuento']) <td class="text-right align-top">
                @if($row->discounts)
                    @php $total_discount_line = \App\Support\Exact\PdfAmounts::lineDiscount($row, false); @endphp
                    {{ \App\Support\Exact\Decimal::format($total_discount_line, 2) }}
                @else
                0.00
                @endif
            </td> @endif
            @if($showColumns['total'])<td class="text-right align-top">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($row, 'total'), 2) }}</td> @endif
        </tr>
        <tr>
            <td colspan="{{ $colspan_total }}" class="border-bottom"></td>
        </tr>
    @endforeach
        @if($document->total_exportation > 0)
            <tr>
                <td colspan="{{ $colspan_total - 1 }}" class="text-right font-bold">OP. EXPORTACIÓN: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exportation'), 2) }}</td>
            </tr>
        @endif
        @if($document->total_free > 0)
            <tr>
                <td colspan="{{ $colspan_total - 1 }}" class="text-right font-bold">OP. GRATUITAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_free'), 2) }}</td>
            </tr>
        @endif
        @if($document->total_unaffected > 0)
            <tr>
                <td colspan="{{ $colspan_total - 1 }}" class="text-right font-bold">OP. INAFECTAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_unaffected'), 2) }}</td>
            </tr>
        @endif
        @if($document->total_exonerated > 0)
            <tr>
                <td colspan="{{ $colspan_total - 1 }}" class="text-right font-bold">OP. EXONERADAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exonerated'), 2) }}</td>
            </tr>
        @endif
        {{-- @if($document->total_taxed > 0)
            <tr>
                <td colspan="5" class="text-right font-bold">OP. GRAVADAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_taxed'), 2) }}</td>
            </tr>
        @endif --}}
      @if($document->total_discount_with_igv > 0)
            <tr>
                <td colspan="{{ $colspan_total - 1 }}" class="text-right font-bold">{{(($document->total_prepayment > 0) ? 'ANTICIPO':'DESCUENTO TOTAL')}}: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_discount_with_igv'), 2) }}</td>
            </tr>
        @endif
        {{--<tr>
            {{-- ########## INICIO CAMBIO IGV A IVA --}}
            <td colspan="5" class="text-right font-bold">IVA: {{ $document->currency_type->symbol }}</td>
            {{-- ######### FIN CAMBIO IGV A IVA --}}
            <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_igv'), 2) }}</td>
        </tr>--}}
        
        @if($document->total_charge > 0 && $document->charges)
            <tr>
                <td colspan="{{ $colspan_total - 1 }}" class="text-right font-bold">CARGOS ({{$document->getTotalFactor()}}%): {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_charge'), 2) }}</td>
            </tr>
        @endif

        {{-- <tr>
            <td colspan="{{ $colspan_total - 1 }}" class="text-left font-bold" style="white-space: nowrap;">Productos: {{ rtrim(rtrim(number_format(collect($document->items)->sum(function ($item) { return (float) data_get($item, 'quantity', 0); }), 2, '.', ''), '0'), '.') }}</td>
            <td class="text-right font-bold"></td>
        </tr> --}}
        <tr>
            <td colspan="{{ $colspan_total - 1 }}" class="text-right font-bold">TOTAL A PAGAR: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total'), 2) }}</td>
        </tr>
        
        @php
            $change_payment = $document->getChangePayment();
        @endphp

        @if($change_payment < 0)
            <tr>
                <td colspan="{{ $colspan_total - 1 }}" class="text-right font-bold">VUELTO: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ number_format(abs($change_payment),2, ".", "") }}</td>
            </tr>
        @endif

    </tbody>
</table>
@if ($showColumns['nro_producto'] ?? false)
<table>
    <tr width="65%">
        <td class="text-left py-1"><strong>N° DE PRODUCTOS</strong>: {{ $document->items->count() }}</td>
    </tr>
</table>
@endif
@if(isset($configurationInPdf) && $configurationInPdf->show_bank_accounts_in_pdf)
<br>
    <table class="full-width">
        <tr>
            <td width="65%" style="text-align: top; vertical-align: top;">
                <br>
                @foreach($accounts as $account)
                    <p>
                    <span class="font-bold">{{$account->bank->description}}</span> {{$account->currency_type->description}}
                    <span class="font-bold">N°:</span> {{$account->number}}
                    @if($account->cci)
                    - <span class="font-bold">CCI:</span> {{$account->cci}}
                    @endif
                    </p>
                @endforeach
            </td>
        </tr>
    </table>
@endif
<br>
@if($document->payment_method_type_id && $payments->count() == 0)
    <table class="full-width">
        <tr>
            <td>
                <strong>PAGO: </strong>{{ $document->payment_method_type->description }}
            </td>
        </tr>
    </table>
@endif

@if($payments->count())
<table class="full-width">
<tr>
    <td>
    <strong>PAGOS:</strong> </td></tr>
        @php
            $payment = 0;
        @endphp
        @foreach($payments as $row)
            <tr><td>- {{ $row->date_of_payment->format('d/m/Y') }} - {{ $row->payment_method_type->description }} - {{ $row->reference ? $row->reference.' - ':'' }} {{ $document->currency_type->symbol }} {{ $row->payment + $row->change }}</td></tr>
            @php
                $payment += (float) $row->payment;
            @endphp
        @endforeach
        <tr><td><strong>SALDO:</strong> {{ $document->currency_type->symbol }} {{ number_format($document->total - $payment, 2) }}</td>
    </tr>

</table>
@endif
@if ($document->terms_condition)
    <br>
    <table class="full-width">
        <tr>
            <td>
                <h6 style="font-size: 12px; font-weight: bold;">Términos y condiciones del servicio</h6>
                {!! $document->terms_condition !!}
            </td>
        </tr>
    </table>
@endif
</body>
</html>
