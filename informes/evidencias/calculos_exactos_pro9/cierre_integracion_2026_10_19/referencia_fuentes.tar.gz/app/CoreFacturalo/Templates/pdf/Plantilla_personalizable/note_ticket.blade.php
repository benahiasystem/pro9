{{-- ######## INICIO PERSISTENCIA FISCAL VENEZUELA ######## --}}
{{-- ######## INICIO MIGRACIÓN MONEDA VENEZUELA ######## --}}
@php
    $establishment = $document->establishment;
    $customer = $document->customer;

    $document_base = $document->note;
    /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$document_number = $document->number_full;
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */
    $currency_type_description_array = [
        'VES' => 'S/D',
        '0' => 'S/D',
        '1' => 'DNI',
        '6' => 'RIF',
    ];

    /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$affected_document_number = $document_base->affected_document ? $document_base->affected_document->number_full : \App\Services\Fiscal\FiscalIdentity::numberFull($document_base->data_affected_document->series ?? '', $document_base->data_affected_document->number);
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */

    //$path_style = app_path('CoreFacturalo'.DIRECTORY_SEPARATOR.'Templates'.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.'style.css');
    // $optional = $document->optional;
    $accounts = \App\Models\Tenant\BankAccount::all();

    extract(\App\CoreFacturalo\Helpers\Template\TemplateHelper::getPersonalizableTicketShowColumns(
        $document->establishment_id,
        ['codigo', 'cantidad', 'unidad', 'descripcion', 'precio_unitario', 'total']
    ));

    $person_type = $document->person?->person_type;
@endphp
<html>
<head>
    {{--<title>{{ $document_number }}111111111</title>--}}
    {{--<link href="{{ $path_style }}" rel="stylesheet" />--}}
</head>
<body>
@if($document->state_type->id == '11')
<div class="company_logo_box" style="position: absolute; text-align: center; top:30%;">
    <img
        src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png")))}}"
        alt="anulado" class="" style="opacity: 0.6;">
</div>
@endif
@if($document->state_type->id == '09')
<div class="company_logo_box" style="position: absolute; text-align: center; top:30%;">
    <img
        src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png")))}}"
        alt="rechazado" class="" style="opacity: 0.6;">
</div>
@endif

@if($company->logo)
    <div class="text-center company_logo_box pt-5">
        <img src="data:{{mime_content_type(public_path("storage/uploads/logos/{$company->logo}"))}};base64, {{base64_encode(file_get_contents(public_path("storage/uploads/logos/{$company->logo}")))}}" alt="{{ \App\CoreFacturalo\Helpers\CompanyDocumentDisplay::logoAlt($company) }}" class="company_logo_ticket contain">
    </div>
@else
    <div class="text-center company_logo_box pt-5">
        <img src="{{ asset('logo/logo.jpg') }}" class="company_logo_ticket contain">
    </div>
@endif
<table class="full-width">
    <tr>
        <td class="text-center">@include('pdf.partials.company_document_header_names', ['tagPrimary' => 'h3', 'tagLegal' => 'h4'])</td>
    </tr>
    <tr>
        <td class="text-center"><h4>{{ 'RIF '.$company->number }}</h4></td>
    </tr>
    <tr>
        <td class="text-center" style="text-transform: uppercase;">
            {{ ($establishment->address !== '-')? $establishment->address : '' }}
            {{ ($establishment->district_id !== '-')? ', '.$establishment->district->description : '' }}
            {{ ($establishment->province_id !== '-')? ', '.$establishment->province->description : '' }}
            {{ ($establishment->department_id !== '-')? '- '.$establishment->department->description : '' }}
        </td>
    </tr>
    <tr>
        <td class="text-center">{{ ($establishment->email !== '-')? $establishment->email : '' }}</td>
    </tr>
    <tr>
        <td class="text-center pb-3">{{ ($establishment->telephone !== '-')? $establishment->telephone : '' }}</td>
    </tr>
    <tr>
        <td class="text-center pt-3 border-top"><h4>{{ $document->document_type->description }}</h4></td>
    </tr>
    <tr>
        <td class="text-center pb-3 border-bottom"><h3>{{ $document_number }}</h3></td>
    </tr>
</table>
<table class="full-width">
    <tr>
        <td width="45%" class="pt-3"><p class="desc">Fecha de emisión:</p></td>
        <td width="" class="pt-3"><p class="desc">{{ $document->date_of_issue->format('Y-m-d') }} / {{ $document->time_of_issue }}</p></td>
    </tr>
    @isset($document->date_of_due)
    <tr>
        <td><p class="desc">Fecha de vencimiento:</p></td>
        <td><p class="desc">{{ $document->date_of_due->format('Y-m-d') }}</p></td>
    </tr>
    @endisset

    <tr>
        <td><p class="desc">Cliente:</p></td>
        <td><p class="desc">{{ $customer->name }}</p></td>
    </tr>
    <tr>
        <td><p class="desc">{{ $customer->identity_document_type->description }}:</p></td>
        <td><p class="desc">{{ format_identity_document($customer->identity_document_type_id ?? null, $customer->number) }}</p></td>
    </tr>
    @if ($customer->address !== '')
        <tr>
            <td class="align-top"><p class="desc">Dirección:</p></td>
            <td>
                <p class="desc">
                    {{ $customer->address }}
                    {{ ($customer->district_id !== '-')? ', '.$customer->district->description : '' }}
                    {{ ($customer->province_id !== '-')? ', '.$customer->province->description : '' }}
                    {{ ($customer->department_id !== '-')? '- '.$customer->department->description : '' }}
                </p>
            </td>
        </tr>
    @endif
    @if ($document->purchase_order)
        <tr>
            <td><p class="desc">Orden de Compra:</p></td>
            <td><p class="desc">{{ $document->purchase_order }}</p></td>
        </tr>
    @endif
    @if ($document->guides)
        @foreach($document->guides as $guide)
            <tr>
                <td><p class="desc">{{ $guide->document_type_id }}</p></td>
                <td><p class="desc">{{ $guide->number }}</p></td>
            </tr>
        @endforeach
    @endif
    <tr>
        <td class="desc">Documento Afectado:</td>
        <td class="desc">{{ $affected_document_number }}</td>
    </tr>
    <tr>
        <td class="desc">Tipo de nota:</td>
        <td class="desc">{{ ($document_base->note_type === 'credit')?$document_base->note_credit_type->description:$document_base->note_debit_type->description}}</td>
    </tr>
    <tr>
        <td class="align-top desc">Descripción:</td>
        <td class="text-left desc">{{ $document_base->note_description }}</td>
    </tr>
    {{-- @if ($optional->salesman)
        <tr>
            <td class="desc">Vendedor:</td>
            <td class="desc">{{ $optional->salesman  }}</td>
        </tr>
    @endif
    @if ($optional->box_number)
        <tr>
            <td class="desc">N° Caja:</td>
            <td class="desc">{{ $optional->box_number  }}</td>
        </tr>
    @endif
    @if ($optional->method_payment)
        <tr>
            <td class="desc">Cond. de pago:</td>
            <td class="desc">{{ $optional->method_payment  }}</td>
        </tr>
    @endif --}}
</table>
<table class="full-width mt-10 mb-10">
    <thead class="">
    <tr>
        @if($show_codigo) <th class="border-top-bottom desc-9 text-left">COD.</th> @endif
        @if($show_cantidad) <th class="border-top-bottom desc-9 text-left">CANT.</th> @endif
        @if($show_unidad) <th class="border-top-bottom desc-9 text-left">UNIDAD</th> @endif
        @if($show_descripcion) <th class="border-top-bottom desc-9 text-left">DESCRIPCIÓN</th> @endif
        @if($show_precio_unitario) <th class="border-top-bottom desc-9 text-left">P.UNIT</th> @endif
        @if($show_total) <th class="border-top-bottom desc-9 text-left">TOTAL</th> @endif
    </tr>
    </thead>
    <tbody>
    @foreach($document->items as $row)
        <tr>
            @if($show_codigo) <td class="text-center desc-9 align-top font-bold">{{ $row->item->internal_id }}</td> @endif
            @if($show_cantidad)
            <td class="text-center desc-9 align-top">
                @if(((int)$row->quantity != $row->quantity))
                    {{ $row->quantity }}
                @else
                    {{ number_format($row->quantity, 0) }}
                @endif
            </td>
            @endif
            @if($show_unidad) <td class="text-center desc-9 align-top">{{ $row->item->unit_type_id }}</td> @endif
            @if($show_descripcion)
            <td class="text-left desc-9 align-top">
                {!! $row->item->description !!}
                @if($show_marca && !empty($row->m_item->brand->name ?? null))
                    <br/><small>Marca: {{ $row->m_item->brand->name }}</small>
                @endif
                @if($show_modelo && !empty($row->item->model ?? null))
                    <br/><small>Modelo: {{ $row->item->model }}</small>
                @endif
                @if($row->attributes)
                    @foreach($row->attributes as $attr)
                        <br/>{!! $attr->description !!} : {{ $attr->value }}
                    @endforeach
                @endif
                @if($show_descuento && $row->discounts)
                    @foreach($row->discounts as $dtos)
                        @if(!($dtos->from_global_distribution ?? false))
                            <br/><small>{{ ($dtos->is_amount ?? false) ? '' : ($dtos->factor * 100).'%' }} {{$dtos->description }}</small>
                        @endif
                    @endforeach
                @endif
                @if($show_serie)
                    @isset($row->item->lots)
                        @foreach($row->item->lots as $lot)
                            @if(isset($lot->has_sale) && $lot->has_sale)
                                <br/><small>Serie: {{ $lot->series }}</small>
                            @endif
                        @endforeach
                    @endisset
                @endif
            </td>
            @endif
            @if($show_precio_unitario) <td class="text-right desc-9 align-top">{{ $row->formatPdfUnitPrice() }}</td> @endif
            @if($show_total) <td class="text-right desc-9 align-top">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($row, 'total'), 2) }}</td> @endif
        </tr>
        <tr>
            <td colspan="{{ $colspan_total }}" class="border-bottom"></td>
        </tr>
    @endforeach
        @if($document->total_exportation > 0)
            <tr>
                <td colspan="{{ $colspan_label }}" class="text-right font-bold desc">OP. EXPORTACIÓN: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exportation'), 2) }}</td>
            </tr>
        @endif


        @if($document->total_exonerated > 0)
            <tr>
                <td colspan="{{ $colspan_label }}" class="text-right font-bold desc">OP. EXONERADAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exonerated'), 2) }}</td>
            </tr>
        @endif
        @if($document->total_taxed > 0)
            <tr>
                <td colspan="{{ $colspan_label }}" class="text-right font-bold desc">OP. GRAVADAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_taxed'), 2) }}</td>
            </tr>
        @endif
        @if($document->total_discount_with_igv > 0)
            <tr>
                <td colspan="{{ $colspan_label }}" class="text-right font-bold">{{(($document->total_prepayment > 0) ? 'ANTICIPO':'DESCUENTO TOTAL')}}: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_discount_with_igv'), 2) }}</td>
            </tr>
        @endif
        <tr>
            {{-- ########## INICIO CAMBIO IGV A IVA --}}
            <td colspan="{{ $colspan_label }}" class="text-right font-bold desc">IVA: {{ $document->currency_type->symbol }}</td>
            {{-- ######### FIN CAMBIO IGV A IVA --}}
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_igv'), 2) }}</td>
        </tr>
        <tr>
            <td colspan="{{ $colspan_label }}" class="text-right font-bold desc">TOTAL A PAGAR: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total'), 2) }}</td>
        </tr>
        @if($show_nro_producto)
            <tr>
                <td colspan="{{ $colspan_total }}" class="text-left font-bold desc">N° DE PRODUCTOS: {{ $document->items->count() }}</td>
            </tr>
        @endif
        @if($show_tipo_persona && $person_type && $person_type->enabled_description_person_type)
            <tr>
                <td colspan="{{ $colspan_total }}" class="text-left desc">
                    <span class="font-bold">{{ $person_type->description }}:</span> {{ $person_type->description_person_type }}
                </td>
            </tr>
        @endif
    </tbody>
</table>
<table class="full-width">
    <tr>
        @foreach($document->legends as $row)
            <td class="desc pt-3" style="text-transform: uppercase;">Son: <span class="font-bold">{{ $row->value }} {{ $document->currency_type->description }}</span></td>
        @endforeach
    </tr>
    @foreach($accounts as $account)
        <tr>
            <td class="desc" >
                <span class="font-bold">{{$account->bank->description}}</span> {{$account->currency_type->description}}
                <span class="font-bold">N°:</span> {{$account->number}}
                @if($account->cci)
                    <span class="font-bold">CCI:</span> {{$account->cci}}
                @endif
            </td>
        </tr>
    @endforeach
    @if(isset($document->optional->observations))
        <tr>
            <td class="desc">Obsevaciones</td>
        </tr>
        <tr>
            <td class="desc">{{ $document->optional->observations }}</td>
        </tr>
    @endif
    <tr>
    </tr>
    <tr>
    </tr>
    <tr>
        <td class="text-center desc pt-5">Para consultar el comprobante ingresar a {!! url('/buscar') !!}</td>
    </tr>
</table>
</body>
</html>

{{-- ######## FIN MIGRACIÓN MONEDA VENEZUELA ######## --}}

{{-- ######## FIN PERSISTENCIA FISCAL VENEZUELA ######## --}}
