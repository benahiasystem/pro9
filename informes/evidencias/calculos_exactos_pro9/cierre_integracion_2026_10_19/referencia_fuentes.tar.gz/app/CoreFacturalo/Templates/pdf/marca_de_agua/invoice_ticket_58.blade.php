{{-- ######## INICIO PERSISTENCIA FISCAL VENEZUELA ######## --}}
{{-- ######## INICIO MIGRACIÓN MONEDA VENEZUELA ######## --}}
@php
    use Modules\Template\Helpers\TemplatePdf;

    $establishment = $document->establishment;
    $customer = $document->customer;
    $invoice = $document->invoice;
    //$path_style = app_path('CoreFacturalo'.DIRECTORY_SEPARATOR.'Templates'.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.'style.css');
    /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$document_number = $document->number_full;
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */

    // $accounts = \App\Models\Tenant\BankAccount::where('show_in_documents', true)->get();
    $accounts = (new TemplatePdf)->getBankAccountsForPdf($document->establishment_id);

    $document_base = ($document->note) ? $document->note : null;
    $payments = $document->payments;

    if($document_base) {
        /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$affected_document_number = $document_base->affected_document ? $document_base->affected_document->number_full : \App\Services\Fiscal\FiscalIdentity::numberFull($document_base->data_affected_document->series ?? '', $document_base->data_affected_document->number);
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */

    } else {
        $affected_document_number = null;
    }

    $document->load('reference_guides');
    $total_payment = $document->payments->sum('payment');
    $balance = $document instanceof \App\Models\Tenant\Document ? $document->balance : (($document->total - $total_payment) - $document->payments->sum('change'));

    $logo = "storage/uploads/logos/{$company->logo}";
    if($establishment->logo) {
        $logo = "{$establishment->logo}";
    }
    $configurationInPdf= App\CoreFacturalo\Helpers\Template\TemplateHelper::getConfigurationInPdf();

@endphp
<html>
<head></head>
<body>
    @if($document->state_type->id == '11')
    <div class="company_logo_box" style="position: absolute; text-align: center; top:30%;">
        <img
            src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png")))}}"
            alt="anulado" class="" style="opacity: 0.6;">
    </div>
    @endif
    @if($document->state_type->id == '09')
    <div class="company_logo_box" style="position: absolute; text-align: center; top:30%;">
        <img
            src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png")))}}"
            alt="rechazado" class="" style="opacity: 0.6;">
    </div>
    @endif
    @if(isset($configuration['is_preview']) && $configuration['is_preview'])
        <div style="position: absolute; width: 100%; text-align: center; top:30%; left: 0; right: 0; margin: auto;">
            <img
                src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."vista_previa.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."vista_previa.png")))}}"
                alt="vista previa" class="" style="opacity: 0.6; width: 50%;">
        </div>
    @endif

<table class="full-width" style="font-family: helvetica">
    <tr>
        <td class="pt-2">
            @if($company->logo)
                <div class="text-center company_logo_box">
                    <img
                        src="data:{{mime_content_type(public_path("{$logo}"))}};base64, {{base64_encode(file_get_contents(public_path("{$logo}")))}}"
                        alt="{{ \App\CoreFacturalo\Helpers\CompanyDocumentDisplay::logoAlt($company) }}" class="company_logo" style="max-width: 60%; margin-left: 20%;">
                </div>
            @endif
        </td>
    </tr>
    <tr>
        <td class="text-center text-uppercase">
            @include('pdf.partials.company_document_header_names_plain')<br>
            {{ 'RIF '.$company->number }}
        </td>
    </tr>
    <tr>
        <td class="desc text-uppercase">
            <br>
            {{ ($establishment->address !== '-')? $establishment->address : '' }}
            {{ ($establishment->district_id !== '-')? ', '.$establishment->district->description : '' }}
            {{ ($establishment->province_id !== '-')? ', '.$establishment->province->description : '' }}
            {{ ($establishment->department_id !== '-')? '- '.$establishment->department->description : '' }}
        </td>
    </tr>

    <tr>
        <td class="desc text-uppercase">
            @isset($establishment->trade_address)
                {{  ($establishment->trade_address !== '-')? 'D. COMERCIAL: '.$establishment->trade_address : ''  }}
                <br>
            @endisset
            {{ ($establishment->telephone !== '-')? 'CENTRAL TELEFÓNICA: '.$establishment->telephone : '' }} <br>
            {{ ($establishment->email !== '-')? 'EMAIL: '.$establishment->email : '' }} <br>
            @isset($establishment->web_address)
                {{ ($establishment->web_address !== '-')? 'WEB: '.$establishment->web_address : '' }} <br>
            @endisset
            @isset($establishment->aditional_information)
                {{ ($establishment->aditional_information !== '-')? $establishment->aditional_information : '' }} <br>
            @endisset
        </td>
    </tr>
    <tr>
        <td class="text-center pt-2 border-top"><h5>{{ $document->document_type->description }}</h5></td>
    </tr>
    <tr>
        <td class="text-center pb-2 border-bottom"><h5>{{ $document_number }}</h5></td>
    </tr>
</table>
<table class="full-width" style="font-family: helvetica">
    <tr>
        <td class="desc text-uppercase" colspan="2">
            Fecha de Emisión: {{ $document->date_of_issue->format('Y-m-d') }} <br>
            @isset($invoice->date_of_due)
                F. Vencimiento: {{ $invoice->date_of_due->format('Y-m-d') }} <br>
            @endisset
            Cliente: {{ $customer->name }} <br>
            {{ $customer->identity_document_type->description }}: {{ format_identity_document($customer->identity_document_type_id ?? null, $customer->number) }} <br>
            Dirección: {{ $customer->address }}
            {{ ($customer->district_id !== '-')? ', '.$customer->district->description : '' }}
            {{ ($customer->province_id !== '-')? ', '.$customer->province->description : '' }}
            {{ ($customer->department_id !== '-')? '- '.$customer->department->description : '' }}
        </td>
    </tr>

    @if ($document->reference_data)
        <tr>
            <td class="align-top"><p class="desc-ticket text-uppercase">D. Referencia:</p></td>
            <td>
                <p class="desc-ticket text-uppercase">
                    {{ $document->reference_data }}
                </p>
            </td>
        </tr>
    @endif




    @if ($document->purchase_order)
        <tr>
            <td><p class="desc-ticket text-uppercase">Orden de Compra:</p></td>
            <td><p class="desc-ticket text-uppercase">{{ $document->purchase_order }}</p></td>
        </tr>
    @endif
    @if ($document->quotation_id)
        <tr>
            <td><p class="desc-ticket text-uppercase">Cotización:</p></td>
            <td><p class="desc-ticket text-uppercase">{{ $document->quotation->identifier }}</p></td>
        </tr>
    @endif
    @isset($document->quotation->delivery_date)
        <tr>
            <td><p class="desc-ticket text-uppercase">F. Entrega</p></td>
            <td>
                <p class="desc-ticket text-uppercase">{{ $document->date_of_issue->addDays($document->quotation->delivery_date)->format('d-m-Y') }}</p>
            </td>
        </tr>
    @endisset
    @isset($document->quotation->sale_opportunity)
        <tr>
            <td><p class="desc-ticket text-uppercase">O. Venta</p></td>
            <td><p class="desc-ticket text-uppercase">{{ $document->quotation->sale_opportunity->number_full}}</p></td>
        </tr>
    @endisset
</table>

@if ($document->guides)
    <table>
        @foreach($document->guides as $guide)
            <tr>
                @if(isset($guide->document_type_description))
                    <td>{{ $guide->document_type_description }}</td>
                @else
                    <td>{{ $guide->document_type_id }}</td>
                @endif
                <td>:</td>
                <td>{{ $guide->number }}</td>
            </tr>
        @endforeach
    </table>
@endif


@if ($document->dispatch)
    <br/>
    <strong>Órdenes de entrega</strong>
    <table>
        <tr>
            <td>{{ $document->dispatch->number_full }}</td>
        </tr>
    </table>

@elseif (count($document->reference_guides) > 0)
    <br/>
    <span>Órdenes de entrega</span>
    <table>
        @foreach($document->reference_guides as $guide)
            <tr>
                <td>{{ $guide->series }}</td>
                <td>-</td>
                <td>{{ $guide->number }}</td>
            </tr>
        @endforeach
    </table>
@endif

@if(!is_null($document_base))
    <table>
        <tr>
            <td class="desc-ticket text-uppercase">Documento Afectado:</td>
            <td class="desc-ticket text-uppercase">{{ $affected_document_number }}</td>
        </tr>
        <tr>
            <td class="desc-ticket text-uppercase">Tipo de nota:</td>
            <td class="desc-ticket text-uppercase">{{ ($document_base->note_type === 'credit')?$document_base->note_credit_type->description:$document_base->note_debit_type->description}}</td>
        </tr>
        <tr>
            <td class="align-top desc-ticket">Descripción:</td>
            <td class="text-left desc-ticket">{{ $document_base->note_description }}</td>
        </tr>
    </table>
@endif

<table class="full-width mt-10 mb-10" style="font-family: 'Courier New', Courier, monospace">

    <tbody>
    <tr>
        <td class="border-top-bottom desc text-left"></td>
        <td class="border-top-bottom desc text-left">UdM</td>
        <td class="border-top-bottom desc text-left">DESCRIPCIÓN</td>
        <td class="border-top-bottom desc text-right" style="padding-right:5px;">P.UNIT</td>
        <td class="border-top-bottom desc text-right">TOTAL</td>
    </tr>
    @foreach($document->items as $row)
        <tr>
            <td class="text-left desc align-top">
                @if(((int)$row->quantity != $row->quantity))
                    {{ $row->quantity }}
                @else
                    {{ number_format($row->quantity, 0) }}
                @endif
            </td>
            <td class="text-left desc align-top">{{ $row->item->unit_type_id }}</td>
            <td class="text-left desc align-top text-uppercase">
                @if($row->name_product_pdf)
                    {!! \App\CoreFacturalo\Helpers\Template\TemplateHelper::formatNameProductPdfForTicket($row->name_product_pdf) !!}
                @else
                    {!!$row->item->description!!}
                @endif

                {{-- ########## INICIO SIN DETRACCIONES E ISC --}}


                @if (!empty($row->item->presentation)) {!!$row->item->presentation->description!!} @endif



                @foreach($row->additional_information as $information)
                    @if ($information)
                        <br/>{{ $information }}
                    @endif
                @endforeach

                @if($row->attributes)
                    @foreach($row->attributes as $attr)
                        <br/>{!! $attr->description !!} : {{ $attr->value }}
                    @endforeach
                @endif
                @if($row->discounts)
                    @foreach($row->discounts as $dtos)
                        @if(!($dtos->from_global_distribution ?? false))
                            <br/><small>{{ ($dtos->is_amount ?? false) ? '' : ($dtos->factor * 100).'%' }} {{$dtos->description }}</small>
                        @endif
                    @endforeach
                @endif

                @if($row->charges)
                    @foreach($row->charges as $charge)
                        <br/><small>{{ $document->currency_type->symbol}} {{ $charge->amount}}
                            ({{ $charge->factor * 100 }}%) {{$charge->description }}</small>
                    @endforeach
                @endif

                @if($document->has_prepayment)
                    <br>
                    *** Pago Anticipado ***
                @endif
            </td>
            <td class="text-right desc align-top"
                style="padding-right:5px;">{{ $row->formatPdfUnitPrice() }}</td>
            <td class="text-right desc align-top">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($row, 'total'), 2) }}</td>
        </tr>
        <tr>
            <td colspan="5" class="border-bottom"></td>
        </tr>
    @endforeach
    @if($document->total_exportation > 0)
        <tr>
            <td colspan="3" class="desc-ticket text-uppercase">OP. EXPORTACIÓN:
                {{ $document->currency_type->symbol }}</td>
            <td colspan="2"
                class="text-right desc-ticket text-uppercase">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exportation'), 2) }}</td>
        </tr>
    @endif


    @if($document->total_exonerated > 0)
        <tr>
            <td colspan="3" class="desc-ticket text-uppercase">OP. EXONERADAS:
                {{ $document->currency_type->symbol }}</td>
            <td colspan="2"
                class="text-right desc-ticket text-uppercase">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exonerated'), 2) }}</td>
        </tr>
    @endif
    @if($document->total_taxed > 0)
        <tr>
            <td colspan="3" class="desc-ticket text-uppercase">OP. GRAVADAS:
                {{ $document->currency_type->symbol }}</td>
            <td colspan="2"
                class="text-right desc-ticket text-uppercase">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_taxed'), 2) }}</td>
        </tr>
    @endif

    <tr>
        {{-- ########## INICIO CAMBIO IGV A IVA --}}
        <td colspan="3" class="desc-ticket text-uppercase">IVA:
        {{-- ######### FIN CAMBIO IGV A IVA --}}
            {{ $document->currency_type->symbol }}</td>
        <td colspan="2" class="text-right desc-ticket text-uppercase">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_igv'), 2) }}</td>
    </tr>

    {{-- ########## INICIO SIN DETRACCIONES E ISC --}}


    @if($document->subtotal > 0)
        @php
            $labelSubtotal = $document->total_discount_with_igv > 0 ? 'SUMA DE IMPORTES' : 'SUBTOTAL';
            $subtotal = $document->total_discount_with_igv > 0 ? \App\Support\Exact\PdfAmounts::read($document, 'subtotal')->plus(\App\Support\Exact\Decimal::of(\App\Support\Exact\Decimal::represent(\App\Support\Exact\PdfAmounts::read($document, 'total_discount_with_igv'), 2))) : \App\Support\Exact\PdfAmounts::read($document, 'subtotal');
        @endphp
        <tr>
            <td colspan="3" class="desc-ticket text-uppercase">{{ $labelSubtotal }}:
                {{ $document->currency_type->symbol }}</td>
            <td colspan="2"
                class="text-right desc-ticket text-uppercase">{{ \App\Support\Exact\Decimal::format($subtotal, 2) }}</td>
        </tr>
    @endif

    @if($document->total_discount_with_igv > 0)
        <tr>
            <td colspan="3"
                class="desc-ticket text-uppercase">{{(($document->total_prepayment > 0) ? 'ANTICIPO':'DESCUENTO TOTAL')}}
                :
                {{ $document->currency_type->symbol }}</td>
            <td colspan="2"
                class="text-right desc-ticket text-uppercase">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_discount_with_igv'), 2) }}</td>
        </tr>
    @endif

    @if($document->total_charge > 0)
        @if($document->charges)
            @php
                $total_factor = 0;
                foreach($document->charges as $charge) {
                    $total_factor = ($total_factor + $charge->factor) * 100;
                }
            @endphp
            <tr>
                <td colspan="3" class="desc-ticket text-uppercase">CARGOS ({{$total_factor}}%):
                    {{ $document->currency_type->symbol }}</td>
                <td colspan="2"
                    class="text-right desc-ticket text-uppercase">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_charge'), 2) }}</td>
            </tr>
        @else
            <tr>
                <td colspan="3" class="desc-ticket text-uppercase">CARGOS:
                    {{ $document->currency_type->symbol }}</td>
                <td colspan="2"
                    class="text-right desc-ticket text-uppercase">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_charge'), 2) }}</td>
            </tr>
        @endif
    @endif

    <tr>
        <td colspan="3" class="desc-ticket text-uppercase">TOTAL A PAGAR:
            {{ $document->currency_type->symbol }}</td>
        <td colspan="2" class="text-right desc-ticket text-uppercase">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total'), 2) }}</td>
    </tr>



    @if($balance < 0)
        <tr>
            <td colspan="3" class="desc-ticket text-uppercase">
                VUELTO:
                <span class="text-right">{{ $document->currency_type->symbol }}</span>
            </td>
            <td colspan="2"
                class="text-right desc-ticket text-uppercase">{{ number_format(abs($balance),2, ".", "") }}</td>
        </tr>
    @endif
    </tbody>
</table>
<table class="full-width" style="font-family: helvetica">
    <tr>

    @foreach(array_reverse((array) $document->legends) as $row)
        <tr>
            @if ($row->code == "1000")
            <td class="desc-ticket text-uppercase">
                <div style="font-size: 10px;">
                    Son: <span class="text-uppercase">{{ $row->value }} {{ $document->currency_type->description }}</span>
                </div>
            </td>
        @else
            <td class="desc-ticket">{{$row->code}}: {{ $row->value }}</td>
            @endif
            </tr>
            @endforeach
            </tr>
            @if(isset($configurationInPdf) && $configurationInPdf->show_seller_in_pdf)
            <tr>
                <td class="desc-ticket text-uppercase">
                    <div style="font-size: 10px;">
                        Vendedor:
                        @if ($document->seller)
                            <span>{{ $document->seller->name }}</span>
                        @else
                            <span>{{ $document->user->name }}</span>
                        @endif
                    </div>
                </td>
            </tr>
            @endif

            @if ($document->payment_condition_id === '01')
                @if($document->payment_method_type_id)
                    <tr>
                        <td class="desc-ticket">
                            <div style="font-size: 10px;">
                                PAGO: {{ $document->payment_method_type->description }}
                            </div>
                        </td>
                    </tr>
                @endif
                @if($payments->count())
                    <tr>
                        <td class="desc-ticket">
                            <div style="font-size: 10px;">
                                PAGOS:
                            </div>
                        </td>
                    </tr>
                    @foreach($payments as $row)
                        <tr>
                            <td class="desc-ticket text-uppercase">
                                <div style="font-size: 10px;">
                                    &#8226; {{ $row->payment_method_type->description }}
                                    - {{ $row->reference ? $row->reference.' - ':'' }}
                                    {{ $document->currency_type->symbol }} {{ $row->payment + $row->change }}
                                </div>
                            </td>
                        </tr>
                    @endforeach
                @endif
            @else
                @php
                    $paymentMethod = \App\Models\Tenant\PaymentMethodType::where('id', '09')->first();
                @endphp
                <table class="full-width">
                    <tr>
                        <td class="desc-ticket">
                            <div style="font-size: 10px;">
                                <span>PAGOS: {{ $paymentMethod->description }}</span>
                            </div>
                        </td>
                    </tr>
                    @foreach($document->fee as $key => $quote)
                        <tr>
                            <td class="desc-ticket text-uppercase">
                                <div style="font-size: 10px;">
                                    &#8226; {{ (empty($quote->getStringPaymentMethodType()) ? 'Cuota #'.( $key + 1) : $quote->getStringPaymentMethodType()) }}
                                    / Fecha: {{ $quote->date->format('d-m-Y') }} /
                                    Monto: {{ $quote->currency_type->symbol }}{{ $quote->amount }}
                                </div>
                            </td>
                        </tr>
                        @endforeach
                        </tr>
                </table>
            @endif

            @if ($document->terms_condition)
                <tr>
                    <td class="desc-ticket text-uppercase">
                        <div style="font-size: 10px; margin-bottom: 1px;">
                            Términos y condiciones del servicio
                        </div>
                        <div style="font-size: 8px;">
                            {!! $document->terms_condition !!}
                        </div>
                    </td>
                </tr>
            @endif

            <tr>
                <td class="text-center pt-2 border-top">
                </td>
            </tr>
            <tr>
            </tr>


            <tr>
                <td class="desc-ticket text-uppercase">
                    @foreach($document->additional_information as $information)
                        @if ($information)
                            @if ($loop->first)
                                <span class=" ">Información adicional</span>
                            @endif
                            <p>{{ $information }}</p>
                        @endif
                    @endforeach
                    <br>
                    @if(isset($configurationInPdf) && $configurationInPdf->show_bank_accounts_in_pdf)
                        @if(((string) $document->document_type->id === '01'))
                            @foreach($accounts as $account)
                                <br>{{$account->bank->description}}
                                <br>{{$account->currency_type->description}} N°: {{$account->number}}
                                @if($account->cci)
                                    <br>CCI: {{$account->cci}}
                                @endif
                            @endforeach
                        @endif
                    @endif

                </td>
            </tr>

            {{-- ######## INICIO MODALIDAD DE EMISIÓN FISCAL ######## --}}
@if(!((string) $document->document_type_id === '01' && $document->fiscal_emission_mode === 'digital'))
<tr>
                <td class="text-center desc-9 pt-2">Para consultar el comprobante ingresar a {!! url('/buscar') !!}</td>
            </tr>
@endif
{{-- ######## FIN MODALIDAD DE EMISIÓN FISCAL ######## --}}
</table>

</body>
</html>

{{-- ######## FIN MIGRACIÓN MONEDA VENEZUELA ######## --}}

{{-- ######## FIN PERSISTENCIA FISCAL VENEZUELA ######## --}}
