{{-- ######## INICIO PERSISTENCIA FISCAL VENEZUELA ######## --}}
{{-- ######## INICIO MIGRACIÓN MONEDA VENEZUELA ######## --}}
@php
    $establishment = $document->establishment;
    $customer = $document->customer;

    $document_base = $document->note;
    /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$document_number = $document->number_full;
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */

    /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$affected_document_number = $document_base->affected_document ? $document_base->affected_document->number_full : \App\Services\Fiscal\FiscalIdentity::numberFull($document_base->data_affected_document->series ?? '', $document_base->data_affected_document->number);
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */

    //$affected_document_number = \App\Services\Fiscal\FiscalIdentity::numberFull($document_base->affected_document->series, str_pad($document_base->affected_document->number, 8, '0', STR_PAD_LEFT));
    //$path_style = app_path('CoreFacturalo'.DIRECTORY_SEPARATOR.'Templates'.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.'style.css');

    $logo = "storage/uploads/logos/{$company->logo}";
    if($establishment->logo) {
        $logo = "{$establishment->logo}";
    }

@endphp
<html>
<head>
    {{--<title>{{ $document_number }}</title>--}}
    {{--<link href="{{ $path_style }}" rel="stylesheet" />--}}
</head>
<body>

@if($document->state_type->id == '11')
<div class="company_logo_box" style="position: absolute; text-align: center; top:30%;">
    <img
        src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png")))}}"
        alt="anulado" class="" style="opacity: 0.6;">
</div>
@endif
@if($document->state_type->id == '09')
<div class="company_logo_box" style="position: absolute; text-align: center; top:30%; left: 100px;">
    <img
        src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png")))}}"
        alt="rechazado" class="" style="opacity: 0.6;">
</div>
@endif

<table class="full-width">
    <tr>
        @if($company->logo)
            <td width="20%">
                <div class="company_logo_box">
                    <img src="data:{{mime_content_type(public_path("{$logo}"))}};base64, {{base64_encode(file_get_contents(public_path("{$logo}")))}}" alt="{{ \App\CoreFacturalo\Helpers\CompanyDocumentDisplay::logoAlt($company) }}" alt="{{ \App\CoreFacturalo\Helpers\CompanyDocumentDisplay::logoAlt($company) }}" class="company_logo" style="max-width: 150px;">
                </div>
            </td>
            <td width="50%" class="text-center pl-3">
                <div class="text-left">
                    @include('pdf.partials.company_document_header_names')
                    <h5>{{ 'RIF '.$company->number }}</h5>
                    <h6 style="text-transform: uppercase;">
                        {{ ($establishment->address !== '-')? $establishment->address : '' }}
                        {{ ($establishment->district_id !== '-')? ', '.$establishment->district->description : '' }}
                        {{ ($establishment->province_id !== '-')? ', '.$establishment->province->description : '' }}
                        {{ ($establishment->department_id !== '-')? '- '.$establishment->department->description : '' }}
                    </h6>
                    <h6>{{ ($establishment->email !== '-')? $establishment->email : '' }}</h6>
                    <h6>{{ ($establishment->telephone !== '-')? $establishment->telephone : '' }}</h6>
                </div>
            </td>
            <td width="30%" class="border-box py-4 px-2 text-center">
                <h5 class="text-center">{{ $document->document_type->description }}</h5>
                <h3 class="text-center">{{ $document_number }}</h3>
            </td>
        @else
            <td width="70%" class="pl-1">
                <div class="text-left">
                    @include('pdf.partials.company_document_header_names')
                    <h5>{{ 'RIF '.$company->number }}</h5>
                    <h6 style="text-transform: uppercase;">
                        {{ ($establishment->address !== '-')? $establishment->address : '' }}
                        {{ ($establishment->district_id !== '-')? ', '.$establishment->district->description : '' }}
                        {{ ($establishment->province_id !== '-')? ', '.$establishment->province->description : '' }}
                        {{ ($establishment->department_id !== '-')? '- '.$establishment->department->description : '' }}
                    </h6>
                    <h6>{{ ($establishment->email !== '-')? $establishment->email : '' }}</h6>
                    <h6>{{ ($establishment->telephone !== '-')? $establishment->telephone : '' }}</h6>
                </div>
            </td>
            <td width="30%" class="border-box py-4 px-2 text-center">
                <h5 class="text-center">{{ $document->document_type->description }}</h5>
                <h3 class="text-center">{{ $document_number }}</h3>
            </td>
        @endif
    </tr>
</table>

<table class="full-width mt-5">
    <tr>
        <td width="120px">FECHA DE EMISIÓN</td>
        <td width="5px">:</td>
        <td>{{ $document->date_of_issue->format('Y-m-d') }} / {{ $document->time_of_issue }}</td>
    </tr>
    <tr>
        <td>CLIENTE</td>
        <td>:</td>
        <td>{{ $customer->name }}</td>
    </tr>
    <tr>
        <td>{{ $customer->identity_document_type->description }}</td>
        <td>:</td>
        <td>{{ format_identity_document($customer->identity_document_type_id ?? null, $customer->number) }}</td>
        {{--@isset($document->date_of_due)--}}
            {{--<td>Fecha de vencimiento:</td>--}}
            {{--<td>{{ $document->date_of_due->format('Y-m-d') }}</td>--}}
        {{--@endisset--}}
    </tr>
    @if ($customer->address !== '')
    <tr>
        <td class="align-top">DIRECCIÓN</td>
        <td>:</td>
        <td>
            {{ $customer->address }}
            {{ ($customer->district_id !== '-')? ', '.$customer->district->description : '' }}
            {{ ($customer->province_id !== '-')? ', '.$customer->province->description : '' }}
            {{ ($customer->department_id !== '-')? '- '.$customer->department->description : '' }}
        </td>
    </tr>
    @endif
</table>

@if ($document->guides)
<table class="full-width mt-3">
@foreach($document->guides as $guide)
    <tr>
        <td>{{ $guide->document_type_id }}</td>
        <td>{{ $guide->number }}</td>
    </tr>
@endforeach
</table>
@endif

<table class="full-width mt-3">
    @if ($document->purchase_order)
    <tr>
        <td>ORDEN DE COMPRA</td>
        <td>:</td>
        <td>{{ $document->purchase_order }}</td>
    </tr>
    @endif
    <tr>
        <td width="120px">DOC. AFECTADO</td>
        <td width="5px">:</td>
        <td>{{ $affected_document_number }}</td>
    </tr>
    <tr>
        <td>TIPO DE NOTA</td>
        <td>:</td>
        <td>{{ ($document_base->note_type === 'credit')?$document_base->note_credit_type->description:$document_base->note_debit_type->description}}</td>
    </tr>
    <tr>
        <td>DESCRIPCIÓN</td>
        <td>:</td>
        <td>{{ $document_base->note_description }}</td>
    </tr>
</table>
<table class="full-width mt-10 mb-10">
    <thead class="">
    <tr class="bg-grey">
        <th class="border-top-bottom text-left py-2" width="">COD.</th>
        <th class="border-top-bottom text-center py-2" width="8%">CANT.</th>
        <th class="border-top-bottom text-center py-2" width="8%">UNIDAD</th>
        <th class="border-top-bottom text-left py-2">DESCRIPCIÓN</th>
        <th class="border-top-bottom text-right py-2" width="12%">P.UNIT</th>
        <th class="border-top-bottom text-right py-2" width="8%">DTO.</th>
        <th class="border-top-bottom text-right py-2" width="12%">TOTAL</th>
    </tr>
    </thead>
    <tbody>
    @foreach($document->items as $row)
        <tr>
            <td class="text-left align-top">{{ $row->relation_item->internal_id }}</td>
            <td class="text-center">
                @if(((int)$row->quantity != $row->quantity))
                    {{ $row->quantity }}
                @else
                    {{ number_format($row->quantity, 0) }}
                @endif
            </td>
            <td class="text-center">{{ $row->item->unit_type_id }}</td>
            <td class="text-left">
                @if($row->name_product_pdf)
                    {!!$row->name_product_pdf!!}
                @else
                    {!!$row->item->description!!}
                @endif
                @if($row->attributes)
                    @foreach($row->attributes as $attr)
                        <br/><span style="font-size: 9px">{!! $attr->description !!} : {{ $attr->value }}</span>
                    @endforeach
                @endif
                @if($row->discounts)
                    @foreach($row->discounts as $dtos)
                        @if(!($dtos->from_global_distribution ?? false))
                            <br/><span style="font-size: 9px">{{ ($dtos->is_amount ?? false) ? '' : ($dtos->factor * 100).'%' }} {{$dtos->description }}</span>
                        @endif
                    @endforeach
                @endif
            </td>
            <td class="text-right">{{ $row->formatPdfUnitPrice() }}</td>
            <td class="text-right align-top">
                @if($row->discounts)
                    @php $total_discount_line = \App\Support\Exact\PdfAmounts::lineDiscount($row, false); @endphp
                    {{ \App\Support\Exact\Decimal::format($total_discount_line, 2) }}
                @else
                0.00
                @endif
            </td>
            <td class="text-right">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($row, 'total'), 2) }}</td>
        </tr>
        <tr>
            <td colspan="7" class="border-bottom"></td>
        </tr>
    @endforeach
        @if($document->total_exportation > 0)
            <tr>
                <td colspan="6" class="text-right font-bold">OP. EXPORTACIÓN: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exportation'), 2) }}</td>
            </tr>
        @endif


        @if($document->total_exonerated > 0)
            <tr>
                <td colspan="6" class="text-right font-bold">OP. EXONERADAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exonerated'), 2) }}</td>
            </tr>
        @endif
        @if($document->total_taxed > 0)
            <tr>
                <td colspan="6" class="text-right font-bold">OP. GRAVADAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_taxed'), 2) }}</td>
            </tr>
        @endif
        @if($document->total_discount_with_igv > 0)
            <tr>
                <td colspan="6" class="text-right font-bold">{{(($document->total_prepayment > 0) ? 'ANTICIPO':'DESCUENTO TOTAL')}}: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_discount_with_igv'), 2) }}</td>
            </tr>
        @endif
        <tr>
            {{-- ########## INICIO CAMBIO IGV A IVA --}}
            <td colspan="6" class="text-right font-bold">IVA: {{ $document->currency_type->symbol }}</td>
            {{-- ######### FIN CAMBIO IGV A IVA --}}
            <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_igv'), 2) }}</td>
        </tr>
        <tr>
            <td colspan="6" class="text-right font-bold">TOTAL A PAGAR: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total'), 2) }}</td>
        </tr>
    </tbody>
    <tfoot style="border-top: 1px solid #333;">


    @if ($document->payment_condition_id === '02' && $document->isCreditNoteAndType13())
        @foreach($document->fee as $key => $quote)
            <tr>
                <td colspan="5" >&#8226; {{ (empty($quote->getStringPaymentMethodType()) ? 'Cuota #'.( $key + 1) : $quote->getStringPaymentMethodType()) }} / Fecha: {{ $quote->date->format('d-m-Y') }} / Monto: {{ $quote->currency_type->symbol }}{{ $quote->amount }}</td>
            </tr>
        @endforeach
    @endif

    <tr>
        <td colspan="5" class="font-lg"  style="padding-top: 2rem;text-transform: uppercase;">Son: <span class="font-bold">{{ $document->number_to_letter }} {{ $document->currency_type->description }}</span></td>
    </tr>
    @if(isset($document->optional->observations))
        <tr>
            <td colspan="3"><b>Obsevaciones</b></td>
            <td colspan="2"></td>
        </tr>
        <tr>
            <td colspan="3">{{ $document->optional->observations }}</td>
            <td colspan="2"></td>
        </tr>
    @endif
    </tfoot>
</table>

<table class="full-width">
    <tr>
        <td width="65%">
        </td>
    </tr>
</table>
</body>
</html>

{{-- ######## FIN MIGRACIÓN MONEDA VENEZUELA ######## --}}

{{-- ######## FIN PERSISTENCIA FISCAL VENEZUELA ######## --}}
