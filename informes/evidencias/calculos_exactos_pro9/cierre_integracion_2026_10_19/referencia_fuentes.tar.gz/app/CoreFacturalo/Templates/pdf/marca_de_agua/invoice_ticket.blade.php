{{-- ######## INICIO PERSISTENCIA FISCAL VENEZUELA ######## --}}
{{-- ######## INICIO MIGRACIÓN MONEDA VENEZUELA ######## --}}
@php
    use Modules\Template\Helpers\TemplatePdf;

    $establishment = $document->establishment;
    $customer = $document->customer;
    $invoice = $document->invoice;
    //$path_style = app_path('CoreFacturalo'.DIRECTORY_SEPARATOR.'Templates'.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.'style.css');
    /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$document_number = $document->number_full;
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */

    // $accounts = \App\Models\Tenant\BankAccount::where('show_in_documents', true)->get();
    $accounts = (new TemplatePdf)->getBankAccountsForPdf($document->establishment_id);

    $document_base = ($document->note) ? $document->note : null;
    $payments = $document->payments;

    if($document_base) {
        /* ######## INICIO NUMERACIÓN FISCAL VENEZUELA ######## */
$affected_document_number = $document_base->affected_document ? $document_base->affected_document->number_full : \App\Services\Fiscal\FiscalIdentity::numberFull($document_base->data_affected_document->series ?? '', $document_base->data_affected_document->number);
/* ######## FIN NUMERACIÓN FISCAL VENEZUELA ######## */

    } else {
        $affected_document_number = null;
    }
    $document->load('reference_guides');

    $total_payment = $document->payments->sum('payment');
    $balance = $document instanceof \App\Models\Tenant\Document ? $document->balance : (($document->total - $total_payment) - $document->payments->sum('change'));


    $logo = "storage/uploads/logos/{$company->logo}";
    if($establishment->logo) {
        $logo = "{$establishment->logo}";
    }
    $configurationInPdf= App\CoreFacturalo\Helpers\Template\TemplateHelper::getConfigurationInPdf();

@endphp
<html>
<head>
    {{--<title>{{ $document_number }}</title>--}}
    {{--<link href="{{ $path_style }}" rel="stylesheet" />--}}
</head>
<body class="ticket">

@if($company->logo)
    <div class="text-center company_logo_box pt-5">
        <img
            src="data:{{mime_content_type(public_path("{$logo}"))}};base64, {{base64_encode(file_get_contents(public_path("{$logo}")))}}"
            alt="{{ \App\CoreFacturalo\Helpers\CompanyDocumentDisplay::logoAlt($company) }}" class="company_logo_ticket contain">
    </div>
    {{--@else--}}
    {{--<div class="text-center company_logo_box pt-5">--}}
    {{--<img src="{{ asset('logo/logo.jpg') }}" class="company_logo_ticket contain">--}}
    {{--</div>--}}
@endif

@if($document->state_type->id == '11')
    <div class="company_logo_box" style="position: absolute; text-align: center; top:500px">
        <img
            src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."anulado.png")))}}"
            alt="anulado" class="" style="opacity: 0.6;">
    </div>
@endif
@if($document->state_type->id == '09')
    <div style="position: absolute; width: 100%; text-align: center; top:30%; left: 0; right: 0; margin: auto;">
        <img
            src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."rechazado.png")))}}"
            alt="rechazado" class="" style="opacity: 0.6; width: 50%;">
    </div>
@endif
@if(isset($configuration['is_preview']) && $configuration['is_preview'])
    <div style="position: absolute; width: 100%; text-align: center; top:30%; left: 0; right: 0; margin: auto;">
        <img
            src="data:{{mime_content_type(public_path("status_images".DIRECTORY_SEPARATOR."vista_previa.png"))}};base64, {{base64_encode(file_get_contents(public_path("status_images".DIRECTORY_SEPARATOR."vista_previa.png")))}}"
            alt="vista previa" class="" style="opacity: 0.6; width: 50%;">
    </div>
@endif
<table class="full-width">
    <tr>
        <td class="text-center">@include('pdf.partials.company_document_header_names')</td>
    </tr>
    {{--<tr>
        <td class="text-center"><h5>{{ $company->trade_name }}</h5></td>
    </tr>--}}
    <tr>
        <td class="text-center"><h5>{{ 'RIF '.$company->number }}</h5></td>
    </tr>
    <tr>
        <td class="text-center" style="text-transform: uppercase;">
            {{ ($establishment->address !== '-')? $establishment->address : '' }}
            {{ ($establishment->district_id !== '-')? ', '.$establishment->district->description : '' }}
            {{ ($establishment->province_id !== '-')? ', '.$establishment->province->description : '' }}
            {{ ($establishment->department_id !== '-')? '- '.$establishment->department->description : '' }}
        </td>
    </tr>

    @isset($establishment->trade_address)
        <tr>
            <td class="text-center ">{{  ($establishment->trade_address !== '-')? 'D. Comercial: '.$establishment->trade_address : ''  }}</td>
        </tr>
    @endisset
    <tr>
        <td class="text-center ">{{ ($establishment->telephone !== '-')? 'Central telefónica: '.$establishment->telephone : '' }}</td>
    </tr>
    <tr>
        <td class="text-center">{{ ($establishment->email !== '-')? 'Email: '.$establishment->email : '' }}</td>
    </tr>
    @isset($establishment->web_address)
        <tr>
            <td class="text-center">{{ ($establishment->web_address !== '-')? 'Web: '.$establishment->web_address : '' }}</td>
        </tr>
    @endisset

    @isset($establishment->aditional_information)
        <tr>
            <td class="text-center pb-3">{{ ($establishment->aditional_information !== '-')? $establishment->aditional_information : '' }}</td>
        </tr>
    @endisset
    <tr>
        <td class="text-center pt-3 border-top"><h3>{{ 'R.I.F. '.$company->number }}</h3></td>
    </tr>
    <tr>
        <td class="text-center"><h4>{{ $document->document_type->description }}</h4></td>
    </tr>
    <tr>
        <td class="text-center pb-3 border-bottom"><h3>{{ $document_number }}</h3></td>
    </tr>
</table>
<table class="full-width">
    <tr>
        <td width="" class="pt-3"><p class="desc">F. Emisión:</p></td>
        <td width="" class="pt-3"><p class="desc">{{ $document->date_of_issue->format('Y-m-d') }}</p></td>
    </tr>
    <tr>
        <td width=""><p class="desc">H. Emisión:</p></td>
        <td width=""><p class="desc">{{ $document->time_of_issue }}</p></td>
    </tr>
    @isset($invoice->date_of_due)
        <tr>
            <td><p class="desc">F. Vencimiento:</p></td>
            <td><p class="desc">{{ $invoice->date_of_due->format('Y-m-d') }}</p></td>
        </tr>
    @endisset

    <tr>
        <td class="align-top"><p class="desc">Cliente:</p></td>
        <td><p class="desc">{{ $customer->name }}</p></td>
    </tr>
    <tr>
        <td><p class="desc">{{ $customer->identity_document_type->description }}:</p></td>
        <td><p class="desc">{{ format_identity_document($customer->identity_document_type_id ?? null, $customer->number) }}</p></td>
    </tr>
    @if ($customer->address !== '')
        <tr>
            <td class="align-top"><p class="desc">Dirección:</p></td>
            <td>
                <p class="desc">
                    {{ $customer->address }}
                    {{ ($customer->district_id !== '-')? ', '.$customer->district->description : '' }}
                    {{ ($customer->province_id !== '-')? ', '.$customer->province->description : '' }}
                    {{ ($customer->department_id !== '-')? '- '.$customer->department->description : '' }}
                </p>
            </td>
        </tr>
    @endif

    @if ($document->reference_data)
        <tr>
            <td class="align-top"><p class="desc">D. Referencia:</p></td>
            <td>
                <p class="desc">
                    {{ $document->reference_data }}
                </p>
            </td>
        </tr>
    @endif

    @if ($document->isPointSystem())
        <tr>
            <td><p class="desc">P. Acumulados:</p></td>
            <td><p class="desc">{{ $document->person->accumulated_points }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">Puntos por la compra:</p></td>
            <td><p class="desc">{{ $document->getPointsBySale() }}</p></td>
        </tr>
    @endif






    @if ($document->prepayments)
        @foreach($document->prepayments as $p)
            <tr>
                <td><p class="desc">Anticipo :</p></td>
                <td><p class="desc">{{$p->number}}</p></td>
            </tr>
        @endforeach
    @endif
    @if ($document->purchase_order)
        <tr>
            <td><p class="desc">Orden de Compra:</p></td>
            <td><p class="desc">{{ $document->purchase_order }}</p></td>
        </tr>
    @endif
    @if ($document->quotation_id)
        <tr>
            <td><p class="desc">Cotización:</p></td>
            <td><p class="desc">{{ $document->quotation->identifier }}</p></td>
        </tr>
    @endif
    @isset($document->quotation->delivery_date)
        <tr>
            <td><p class="desc">F. Entrega</p></td>
            <td>
                <p class="desc">{{ $document->date_of_issue->addDays($document->quotation->delivery_date)->format('d-m-Y') }}</p>
            </td>
        </tr>
    @endisset
    @isset($document->quotation->sale_opportunity)
        <tr>
            <td><p class="desc">O. Venta</p></td>
            <td><p class="desc">{{ $document->quotation->sale_opportunity->number_full}}</p></td>
        </tr>
    @endisset
</table>

@if ($document->guides)
    {{--<strong>Órdenes de entrega:</strong>--}}
    <table>
        @foreach($document->guides as $guide)
            <tr>
                @if(isset($guide->document_type_description))
                    <td class="desc">{{ $guide->document_type_description }}</td>
                @else
                    <td class="desc">{{ $guide->document_type_id }}</td>
                @endif
                <td class="desc">:</td>
                <td class="desc">{{ $guide->number }}</td>
            </tr>
        @endforeach
    </table>
@endif


@if ($document->transport)
    <p class="desc"><strong>Transporte de pasajeros</strong></p>

    @php
        $transport = $document->transport;
        $origin_district_id = (array)$transport->origin_district_id;
        $destinatation_district_id = (array)$transport->destinatation_district_id;
        $origin_district = Modules\Order\Services\AddressFullService::getDescription($origin_district_id[2]);
        $destinatation_district = Modules\Order\Services\AddressFullService::getDescription($destinatation_district_id[2]);
    @endphp


    <table class="full-width mt-3">
        <tr>
            <td><p class="desc">{{ $transport->identity_document_type->description }}:</p></td>
            <td><p class="desc">{{ $transport->number_identity_document }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">Nombre:</p></td>
            <td><p class="desc">{{ $transport->passenger_fullname }}</p></td>
        </tr>


        <tr>
            <td><p class="desc">N° Asiento:</p></td>
            <td><p class="desc">{{ $transport->seat_number }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">M. Pasajero:</p></td>
            <td><p class="desc">{{ $transport->passenger_manifest }}</p></td>
        </tr>

        <tr>
            <td><p class="desc">F. Inicio:</p></td>
            <td><p class="desc">{{ $transport->start_date }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">H. Inicio:</p></td>
            <td><p class="desc">{{ $transport->start_time }}</p></td>
        </tr>


        <tr>
            <td><p class="desc">U. Origen:</p></td>
            <td><p class="desc">{{ $origin_district }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">D. Origen:</p></td>
            <td><p class="desc">{{ $transport->origin_address }}</p></td>
        </tr>

        <tr>
            <td><p class="desc">U. Destino:</p></td>
            <td><p class="desc">{{ $destinatation_district }}</p></td>
        </tr>
        <tr>
            <td><p class="desc">D. Destino:</p></td>
            <td><p class="desc">{{ $transport->destinatation_address }}</p></td>
        </tr>

    </table>
@endif


@if ($document->dispatch)
    <br/>
    <strong>Órdenes de entrega</strong>
    <table>
        <tr>
            <td>{{ $document->dispatch->number_full }}</td>
        </tr>
    </table>

@elseif (count($document->reference_guides) > 0)
    <br/>
    <strong>Órdenes de entrega</strong>
    <table>
        @foreach($document->reference_guides as $guide)
            <tr>
                <td>{{ $guide->series }}</td>
                <td>-</td>
                <td>{{ $guide->number }}</td>
            </tr>
        @endforeach
    </table>
@endif

@if(!is_null($document_base))
    <table>
        <tr>
            <td class="desc">Documento Afectado:</td>
            <td class="desc">{{ $affected_document_number }}</td>
        </tr>
        <tr>
            <td class="desc">Tipo de nota:</td>
            <td class="desc">{{ ($document_base->note_type === 'credit')?$document_base->note_credit_type->description:$document_base->note_debit_type->description}}</td>
        </tr>
        <tr>
            <td class="align-top desc">Descripción:</td>
            <td class="text-left desc">{{ $document_base->note_description }}</td>
        </tr>
    </table>
@endif

<table class="full-width mt-10 mb-10">
    <thead class="">
    <tr>
        <th class="border-top-bottom desc-9 text-left">COD.</th>
        <th class="border-top-bottom desc-9 text-left">CANT.</th>
        <th class="border-top-bottom desc-9 text-left">UNIDAD</th>
        <th class="border-top-bottom desc-9 text-left">DESCRIPCIÓN</th>
        <th class="border-top-bottom desc-9 text-left">P.UNIT</th>
        <th class="border-top-bottom desc-9 text-left">TOTAL</th>
    </tr>
    </thead>
    <tbody>
    @php
        $data_json_items = collect($document->data_json->items ?? []);
        $fusionados = $data_json_items->filter(function($item) {return !empty($item->esFusionado);});
        $hay_fusionados = $fusionados->isNotEmpty();
        $cantidad_fusionada = \App\Support\Exact\Decimal::sum($fusionados->map(fn ($item) => \App\Support\Exact\Decimal::read($item, 'cantidad')));

        $total_fusionado = \App\Support\Exact\Decimal::sum($fusionados->map(fn ($item) => \App\Support\Exact\Decimal::read($item, 'total_item')));
    @endphp
    @if($hay_fusionados)
        <tr>
            <td class="text-center desc-9 align-top font-bold">001</td>
            <td class="text-center">{{ \App\Support\Exact\Decimal::represent($cantidad_fusionada) }}</td>
            <td class="text-center desc-9 align-top">UND</td>
            <td class="text-left desc-9 align-top font-bold">Por consumo</td>
            <td class="text-right">{{ \App\Support\Exact\PdfPrice::configured($cantidad_fusionada->isZero() ? 0 : $total_fusionado->dividedBy($cantidad_fusionada)) }}</td>
            <td class="text-right">{{ \App\Support\Exact\Decimal::format($total_fusionado) }}</td>
        </tr>
        <tr><td colspan="6" class="border-bottom"></td></tr>
    @else
        @foreach($document->items as $row)
            <tr>
                <td class="text-center desc-9 align-top font-bold">{{ $row->item->internal_id }}</td>
                <td class="text-center desc-9 align-top font-bold">
                    @if(((int)$row->quantity != $row->quantity))
                        {{ $row->quantity }}
                    @else
                        {{ number_format($row->quantity, 0) }}
                    @endif
                </td>
                <td class="text-center desc-9 align-top">{{ $row->item->unit_type_id }}</td>
                <td class="text-left desc-9 align-top font-bold">
                    @if($row->name_product_pdf)
                        {!! \App\CoreFacturalo\Helpers\Template\TemplateHelper::formatNameProductPdfForTicket($row->name_product_pdf) !!}
                    @else
                        {!!$row->item->description!!}
                    @endif

                    {{-- ########## INICIO SIN DETRACCIONES E ISC --}}


                    @if (!empty($row->item->presentation)) {!!$row->item->presentation->description!!} @endif



                    @foreach($row->additional_information as $information)
                        @if ($information)
                            <br/>{{ $information }}
                        @endif
                    @endforeach

                    @if($row->attributes)
                        @foreach($row->attributes as $attr)
                            <br/>{!! $attr->description !!} : {{ $attr->value }}
                        @endforeach
                    @endif
                    @if($row->discounts)
                        @foreach($row->discounts as $dtos)
                            @if(!($dtos->from_global_distribution ?? false))
                                <br/><small>{{ ($dtos->is_amount ?? false) ? '' : ($dtos->factor * 100).'%' }} {{$dtos->description }}</small>
                            @endif
                        @endforeach
                    @endif

                    @if($row->charges)
                        @foreach($row->charges as $charge)
                            <br/><small>{{ $document->currency_type->symbol}} {{ $charge->amount}}
                                ({{ $charge->factor * 100 }}%) {{$charge->description }}</small>
                        @endforeach
                    @endif

                    @if($row->item->is_set == 1)

                        <br>
                        @inject('itemSet', 'App\Services\ItemSetService')
                        @foreach ($itemSet->getItemsSet($row->item_id) as $item)
                            {{$item}}<br>
                        @endforeach
                        {{-- {{join( "-", $itemSet->getItemsSet($row->item_id) )}} --}}
                    @endif

                    @if($row->item->used_points_for_exchange ?? false)
                        <br>
                        <small>*** Canjeado por {{$row->item->used_points_for_exchange}} puntos ***</small>
                    @endif

                    @if($document->has_prepayment)
                        <br>
                        *** Pago Anticipado ***
                    @endif
                </td>
                <td class="text-right desc-9 align-top">{{ $row->formatPdfUnitPrice() }}</td>
                <td class="text-right desc-9 align-top font-bold">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($row, 'total'), 2) }}</td>
            </tr>
            <tr>
                <td colspan="6" class="border-bottom"></td>
            </tr>
        @endforeach
    @endif

    @if ($document->prepayments)
        @foreach($document->prepayments as $p)
            <tr>
                <td class="text-center desc-9 align-top">
                    1
                </td>
                <td class="text-center desc-9 align-top">UND</td>
                <td class="text-left desc-9 align-top">
                    ANTICIPO: FACTURA NRO. {{$p->number}}
                </td>
                <td class="text-right  desc-9 align-top">-{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($p, 'total'), 2) }}</td>
                <td class="text-right  desc-9 align-top">-{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($p, 'total'), 2) }}</td>
            </tr>
            <tr>
                <td colspan="5" class="border-bottom"></td>
            </tr>
        @endforeach
    @endif

    @if($document->total_exportation > 0)
        <tr>
            <td colspan="5" class="text-right font-bold desc">OP.
                EXPORTACIÓN: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exportation'), 2) }}</td>
        </tr>
    @endif


    @if($document->total_exonerated > 0)
        <tr>
            <td colspan="5" class="text-right font-bold desc">OP.
                EXONERADAS: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_exonerated'), 2) }}</td>
        </tr>
    @endif

    @if ($document->document_type_id === '07')
        @if($document->total_taxed >= 0)
            <tr>
                <td colspan="5" class="text-right font-bold desc">OP.
                    GRAVADAS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_taxed'), 2) }}</td>
            </tr>
        @endif
    @elseif($document->total_taxed > 0)
        <tr>
            <td colspan="5" class="text-right font-bold desc">OP. GRAVADAS: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_taxed'), 2) }}</td>
        </tr>
    @endif


    <tr>
        {{-- ########## INICIO CAMBIO IGV A IVA --}}
        <td colspan="5" class="text-right font-bold desc">IVA: {{ $document->currency_type->symbol }}</td>
        {{-- ######### FIN CAMBIO IGV A IVA --}}
        <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_igv'), 2) }}</td>
    </tr>

    {{-- ########## INICIO SIN DETRACCIONES E ISC --}}


    @if($document->subtotal > 0)
        @php
            $labelSubtotal = $document->total_discount_with_igv > 0 ? 'SUMA DE IMPORTES' : 'SUBTOTAL';
            $subtotal = $document->total_discount_with_igv > 0 ? \App\Support\Exact\PdfAmounts::read($document, 'subtotal')->plus(\App\Support\Exact\Decimal::of(\App\Support\Exact\Decimal::represent(\App\Support\Exact\PdfAmounts::read($document, 'total_discount_with_igv'), 2))) : \App\Support\Exact\PdfAmounts::read($document, 'subtotal');
        @endphp
        <tr>
            <td colspan="5" class="text-right font-bold desc">{{ $labelSubtotal }}: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format($subtotal, 2) }}</td>
        </tr>
    @endif

    @if($document->total_discount_with_igv > 0)
        <tr>
            <td colspan="5" class="text-right font-bold desc">DESCUENTO
                TOTAL: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_discount_with_igv'), 2) }}</td>
        </tr>
    @endif

    @if($document->total_charge > 0)
        @if($document->charges)
            @php
                $total_factor = 0;
                foreach($document->charges as $charge) {
                    $total_factor = ($total_factor + $charge->factor) * 100;
                }
            @endphp
            <tr>
                <td colspan="5" class="text-right font-bold desc">CARGOS ({{$total_factor}}
                    %): {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_charge'), 2) }}</td>
            </tr>
        @else
            <tr>
                <td colspan="5" class="text-right font-bold desc">CARGOS: {{ $document->currency_type->symbol }}</td>
                <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total_charge'), 2) }}</td>
            </tr>
        @endif
    @endif


        <tr>
            <td colspan="5" class="text-right font-bold desc">TOTAL A PAGAR: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ \App\Support\Exact\Decimal::format(\App\Support\Exact\PdfAmounts::read($document, 'total'), 2) }}</td>
        </tr>




    @if($balance < 0)
        <tr>
            <td colspan="5" class="text-right font-bold desc">VUELTO: {{ $document->currency_type->symbol }}</td>
            <td class="text-right font-bold desc">{{ number_format(abs($balance),2, ".", "") }}</td>
        </tr>
    @endif
    </tbody>
</table>
<table class="full-width">
    @foreach(array_reverse((array) $document->legends) as $row)
        <tr>
            @if ($row->code == "1000")
                <td class="desc pt-3" colspan="2">Son: <span class="font-bold">{{ $row->value }} {{ $document->currency_type->description }}</span></td>
            @else
                <td class="desc pt-3" colspan="2">{{$row->code}}: {{ $row->value }}</td>
            @endif
        </tr>
    @endforeach
    <tr>
        <td class="text-left pt-1 align-top">
            <!-- HKA_TICKET_QR -->
        </td>
        <td class="align-top">
            @foreach($document->additional_information as $information)
                @if ($information)
                    @if ($loop->first)
                        <strong>Información adicional</strong>
                    @endif
                    <p class="desc">{{ $information }}</p>
                @endif
            @endforeach
            @if(isset($configurationInPdf) && $configurationInPdf->show_bank_accounts_in_pdf)
                @if(((string) $document->document_type->id === '01'))
                    @foreach($accounts as $account)
                        <p class="desc">
                            <small>
                                <span class="font-bold desc">{{$account->bank->description}}</span> {{$account->currency_type->description}}
                                <span class="font-bold desc">N°:</span> {{$account->number}}
                                @if($account->cci)
                                <span class="font-bold desc">CCI:</span> {{$account->cci}}
                                @endif
                            </small>
                        </p>
                    @endforeach
                @endif
            @endif


            @php
                $paymentCondition = \App\CoreFacturalo\Helpers\Template\TemplateHelper::getDocumentPaymentCondition($document);
            @endphp
            {{-- Condicion de pago  Crédito / Contado --}}
            <p class="desc pt-5">
                <strong>CONDICIÓN DE PAGO: {{ $paymentCondition }} </strong>
            </p>

            @if($document->payment_method_type_id)
                <p class="desc pt-5">
                    <strong>MÉTODO DE PAGO: </strong>{{ $document->payment_method_type->description }}
                </p>
            @endif

            @if ($document->payment_condition_id === '01')

                @if($payments->count())
                        <p class="desc pt-5">
                            <strong>PAGOS:</strong>
                        </p>
                    @foreach($payments as $row)
                        <p>
                            <span class="desc">&#8226; {{ $row->payment_method_type->description }} - {{ $row->reference ? $row->reference.' - ':'' }} {{ $document->currency_type->symbol }} {{ $row->payment + $row->change }}</span>
                        </p>
                    @endforeach
                @endif
            @else
                @foreach($document->fee as $key => $quote)
                    <p class="desc pt-5">
                        <span class="desc">&#8226; {{ (empty($quote->getStringPaymentMethodType()) ? 'Cuota #'.( $key + 1) : $quote->getStringPaymentMethodType()) }} / Fecha: {{ $quote->date->format('d-m-Y') }} / Monto: {{ $quote->currency_type->symbol }}{{ $quote->amount }}</span>
                    </p>
                @endforeach
            @endif
            @if(isset($configurationInPdf) && $configurationInPdf->show_seller_in_pdf)
                <tr>
                    <td class="desc">
                        <strong>Vendedor:</strong>
                    </td>
                </tr>
                <tr>
                    @if ($document->seller)
                        <td class="desc">{{ $document->seller->name }}</td>
                    @else
                        <td class="desc">{{ $document->user->name }}</td>
                    @endif
                </tr>
            @endif

        </td>
    </tr>
</table>
<table class="full-width">
@if ($document->terms_condition)
        <tr>
            <td class="desc">
                <br>
                <h6 style="font-size: 10px; font-weight: bold;">Términos y condiciones del servicio</h6>
                {!! $document->terms_condition !!}
            </td>
        </tr>
    @endif
    </tr>
    {{-- ######## INICIO MODALIDAD DE EMISIÓN FISCAL ######## --}}
@if(!((string) $document->document_type_id === '01' && $document->fiscal_emission_mode === 'digital'))
<tr>
        <td class="text-center desc pt-5">Para consultar el comprobante ingresar a {!! url('/buscar') !!}</td>
    </tr>
@endif
{{-- ######## FIN MODALIDAD DE EMISIÓN FISCAL ######## --}}
</table>

</body>
</html>
{{-- ######## FIN MIGRACIÓN MONEDA VENEZUELA ######## --}}

{{-- ######## FIN PERSISTENCIA FISCAL VENEZUELA ######## --}}
