<?php

namespace App\CoreFacturalo;

use Closure;

class InputRequest
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @param  $type
     * @param  $service
     * @return mixed
     * @throws \Exception
     */
    public function handle($request, Closure $next, $type, $service)
    {
        try {
            return \Illuminate\Support\Facades\DB::connection('tenant')->transaction(function () use ($request, $next, $type, $service) {
                if ($type==='dispatch' && $service==='web') {
                    \App\Services\Fiscal\DeliveryOrderInput::authorize();
                    \App\Models\Tenant\Company::query()->lockForUpdate()->firstOrFail();
                }
                $inputs = $request->all();
                if ($service === 'api') $inputs = $this->transformInputs($inputs, $type);
                $inputs = $this->validationInputs($inputs, $type, $service);
                $request->replace($this->setInputs($inputs, $type, $service));
                return $next($request);
            });
        } catch (\Illuminate\Validation\ValidationException $exception) {
            throw $exception;
        } catch (\Symfony\Component\HttpKernel\Exception\HttpExceptionInterface $exception) {
            throw $exception;
        } catch (\Exception $exception) {
            return response()->json(['success' => false, 'message' => 'No se pudo registrar el documento. Revise los datos y la serie seleccionada.'], 400);
        }
    }

    private function transformInputs($inputs, $type)
    {
        $class = "App\\CoreFacturalo\\Requests\\Api\\Transform\\".ucfirst($type)."Transform";
        return $class::transform($inputs);
    }

    private function validationInputs($inputs, $type, $service)
    {
        $class = "App\\CoreFacturalo\\Requests\\".ucfirst($service)."\\Validation\\".ucfirst($type)."Validation";
        return $class::validation($inputs);
    }

    private function setInputs($inputs, $type, $service)
    {
        $class = "App\\CoreFacturalo\\Requests\\Inputs\\".ucfirst($type)."Input";
        return $class::set($inputs, $service);
    }
}
